// Jasem (جاسم) — Bidirectional AI-Powered Arabic Marketplace Types

// ─── Bubble Types ───
export interface BubbleData {
  id: string;
  label: string;
  x: number;
  y: number;
  radius: number;
  color: string;
  color2: string;
  items: BubbleItem[];
  popped: boolean;
  hover: boolean;
  vx: number;
  vy: number;
  poppedAt?: number;
  windowId?: string;
  icon?: string;
}

export interface BubbleItem {
  title: string;
  value: string;
  trend: 'up' | 'down' | 'neutral';
  progress?: number;
}

// ─── Window Types ───
export type WindowState = 'normal' | 'maximized' | 'minimized' | 'snapped-left' | 'snapped-right';

export interface WindowData {
  id: string;
  label: string;
  description?: string;
  items: BubbleItem[];
  color: string;
  color2: string;
  icon?: string;
  state: WindowState;
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
  prevState?: WindowState;
  prevBounds?: { x: number; y: number; width: number; height: number };
}

// ─── Chat Types ───
export type MessageSender = 'user' | 'ai';

export interface ChatMessage {
  id: string;
  content: string;
  sender: MessageSender;
  timestamp: Date;
  liked?: boolean | null; // null = no reaction, true = liked, false = disliked
  suggestions?: string[];
}

// ─── Product Types ───
export interface ProductData {
  id: string;
  name: string;
  nameAr: string;
  price: number;
  currency: string;
  image?: string;
  category: string;
  rating: number;
  salesCount: number;
}

// ─── Wallet Types ───
export interface WalletData {
  balance: number;
  pending: number;
  currency: string;
}

// ─── Analytics Types ───
export interface AnalyticsData {
  views: number;
  sales: number;
  avgOrder: number;
  roi: number;
}

// ─── User Types ───
export interface UserData {
  name: string;
  nameAr: string;
  role: string;
  avatar?: string;
}

// ─── Minimized Dock Types ───
export interface DockItem {
  id: string;
  label: string;
  icon?: string;
  color: string;
}

// ─── Particle Types ───
export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

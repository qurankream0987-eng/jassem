import { create } from 'zustand';
import type {
  BubbleData,
  BubbleItem,
  WindowData,
  WindowState,
  ChatMessage,
  ProductData,
  WalletData,
  AnalyticsData,
  UserData,
  DockItem,
} from './jasem-types';

// ─── Default Data ───
const defaultBubbleItems: Record<string, BubbleItem[]> = {
  ads: [
    { title: 'إعلانات نشطة', value: '24', trend: 'up', progress: 0.8 },
    { title: 'مشاهدات اليوم', value: '1.2K', trend: 'up', progress: 0.65 },
    { title: 'معدل النقر', value: '3.4%', trend: 'down', progress: 0.34 },
    { title: 'إعلانات معلقة', value: '5', trend: 'neutral', progress: 0.5 },
  ],
  suggestions: [
    { title: 'اقتراحات جديدة', value: '12', trend: 'up', progress: 0.7 },
    { title: 'مقبولة', value: '8', trend: 'up', progress: 0.6 },
    { title: 'مرفوضة', value: '3', trend: 'down', progress: 0.25 },
    { title: 'قيد المراجعة', value: '1', trend: 'neutral', progress: 0.4 },
  ],
  subchat: [
    { title: 'غرف فرعية', value: '6', trend: 'up', progress: 0.6 },
    { title: 'رسائل اليوم', value: '340', trend: 'up', progress: 0.75 },
    { title: 'أعضاء متصلون', value: '18', trend: 'up', progress: 0.9 },
    { title: 'متوسط الرد', value: '2.1د', trend: 'down', progress: 0.45 },
  ],
  wallet: [
    { title: 'الرصيد', value: '2,450 ر.س', trend: 'up', progress: 0.82 },
    { title: 'معلق', value: '350 ر.س', trend: 'neutral', progress: 0.35 },
    { title: 'إجمالي المبيعات', value: '15,800 ر.س', trend: 'up', progress: 0.9 },
    { title: 'العمولات', value: '790 ر.س', trend: 'down', progress: 0.4 },
  ],
  analytics: [
    { title: 'مشاهدات', value: '45.2K', trend: 'up', progress: 0.85 },
    { title: 'مبيعات', value: '128', trend: 'up', progress: 0.72 },
    { title: 'متوسط الطلب', value: '185 ر.س', trend: 'up', progress: 0.65 },
    { title: 'العائد على الاستثمار', value: '24%', trend: 'up', progress: 0.78 },
  ],
  settings: [
    { title: 'الإعدادات العامة', value: 'مكتملة', trend: 'neutral', progress: 1.0 },
    { title: 'الإشعارات', value: 'مفعلة', trend: 'neutral', progress: 0.8 },
    { title: 'الأمان', value: 'عالي', trend: 'up', progress: 0.95 },
    { title: 'اللغة', value: 'العربية', trend: 'neutral', progress: 1.0 },
  ],
};

const defaultBubbles: BubbleData[] = [
  {
    id: 'bubble-ads',
    label: 'الإعلانات',
    x: 0, y: 0, radius: 75,
    color: '#00d4ff', color2: '#4a9eff',
    items: defaultBubbleItems.ads,
    popped: false, hover: false, vx: 0, vy: 0,
    icon: 'Megaphone',
  },
  {
    id: 'bubble-suggestions',
    label: 'الاقتراحات',
    x: 0, y: 0, radius: 68,
    color: '#a855f7', color2: '#ec4899',
    items: defaultBubbleItems.suggestions,
    popped: false, hover: false, vx: 0, vy: 0,
    icon: 'Lightbulb',
  },
  {
    id: 'bubble-subchat',
    label: 'دردشة فرعية',
    x: 0, y: 0, radius: 65,
    color: '#00c896', color2: '#00d4ff',
    items: defaultBubbleItems.subchat,
    popped: false, hover: false, vx: 0, vy: 0,
    icon: 'MessageCircle',
  },
  {
    id: 'bubble-wallet',
    label: 'المحفظة',
    x: 0, y: 0, radius: 72,
    color: '#FFD700', color2: '#FF6B00',
    items: defaultBubbleItems.wallet,
    popped: false, hover: false, vx: 0, vy: 0,
    icon: 'Wallet',
  },
  {
    id: 'bubble-analytics',
    label: 'التحليلات',
    x: 0, y: 0, radius: 70,
    color: '#ec4899', color2: '#a855f7',
    items: defaultBubbleItems.analytics,
    popped: false, hover: false, vx: 0, vy: 0,
    icon: 'BarChart3',
  },
  {
    id: 'bubble-settings',
    label: 'الإعدادات',
    x: 0, y: 0, radius: 60,
    color: '#4a9eff', color2: '#00c896',
    items: defaultBubbleItems.settings,
    popped: false, hover: false, vx: 0, vy: 0,
    icon: 'Settings',
  },
];

const defaultMessages: ChatMessage[] = [
  {
    id: 'msg-welcome',
    content: 'مرحباً بك في جاسم! 🌟 سوقك الذكي ثنائي الاتجاه. كيف يمكنني مساعدتك اليوم؟ يمكنك استكشاف الفقاعات أو طرح أي سؤال.',
    sender: 'ai',
    timestamp: new Date(),
    suggestions: ['عرض الإعلانات', 'حالة المحفظة', 'تحليلات المبيعات', 'اقتراحات جديدة'],
  },
];

// ─── Store Interface ───
interface JasemState {
  bubbles: BubbleData[];
  windows: WindowData[];
  messages: ChatMessage[];
  products: ProductData[];
  wallet: WalletData;
  analytics: AnalyticsData;
  user: UserData;
  nextZIndex: number;
  chatLoading: boolean;

  // Bubble actions
  updateBubble: (id: string, updates: Partial<BubbleData>) => void;
  popBubble: (id: string) => void;
  respawnBubble: (id: string) => void;
  setBubbles: (bubbles: BubbleData[]) => void;

  // Window actions
  openWindow: (bubbleId: string) => void;
  closeWindow: (id: string) => void;
  minimizeWindow: (id: string) => void;
  maximizeWindow: (id: string) => void;
  restoreWindow: (id: string) => void;
  snapWindow: (id: string, state: WindowState) => void;
  updateWindow: (id: string, updates: Partial<WindowData>) => void;
  bringToFront: (id: string) => void;

  // Chat actions
  addMessage: (content: string, sender: 'user' | 'ai', suggestions?: string[]) => void;
  setChatLoading: (loading: boolean) => void;
  likeMessage: (id: string, liked: boolean | null) => void;

  // Wallet actions
  updateWallet: (updates: Partial<WalletData>) => void;

  // Analytics actions
  updateAnalytics: (updates: Partial<AnalyticsData>) => void;

  // Dock items
  getDockItems: () => DockItem[];
}

// ─── Helper: Find bubble by ID ───
const findBubble = (bubbles: BubbleData[], id: string) => bubbles.find(b => b.id === id);

export const useJasemStore = create<JasemState>((set, get) => ({
  bubbles: defaultBubbles,
  windows: [],
  messages: defaultMessages,
  products: [],
  wallet: { balance: 2450, pending: 350, currency: 'ر.س' },
  analytics: { views: 45200, sales: 128, avgOrder: 185, roi: 24 },
  user: { name: 'Jasem User', nameAr: 'مستخدم جاسم', role: 'تاجر', avatar: '' },
  nextZIndex: 100,
  chatLoading: false,

  // ─── Bubble Actions ───
  updateBubble: (id, updates) =>
    set(state => ({
      bubbles: state.bubbles.map(b => (b.id === id ? { ...b, ...updates } : b)),
    })),

  popBubble: (id) =>
    set(state => ({
      bubbles: state.bubbles.map(b => (b.id === id ? { ...b, popped: true, poppedAt: Date.now() } : b)),
    })),

  respawnBubble: (id) =>
    set(state => ({
      bubbles: state.bubbles.map(b => (b.id === id ? { ...b, popped: false, poppedAt: undefined } : b)),
    })),

  setBubbles: (bubbles) => set({ bubbles }),

  // ─── Window Actions ───
  openWindow: (bubbleId) => {
    const state = get();
    const bubble = findBubble(state.bubbles, bubbleId);
    if (!bubble) return;

    // Check if window already exists
    const existing = state.windows.find(w => w.id === `window-${bubbleId}`);
    if (existing) {
      // Restore if minimized, bring to front
      set(s => ({
        windows: s.windows.map(w =>
          w.id === existing.id
            ? { ...w, state: w.state === 'minimized' ? 'normal' : w.state, zIndex: s.nextZIndex }
            : w
        ),
        nextZIndex: s.nextZIndex + 1,
      }));
      return;
    }

    const newWindow: WindowData = {
      id: `window-${bubbleId}`,
      label: bubble.label,
      description: `نافذة ${bubble.label}`,
      items: bubble.items,
      color: bubble.color,
      color2: bubble.color2,
      icon: bubble.icon,
      state: 'normal',
      x: 100 + Math.random() * 200,
      y: 80 + Math.random() * 150,
      width: 420,
      height: 380,
      zIndex: state.nextZIndex,
    };

    set(s => ({
      windows: [...s.windows, newWindow],
      nextZIndex: s.nextZIndex + 1,
      bubbles: s.bubbles.map(b => (b.id === bubbleId ? { ...b, windowId: newWindow.id } : b)),
    }));
  },

  closeWindow: (id) =>
    set(state => ({
      windows: state.windows.filter(w => w.id !== id),
      bubbles: state.bubbles.map(b => (b.windowId === id ? { ...b, windowId: undefined } : b)),
    })),

  minimizeWindow: (id) =>
    set(state => ({
      windows: state.windows.map(w =>
        w.id === id
          ? { ...w, prevState: w.state, prevBounds: { x: w.x, y: w.y, width: w.width, height: w.height }, state: 'minimized' as WindowState }
          : w
      ),
    })),

  maximizeWindow: (id) =>
    set(state => ({
      windows: state.windows.map(w => {
        if (w.id !== id) return w;
        if (w.state === 'maximized') {
          // Restore
          return {
            ...w,
            state: w.prevState || 'normal',
            x: w.prevBounds?.x ?? w.x,
            y: w.prevBounds?.y ?? w.y,
            width: w.prevBounds?.width ?? w.width,
            height: w.prevBounds?.height ?? w.height,
          };
        }
        return {
          ...w,
          prevState: w.state,
          prevBounds: { x: w.x, y: w.y, width: w.width, height: w.height },
          state: 'maximized' as WindowState,
          x: 0,
          y: 0,
          width: typeof window !== 'undefined' ? window.innerWidth : 1200,
          height: typeof window !== 'undefined' ? window.innerHeight : 800,
        };
      }),
    })),

  restoreWindow: (id) =>
    set(state => ({
      windows: state.windows.map(w => {
        if (w.id !== id) return w;
        return {
          ...w,
          state: w.prevState || 'normal',
          x: w.prevBounds?.x ?? w.x,
          y: w.prevBounds?.y ?? w.y,
          width: w.prevBounds?.width ?? w.width,
          height: w.prevBounds?.height ?? w.height,
        };
      }),
    })),

  snapWindow: (id, snapState) =>
    set(state => ({
      windows: state.windows.map(w => {
        if (w.id !== id) return w;
        const vw = typeof window !== 'undefined' ? window.innerWidth : 1200;
        const vh = typeof window !== 'undefined' ? window.innerHeight : 800;
        const prevBounds = { x: w.x, y: w.y, width: w.width, height: w.height };

        switch (snapState) {
          case 'snapped-left':
            return { ...w, state: snapState, prevState: w.state, prevBounds, x: 0, y: 0, width: vw / 2, height: vh };
          case 'snapped-right':
            return { ...w, state: snapState, prevState: w.state, prevBounds, x: vw / 2, y: 0, width: vw / 2, height: vh };
          case 'maximized':
            return { ...w, state: snapState, prevState: w.state, prevBounds, x: 0, y: 0, width: vw, height: vh };
          default:
            return w;
        }
      }),
    })),

  updateWindow: (id, updates) =>
    set(state => ({
      windows: state.windows.map(w => (w.id === id ? { ...w, ...updates } : w)),
    })),

  bringToFront: (id) =>
    set(state => ({
      windows: state.windows.map(w => (w.id === id ? { ...w, zIndex: state.nextZIndex } : w)),
      nextZIndex: state.nextZIndex + 1,
    })),

  // ─── Chat Actions ───
  addMessage: (content, sender, suggestions) =>
    set(state => ({
      messages: [
        ...state.messages,
        {
          id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          content,
          sender,
          timestamp: new Date(),
          suggestions: suggestions || (sender === 'ai' ? undefined : undefined),
        },
      ],
    })),

  setChatLoading: (loading) => set({ chatLoading: loading }),

  likeMessage: (id, liked) =>
    set(state => ({
      messages: state.messages.map(m => (m.id === id ? { ...m, liked } : m)),
    })),

  // ─── Wallet Actions ───
  updateWallet: (updates) =>
    set(state => ({ wallet: { ...state.wallet, ...updates } })),

  // ─── Analytics Actions ───
  updateAnalytics: (updates) =>
    set(state => ({ analytics: { ...state.analytics, ...updates } })),

  // ─── Dock Items ───
  getDockItems: () => {
    const state = get();
    return state.windows
      .filter(w => w.state === 'minimized')
      .map(w => ({
        id: w.id,
        label: w.label,
        icon: w.icon,
        color: w.color,
      }));
  },
}));

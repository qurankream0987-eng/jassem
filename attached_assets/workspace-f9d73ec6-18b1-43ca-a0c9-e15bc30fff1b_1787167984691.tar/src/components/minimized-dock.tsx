'use client';

import { useState } from 'react';
import type { DockItem } from '@/lib/jasem-types';

interface MinimizedDockProps {
  items: DockItem[];
  onRestore: (id: string) => void;
}

export default function MinimizedDock({ items, onRestore }: MinimizedDockProps) {
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  if (items.length === 0) return null;

  return (
    <div
      className="fixed right-3 top-1/2 -translate-y-1/2 flex flex-col items-center gap-3 p-2 rounded-2xl"
      style={{
        zIndex: 150,
        direction: 'rtl',
        background: 'rgba(10, 15, 30, 0.7)',
        backdropFilter: 'blur(16px)',
        border: '1px solid rgba(255, 255, 255, 0.08)',
      }}
    >
      {items.map((item) => (
        <div
          key={item.id}
          className="relative"
          onMouseEnter={() => setHoveredId(item.id)}
          onMouseLeave={() => setHoveredId(null)}
        >
          {/* Tooltip */}
          <div
            className="absolute right-full ml-2 top-1/2 -translate-y-1/2 px-3 py-1 rounded-lg text-xs text-white/80 whitespace-nowrap transition-all duration-200 pointer-events-none"
            style={{
              background: 'rgba(10, 15, 30, 0.9)',
              backdropFilter: 'blur(8px)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              opacity: hoveredId === item.id ? 1 : 0,
              transform: hoveredId === item.id ? 'translateY(-50%) translateX(0)' : 'translateY(-50%) translateX(8px)',
            }}
          >
            {item.label}
          </div>

          {/* Bubble button */}
          <button
            onClick={() => onRestore(item.id)}
            className="relative w-10 h-10 rounded-full transition-all duration-200 hover:scale-110 active:scale-95"
            style={{
              background: `linear-gradient(135deg, ${item.color}, ${item.color}88)`,
              boxShadow: `0 0 12px ${item.color}30, 0 2px 8px rgba(0,0,0,0.3)`,
            }}
          >
            {/* Specular highlight */}
            <div
              className="absolute inset-0 rounded-full pointer-events-none"
              style={{
                background: 'radial-gradient(circle at 35% 35%, rgba(255,255,255,0.3), transparent 60%)',
              }}
            />
            {/* Icon placeholder (first letter) */}
            <span className="relative text-xs font-bold text-white/90">
              {item.label.charAt(0)}
            </span>
          </button>
        </div>
      ))}
    </div>
  );
}

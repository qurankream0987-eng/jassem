'use client';

import { useEffect, useRef } from 'react';

interface Nebula {
  x: number;
  y: number;
  radius: number;
  hue: number;
  speed: number;
  phase: number;
}

interface NeuralLine {
  angle: number;
  length: number;
  speed: number;
  phase: number;
  width: number;
}

interface PulsingNode {
  x: number;
  y: number;
  baseRadius: number;
  phase: number;
  speed: number;
  hue: number;
}

interface TwinkleParticle {
  x: number;
  y: number;
  size: number;
  alpha: number;
  twinkleSpeed: number;
  phase: number;
}

export default function SpaceBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = 0;
    let height = 0;
    let dpr = 1;

    const resize = () => {
      dpr = window.devicePixelRatio || 1;
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = width + 'px';
      canvas.style.height = height + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resize();
    window.addEventListener('resize', resize);

    // ─── Initialize elements ───
    const nebulae: Nebula[] = [];
    for (let i = 0; i < 8; i++) {
      nebulae.push({
        x: Math.random() * width,
        y: Math.random() * height,
        radius: 100 + Math.random() * 200,
        hue: [190, 260, 320, 170, 220, 280, 340, 200][i],
        speed: 0.15 + Math.random() * 0.25,
        phase: Math.random() * Math.PI * 2,
      });
    }

    const neuralLines: NeuralLine[] = [];
    for (let i = 0; i < 50; i++) {
      neuralLines.push({
        angle: (Math.PI * 2 * i) / 50 + (Math.random() - 0.5) * 0.3,
        length: 80 + Math.random() * 250,
        speed: 0.3 + Math.random() * 0.5,
        phase: Math.random() * Math.PI * 2,
        width: 0.5 + Math.random() * 1.5,
      });
    }

    const pulsingNodes: PulsingNode[] = [];
    for (let i = 0; i < 35; i++) {
      const angle = Math.random() * Math.PI * 2;
      const dist = 50 + Math.random() * 280;
      pulsingNodes.push({
        x: Math.cos(angle) * dist,
        y: Math.sin(angle) * dist,
        baseRadius: 2 + Math.random() * 4,
        phase: Math.random() * Math.PI * 2,
        speed: 0.8 + Math.random() * 1.5,
        hue: 180 + Math.random() * 140,
      });
    }

    const particles: TwinkleParticle[] = [];
    for (let i = 0; i < 250; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: 0.5 + Math.random() * 2,
        alpha: Math.random(),
        twinkleSpeed: 0.5 + Math.random() * 2,
        phase: Math.random() * Math.PI * 2,
      });
    }

    // ─── Animation Loop ───
    let time = 0;

    const draw = () => {
      time += 0.016;
      const cx = width / 2;
      const cy = height / 2;

      // Background
      const bgGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(width, height) * 0.7);
      bgGrad.addColorStop(0, '#070c1a');
      bgGrad.addColorStop(1, '#000000');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // Nebulae
      for (const neb of nebulae) {
        const nx = neb.x + Math.sin(time * neb.speed + neb.phase) * 60;
        const ny = neb.y + Math.cos(time * neb.speed * 0.7 + neb.phase) * 40;
        const grad = ctx.createRadialGradient(nx, ny, 0, nx, ny, neb.radius);
        grad.addColorStop(0, `hsla(${neb.hue}, 80%, 50%, 0.06)`);
        grad.addColorStop(0.5, `hsla(${neb.hue}, 70%, 40%, 0.03)`);
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.fillRect(nx - neb.radius, ny - neb.radius, neb.radius * 2, neb.radius * 2);
      }

      // Neural lines
      ctx.save();
      ctx.translate(cx, cy);
      for (const line of neuralLines) {
        const wave = Math.sin(time * line.speed + line.phase) * 30;
        const endX = Math.cos(line.angle) * line.length + wave;
        const endY = Math.sin(line.angle) * line.length + Math.cos(time * line.speed * 0.8 + line.phase) * 20;
        const midX = endX * 0.5 + Math.sin(time * 0.5 + line.phase) * 15;
        const midY = endY * 0.5 + Math.cos(time * 0.5 + line.phase) * 15;

        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.quadraticCurveTo(midX, midY, endX, endY);
        ctx.strokeStyle = `hsla(${200 + line.phase * 30}, 80%, 60%, ${0.08 + Math.sin(time * line.speed + line.phase) * 0.04})`;
        ctx.lineWidth = line.width;
        ctx.stroke();
      }
      ctx.restore();

      // Pulsing nodes
      ctx.save();
      ctx.translate(cx, cy);
      for (const node of pulsingNodes) {
        const pulse = Math.sin(time * node.speed + node.phase);
        const r = node.baseRadius + pulse * 2;
        const alpha = 0.3 + pulse * 0.2;
        const grad = ctx.createRadialGradient(node.x, node.y, 0, node.x, node.y, Math.max(0.1, r * 3));
        grad.addColorStop(0, `hsla(${node.hue}, 80%, 70%, ${alpha})`);
        grad.addColorStop(0.5, `hsla(${node.hue}, 80%, 60%, ${alpha * 0.3})`);
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(node.x, node.y, Math.max(0.1, r * 3), 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = `hsla(${node.hue}, 90%, 80%, ${alpha + 0.2})`;
        ctx.beginPath();
        ctx.arc(node.x, node.y, Math.max(0.1, r), 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // Twinkling particles
      for (const p of particles) {
        const twinkle = 0.3 + Math.sin(time * p.twinkleSpeed + p.phase) * 0.5 + 0.2;
        ctx.fillStyle = `rgba(200, 220, 255, ${twinkle * 0.7})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }

      // Vignette
      const vigGrad = ctx.createRadialGradient(cx, cy, Math.min(width, height) * 0.3, cx, cy, Math.max(width, height) * 0.75);
      vigGrad.addColorStop(0, 'transparent');
      vigGrad.addColorStop(1, 'rgba(0, 0, 0, 0.6)');
      ctx.fillStyle = vigGrad;
      ctx.fillRect(0, 0, width, height);

      animFrameRef.current = requestAnimationFrame(draw);
    };

    animFrameRef.current = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(animFrameRef.current);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: 0,
        pointerEvents: 'none',
      }}
    />
  );
}

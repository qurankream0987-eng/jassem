'use client';

import { useRef, useState, useCallback, useEffect } from 'react';
import { Send, Mic, Paperclip, Copy, RefreshCw, ThumbsUp, ThumbsDown, ChevronDown, Sparkles } from 'lucide-react';
import type { ChatMessage } from '@/lib/jasem-types';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  onSendMessage: (content: string) => void;
  isLoading: boolean;
  suggestions?: string[];
}

export default function ChatInterface({
  messages,
  onSendMessage,
  isLoading,
  suggestions = [],
}: ChatInterfaceProps) {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const [hoveredMsg, setHoveredMsg] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Scroll button visibility
  useEffect(() => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const handleScroll = () => {
      const threshold = 80;
      setShowScrollBtn(el.scrollHeight - el.scrollTop - el.clientHeight > threshold);
    };
    el.addEventListener('scroll', handleScroll);
    return () => el.removeEventListener('scroll', handleScroll);
  }, []);

  // Auto-resize textarea
  useEffect(() => {
    const ta = textareaRef.current;
    if (ta) {
      ta.style.height = 'auto';
      ta.style.height = Math.min(ta.scrollHeight, 120) + 'px';
    }
  }, [input]);

  const handleSend = useCallback(() => {
    const trimmed = input.trim();
    if (!trimmed || isLoading) return;
    onSendMessage(trimmed);
    setInput('');
  }, [input, isLoading, onSendMessage]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }, [handleSend]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard?.writeText(text);
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
  };

  // Date divider
  const shouldShowDateDivider = (msg: ChatMessage, idx: number) => {
    if (idx === 0) return true;
    const prev = messages[idx - 1];
    const prevDate = new Date(prev.timestamp).toDateString();
    const currDate = new Date(msg.timestamp).toDateString();
    return prevDate !== currDate;
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('ar-SA', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <div
      className="flex flex-col h-full w-full max-w-2xl mx-auto"
      style={{ direction: 'rtl' }}
    >
      {/* Messages area */}
      <div
        ref={scrollContainerRef}
        className="flex-1 overflow-y-auto p-4 space-y-1 scrollbar-thin"
        style={{ scrollbarWidth: 'thin' }}
      >
        {messages.map((msg, idx) => (
          <div key={msg.id}>
            {/* Date divider */}
            {shouldShowDateDivider(msg, idx) && (
              <div className="flex items-center justify-center my-4">
                <div className="h-px flex-1 bg-white/10" />
                <span className="px-3 text-xs text-white/30">{formatDate(msg.timestamp)}</span>
                <div className="h-px flex-1 bg-white/10" />
              </div>
            )}

            {/* Message bubble */}
            <div
              className="group flex flex-col mb-2"
              onMouseEnter={() => setHoveredMsg(msg.id)}
              onMouseLeave={() => setHoveredMsg(null)}
            >
              <div
                className={`relative max-w-[85%] rounded-2xl px-4 py-3 ${
                  msg.sender === 'user'
                    ? 'mr-auto bg-cyan-500/10 border border-cyan-500/20'
                    : 'ml-auto bg-purple-500/10 border border-purple-500/20'
                }`}
                style={{
                  backdropFilter: 'blur(12px)',
                  alignSelf: msg.sender === 'user' ? 'flex-start' : 'flex-end',
                }}
              >
                {/* Specular */}
                <div
                  className="absolute inset-0 rounded-2xl pointer-events-none"
                  style={{
                    background: 'linear-gradient(180deg, rgba(255,255,255,0.04) 0%, transparent 50%)',
                  }}
                />

                <p className="text-sm text-white/85 leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                <span className="block text-xs text-white/25 mt-2">{formatTime(msg.timestamp)}</span>

                {/* Action buttons on hover */}
                {hoveredMsg === msg.id && (
                  <div className="absolute top-1 left-1 flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => copyToClipboard(msg.content)}
                      className="p-1 rounded hover:bg-white/10 transition-colors"
                      title="نسخ"
                    >
                      <Copy className="w-3 h-3 text-white/40" />
                    </button>
                    {msg.sender === 'ai' && (
                      <>
                        <button className="p-1 rounded hover:bg-white/10 transition-colors" title="إعادة توليد">
                          <RefreshCw className="w-3 h-3 text-white/40" />
                        </button>
                        <button
                          className="p-1 rounded hover:bg-white/10 transition-colors"
                          title="إعجاب"
                        >
                          <ThumbsUp className={`w-3 h-3 ${msg.liked === true ? 'text-green-400' : 'text-white/40'}`} />
                        </button>
                        <button
                          className="p-1 rounded hover:bg-white/10 transition-colors"
                          title="عدم إعجاب"
                        >
                          <ThumbsDown className={`w-3 h-3 ${msg.liked === false ? 'text-red-400' : 'text-white/40'}`} />
                        </button>
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Suggestions after AI messages */}
              {msg.sender === 'ai' && msg.suggestions && msg.suggestions.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2 mr-auto ml-4">
                  {msg.suggestions.map((sug, i) => (
                    <button
                      key={i}
                      onClick={() => onSendMessage(sug)}
                      className="px-3 py-1.5 text-xs rounded-full border border-white/10 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white/80 transition-all duration-200"
                      style={{ backdropFilter: 'blur(8px)' }}
                    >
                      {sug}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}

        {/* Typing indicator */}
        {isLoading && (
          <div className="flex items-end ml-auto mr-4 mb-2">
            <div className="bg-purple-500/10 border border-purple-500/20 rounded-2xl px-4 py-3" style={{ backdropFilter: 'blur(12px)' }}>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Scroll to bottom button */}
      {showScrollBtn && (
        <button
          onClick={() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })}
          className="absolute bottom-24 left-1/2 -translate-x-1/2 p-2 rounded-full bg-white/10 border border-white/20 hover:bg-white/20 transition-all"
          style={{ backdropFilter: 'blur(8px)', zIndex: 5 }}
        >
          <ChevronDown className="w-4 h-4 text-white/60" />
        </button>
      )}

      {/* Suggestion bar */}
      {suggestions.length > 0 && (
        <div className="flex gap-2 px-4 py-2 overflow-x-auto scrollbar-none" style={{ scrollbarWidth: 'none' }}>
          {suggestions.map((sug, i) => (
            <button
              key={i}
              onClick={() => onSendMessage(sug)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs border border-white/10 bg-white/5 hover:bg-white/10 text-white/50 hover:text-white/70 transition-all whitespace-nowrap flex-shrink-0"
              style={{ backdropFilter: 'blur(8px)' }}
            >
              <Sparkles className="w-3 h-3" />
              {sug}
            </button>
          ))}
        </div>
      )}

      {/* Composer */}
      <div className="p-3 border-t border-white/10">
        <div
          className="flex items-end gap-2 rounded-xl p-2 bg-white/5 border border-white/10"
          style={{ backdropFilter: 'blur(12px)' }}
        >
          <button className="p-2 rounded-lg hover:bg-white/10 transition-colors flex-shrink-0">
            <Paperclip className="w-4 h-4 text-white/40" />
          </button>
          <button className="p-2 rounded-lg hover:bg-white/10 transition-colors flex-shrink-0">
            <Mic className="w-4 h-4 text-white/40" />
          </button>
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="اكتب رسالتك..."
            rows={1}
            className="flex-1 bg-transparent text-sm text-white/80 placeholder:text-white/25 resize-none outline-none py-2 px-1 max-h-[120px]"
            style={{ direction: 'rtl' }}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="p-2 rounded-lg transition-all flex-shrink-0 disabled:opacity-30"
            style={{
              background: input.trim() && !isLoading
                ? 'linear-gradient(135deg, #00d4ff, #a855f7)'
                : 'rgba(255,255,255,0.1)',
            }}
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}

'use client';

import { useRef, useState, useCallback, useEffect } from 'react';
import { Minus, Square, X, Maximize2, ChevronUp, ChevronDown, ArrowUpRight, ArrowDownRight, Minus as FlatLine } from 'lucide-react';
import type { BubbleItem, WindowState } from '@/lib/jasem-types';

interface SoapWindowProps {
  id: string;
  label: string;
  description?: string;
  items: BubbleItem[];
  color: string;
  color2: string;
  icon?: string;
  state: WindowState;
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
  onClose: () => void;
  onMinimize: () => void;
  onMaximize: () => void;
  onSnap: (state: WindowState) => void;
  onUpdate: (updates: { x?: number; y?: number; width?: number; height?: number; state?: WindowState }) => void;
  onFocus: () => void;
}

export default function SoapWindow({
  id,
  label,
  description,
  items,
  color,
  color2,
  icon,
  state,
  x,
  y,
  width,
  height,
  zIndex,
  onClose,
  onMinimize,
  onMaximize,
  onSnap,
  onUpdate,
  onFocus,
}: SoapWindowProps) {
  const windowRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [resizeDir, setResizeDir] = useState('');
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [snapPreview, setSnapPreview] = useState<WindowState | null>(null);
  const [borderAngle, setBorderAngle] = useState(0);
  const dragVelocity = useRef({ x: 0, y: 0, lastX: 0, lastY: 0, lastTime: 0 });

  // Rotate iridescent border
  useEffect(() => {
    const interval = setInterval(() => {
      setBorderAngle(a => (a + 0.5) % 360);
    }, 16);
    return () => clearInterval(interval);
  }, []);

  // ─── Dragging ───
  const startDrag = useCallback((e: React.MouseEvent) => {
    if (state === 'maximized') return;
    e.preventDefault();
    onFocus();
    setIsDragging(true);
    setDragStart({ x: e.clientX - x, y: e.clientY - y });
    dragVelocity.current = { x: 0, y: 0, lastX: e.clientX, lastY: e.clientY, lastTime: Date.now() };
  }, [state, x, y, onFocus]);

  useEffect(() => {
    if (!isDragging) return;

    const handleMove = (e: MouseEvent) => {
      const newX = e.clientX - dragStart.x;
      const newY = e.clientY - dragStart.y;

      // Track velocity
      const now = Date.now();
      const dt = now - dragVelocity.current.lastTime;
      if (dt > 0) {
        dragVelocity.current.x = (e.clientX - dragVelocity.current.lastX) / dt;
        dragVelocity.current.y = (e.clientY - dragVelocity.current.lastY) / dt;
        dragVelocity.current.lastX = e.clientX;
        dragVelocity.current.lastY = e.clientY;
        dragVelocity.current.lastTime = now;
      }

      onUpdate({ x: newX, y: newY });

      // Snap preview detection
      const vw = window.innerWidth;
      if (e.clientX < 30) setSnapPreview('snapped-left');
      else if (e.clientX > vw - 30) setSnapPreview('snapped-right');
      else if (e.clientY < 30) setSnapPreview('maximized');
      else setSnapPreview(null);
    };

    const handleUp = () => {
      setIsDragging(false);
      if (snapPreview) {
        onSnap(snapPreview);
        setSnapPreview(null);
      }
    };

    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleUp);
    return () => {
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('mouseup', handleUp);
    };
  }, [isDragging, dragStart, snapPreview, onUpdate, onSnap]);

  // ─── Resizing ───
  const startResize = useCallback((dir: string) => (e: React.MouseEvent) => {
    if (state === 'maximized') return;
    e.preventDefault();
    e.stopPropagation();
    onFocus();
    setIsResizing(true);
    setResizeDir(dir);
    setDragStart({ x: e.clientX, y: e.clientY });
  }, [state, onFocus]);

  useEffect(() => {
    if (!isResizing) return;

    const handleMove = (e: MouseEvent) => {
      const dx = e.clientX - dragStart.x;
      const dy = e.clientY - dragStart.y;
      let newX = x, newY = y, newW = width, newH = height;

      if (resizeDir.includes('e')) newW = Math.max(300, width + dx);
      if (resizeDir.includes('w')) { newW = Math.max(300, width - dx); newX = x + dx; }
      if (resizeDir.includes('s')) newH = Math.max(200, height + dy);
      if (resizeDir.includes('n')) { newH = Math.max(200, height - dy); newY = y + dy; }

      onUpdate({ x: newX, y: newY, width: newW, height: newH });
    };

    const handleUp = () => {
      setIsResizing(false);
    };

    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleUp);
    return () => {
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('mouseup', handleUp);
    };
  }, [isResizing, resizeDir, dragStart, x, y, width, height, onUpdate]);

  const TrendIcon = ({ trend }: { trend: string }) => {
    if (trend === 'up') return <ArrowUpRight className="w-3 h-3 text-green-400" />;
    if (trend === 'down') return <ArrowDownRight className="w-3 h-3 text-red-400" />;
    return <FlatLine className="w-3 h-3 text-gray-400" />;
  };

  // Snap preview ghost
  const renderSnapPreview = () => {
    if (!snapPreview) return null;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let sx = 0, sy = 0, sw = vw / 2, sh = vh;
    if (snapPreview === 'snapped-right') { sx = vw / 2; }
    if (snapPreview === 'maximized') { sw = vw; }

    return (
      <div
        style={{
          position: 'fixed',
          left: sx,
          top: sy,
          width: sw,
          height: sh,
          zIndex: 9998,
          border: `2px dashed ${color}`,
          borderRadius: 12,
          background: `${color}10`,
          pointerEvents: 'none',
        }}
      />
    );
  };

  const resizeHandles = ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw'];
  const handleCursors: Record<string, string> = {
    n: 'ns-resize', s: 'ns-resize', e: 'ew-resize', w: 'ew-resize',
    ne: 'nesw-resize', nw: 'nwse-resize', se: 'nwse-resize', sw: 'nesw-resize',
  };

  return (
    <>
      {renderSnapPreview()}
      <div
        ref={windowRef}
        onMouseDown={onFocus}
        style={{
          position: 'fixed',
          left: state === 'maximized' ? 0 : state === 'snapped-left' ? 0 : state === 'snapped-right' ? '50%' : x,
          top: state === 'maximized' || state === 'snapped-left' || state === 'snapped-right' ? 0 : y,
          width: state === 'maximized' ? '100%' : state === 'snapped-left' || state === 'snapped-right' ? '50%' : width,
          height: state === 'maximized' || state === 'snapped-left' || state === 'snapped-right' ? '100%' : height,
          zIndex,
          direction: 'rtl',
        }}
        className="flex flex-col overflow-hidden rounded-xl shadow-2xl transition-shadow duration-200"
      >
        {/* Iridescent rotating border */}
        <div
          style={{
            position: 'absolute',
            inset: -2,
            borderRadius: 14,
            background: `conic-gradient(from ${borderAngle}deg, ${color}, ${color2}, #a855f7, #ec4899, #00d4ff, ${color})`,
            zIndex: -1,
            opacity: 0.6,
            filter: 'blur(1px)',
          }}
        />

        {/* Glass background */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: 'rgba(10, 15, 30, 0.85)',
            backdropFilter: 'blur(20px)',
            borderRadius: 12,
            zIndex: 0,
          }}
        />

        {/* Specular highlight */}
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: '40%',
            background: 'linear-gradient(180deg, rgba(255,255,255,0.06) 0%, transparent 100%)',
            borderRadius: '12px 12px 0 0',
            pointerEvents: 'none',
            zIndex: 1,
          }}
        />

        {/* Content */}
        <div className="relative z-10 flex flex-col h-full">
          {/* Header */}
          <div
            onMouseDown={startDrag}
            className="flex items-center justify-between px-4 py-3 border-b border-white/10 cursor-grab active:cursor-grabbing select-none"
          >
            <div className="flex items-center gap-3">
              <div
                style={{ background: `linear-gradient(135deg, ${color}, ${color2})` }}
                className="w-3 h-3 rounded-full shadow-lg"
              />
              <div>
                <h3 className="text-sm font-bold text-white/90">{label}</h3>
                {description && (
                  <p className="text-xs text-white/40">{description}</p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={(e) => { e.stopPropagation(); onMinimize(); }}
                className="p-1.5 rounded-md hover:bg-white/10 transition-colors"
              >
                <Minus className="w-3.5 h-3.5 text-white/60" />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); onMaximize(); }}
                className="p-1.5 rounded-md hover:bg-white/10 transition-colors"
              >
                {state === 'maximized' ? (
                  <Maximize2 className="w-3.5 h-3.5 text-white/60" />
                ) : (
                  <Square className="w-3.5 h-3.5 text-white/60" />
                )}
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); onClose(); }}
                className="p-1.5 rounded-md hover:bg-red-500/20 transition-colors"
              >
                <X className="w-3.5 h-3.5 text-white/60 hover:text-red-400" />
              </button>
            </div>
          </div>

          {/* Scrollable content */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin" style={{ scrollbarWidth: 'thin' }}>
            {items.map((item, idx) => (
              <div
                key={idx}
                className="group p-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/15 transition-all duration-200 cursor-pointer"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-white/70">{item.title}</span>
                  <div className="flex items-center gap-2">
                    <TrendIcon trend={item.trend} />
                    <span className="text-sm font-bold text-white/90">{item.value}</span>
                  </div>
                </div>
                {item.progress !== undefined && (
                  <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                    <div
                      style={{
                        width: `${item.progress * 100}%`,
                        background: `linear-gradient(90deg, ${color}, ${color2})`,
                      }}
                      className="h-full rounded-full transition-all duration-500 group-hover:shadow-lg"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="px-4 py-2 border-t border-white/10 text-xs text-white/30 text-center">
            {label} — جاسم
          </div>
        </div>

        {/* Resize handles */}
        {state !== 'maximized' && state !== 'snapped-left' && state !== 'snapped-right' && (
          <>
            {resizeHandles.map(dir => (
              <div
                key={dir}
                onMouseDown={startResize(dir)}
                style={{
                  position: 'absolute',
                  zIndex: 20,
                  cursor: handleCursors[dir],
                  ...(dir.includes('n') && !dir.includes('s') ? { top: -3, height: 6 } : {}),
                  ...(dir.includes('s') && !dir.includes('n') ? { bottom: -3, height: 6 } : {}),
                  ...(dir.includes('w') && !dir.includes('e') ? { left: -3, width: 6 } : {}),
                  ...(dir.includes('e') && !dir.includes('w') ? { right: -3, width: 6 } : {}),
                  ...(dir === 'n' || dir === 's' ? { left: 6, right: 6 } : {}),
                  ...(dir === 'e' || dir === 'w' ? { top: 6, bottom: 6 } : {}),
                  ...(dir.length === 2 ? { width: 12, height: 12 } : {}),
                  ...(dir === 'ne' ? { top: -3, right: -3 } : {}),
                  ...(dir === 'nw' ? { top: -3, left: -3 } : {}),
                  ...(dir === 'se' ? { bottom: -3, right: -3 } : {}),
                  ...(dir === 'sw' ? { bottom: -3, left: -3 } : {}),
                }}
              />
            ))}
          </>
        )}
      </div>
    </>
  );
}

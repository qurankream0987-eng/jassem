'use client';

import { useEffect, useRef, useCallback } from 'react';
import type { BubbleData } from '@/lib/jasem-types';

interface SoapBubbleCanvasProps {
  bubbles: BubbleData[];
  onBubbleClick: (id: string) => void;
  onBubblePop: (id: string) => void;
  onBubbleDrag: (id: string, x: number, y: number) => void;
}

interface InternalBubble extends BubbleData {
  renderX: number;
  renderY: number;
  renderRadius: number;
  popProgress: number;
  wobblePhase: number;
  wobbleSpeed: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

export default function SoapBubbleCanvas({
  bubbles,
  onBubbleClick,
  onBubblePop,
  onBubbleDrag,
}: SoapBubbleCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number>(0);
  const internalRef = useRef<Map<string, InternalBubble>>(new Map());
  const particlesRef = useRef<Particle[]>([]);
  const mouseRef = useRef({ x: 0, y: 0, down: false, downTime: 0, downBubbleId: '', dragBubbleId: '', dragOffX: 0, dragOffY: 0 });
  const timeRef = useRef(0);

  // Initialize internal bubble states
  const syncBubbles = useCallback(() => {
    const map = internalRef.current;
    const currentIds = new Set(bubbles.map(b => b.id));

    // Remove bubbles that no longer exist
    for (const key of map.keys()) {
      if (!currentIds.has(key)) {
        map.delete(key);
      }
    }

    // Add/update bubbles
    for (const b of bubbles) {
      const existing = map.get(b.id);
      if (!existing) {
        // New bubble - position randomly if x/y are 0
        const w = typeof window !== 'undefined' ? window.innerWidth : 1200;
        const h = typeof window !== 'undefined' ? window.innerHeight : 800;
        map.set(b.id, {
          ...b,
          renderX: b.x || (w * 0.2 + Math.random() * w * 0.6),
          renderY: b.y || (h * 0.2 + Math.random() * h * 0.6),
          renderRadius: b.radius,
          popProgress: 0,
          wobblePhase: Math.random() * Math.PI * 2,
          wobbleSpeed: 0.8 + Math.random() * 0.6,
        });
      } else {
        // Update from props
        existing.popped = b.popped;
        existing.hover = b.hover;
        existing.radius = b.radius;
        existing.label = b.label;
        existing.items = b.items;
        existing.color = b.color;
        existing.color2 = b.color2;
        // If bubble was respawned
        if (!b.popped && existing.popped) {
          existing.popped = false;
          existing.popProgress = 0;
        }
      }
    }
  }, [bubbles]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = 0;
    let height = 0;
    let dpr = 1;

    const resize = () => {
      dpr = window.devicePixelRatio || 1;
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = width + 'px';
      canvas.style.height = height + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resize();
    window.addEventListener('resize', resize);

    // ─── Mouse handlers ───
    const getPos = (e: MouseEvent | TouchEvent) => {
      if ('touches' in e && e.touches.length > 0) {
        return { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
      if ('clientX' in e) return { x: e.clientX, y: e.clientY };
      return { x: 0, y: 0 };
    };

    const findBubbleAt = (mx: number, my: number): string | null => {
      const map = internalRef.current;
      for (const [id, b] of map) {
        if (b.popped) continue;
        const dx = mx - b.renderX;
        const dy = my - b.renderY;
        if (dx * dx + dy * dy < b.renderRadius * b.renderRadius) {
          return id;
        }
      }
      return null;
    };

    const handleDown = (e: MouseEvent | TouchEvent) => {
      const pos = getPos(e);
      const m = mouseRef.current;
      m.x = pos.x;
      m.y = pos.y;
      m.down = true;
      m.downTime = Date.now();
      const bid = findBubbleAt(pos.x, pos.y);
      m.downBubbleId = bid || '';
      if (bid) {
        const b = internalRef.current.get(bid);
        if (b) {
          m.dragBubbleId = bid;
          m.dragOffX = pos.x - b.renderX;
          m.dragOffY = pos.y - b.renderY;
        }
      }
    };

    const handleMove = (e: MouseEvent | TouchEvent) => {
      const pos = getPos(e);
      const m = mouseRef.current;
      m.x = pos.x;
      m.y = pos.y;

      // Update hover states
      for (const [id, b] of internalRef.current) {
        const dx = pos.x - b.renderX;
        const dy = pos.y - b.renderY;
        b.hover = dx * dx + dy * dy < b.renderRadius * b.renderRadius && !b.popped;
      }

      // Drag
      if (m.down && m.dragBubbleId) {
        const b = internalRef.current.get(m.dragBubbleId);
        if (b) {
          b.renderX = pos.x - m.dragOffX;
          b.renderY = pos.y - m.dragOffY;
          onBubbleDrag(m.dragBubbleId, b.renderX, b.renderY);
        }
      }
    };

    const handleUp = () => {
      const m = mouseRef.current;
      if (m.down && m.downBubbleId) {
        const elapsed = Date.now() - m.downTime;
        if (elapsed > 400) {
          // Long press → pop
          onBubblePop(m.downBubbleId);
          // Spawn particles
          const b = internalRef.current.get(m.downBubbleId);
          if (b) {
            spawnParticles(b.renderX, b.renderY, b.color, b.color2, b.renderRadius);
          }
        } else {
          // Short click → open
          onBubbleClick(m.downBubbleId);
        }
      }
      m.down = false;
      m.downBubbleId = '';
      m.dragBubbleId = '';
    };

    const spawnParticles = (x: number, y: number, color: string, color2: string, radius: number) => {
      const particles = particlesRef.current;
      // 40 colored particles
      for (let i = 0; i < 40; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 1 + Math.random() * 4;
        particles.push({
          x, y,
          vx: Math.cos(angle) * speed * (radius / 50),
          vy: Math.sin(angle) * speed * (radius / 50),
          life: 1,
          maxLife: 0.8 + Math.random() * 0.8,
          color: Math.random() > 0.5 ? color : color2,
          size: 2 + Math.random() * 4,
        });
      }
      // 20 white particles
      for (let i = 0; i < 20; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 2 + Math.random() * 3;
        particles.push({
          x, y,
          vx: Math.cos(angle) * speed * (radius / 50),
          vy: Math.sin(angle) * speed * (radius / 50) - 1,
          life: 1,
          maxLife: 0.6 + Math.random() * 0.6,
          color: '#ffffff',
          size: 1 + Math.random() * 2,
        });
      }
    };

    canvas.addEventListener('mousedown', handleDown);
    canvas.addEventListener('mousemove', handleMove);
    canvas.addEventListener('mouseup', handleUp);
    canvas.addEventListener('mouseleave', handleUp);
    canvas.addEventListener('touchstart', handleDown, { passive: true });
    canvas.addEventListener('touchmove', handleMove, { passive: true });
    canvas.addEventListener('touchend', handleUp);

    // ─── Animation Loop ───
    const draw = () => {
      timeRef.current += 0.016;
      const t = timeRef.current;

      syncBubbles();

      ctx.clearRect(0, 0, width, height);
      const map = internalRef.current;

      for (const [id, b] of map) {
        // Floating physics
        if (!b.popped && id !== mouseRef.current.dragBubbleId) {
          b.renderX += Math.sin(t * 0.3 + b.wobblePhase) * 0.3;
          b.renderY += Math.cos(t * 0.25 + b.wobblePhase * 1.3) * 0.2;

          // Boundary bounce
          const margin = b.renderRadius;
          if (b.renderX < margin) b.renderX = margin;
          if (b.renderX > width - margin) b.renderX = width - margin;
          if (b.renderY < margin) b.renderY = margin;
          if (b.renderY > height - margin) b.renderY = height - margin;
        }

        // Pop animation
        if (b.popped) {
          b.popProgress = Math.min(1, b.popProgress + 0.04);
          if (b.popProgress >= 1) continue; // Don't render fully popped
        }

        const bx = b.renderX;
        const by = b.renderY;
        let br = b.renderRadius;

        // Wobble
        const wobbleT = t * b.wobbleSpeed + b.wobblePhase;
        const scaleX = 1 + Math.sin(wobbleT) * 0.04;
        const scaleY = 1 + Math.cos(wobbleT * 1.1) * 0.04;
        const skew = Math.sin(wobbleT * 0.7) * 0.02;

        // Pop shrink
        if (b.popped) {
          const shrink = 1 - b.popProgress;
          br *= shrink;
          if (br < 1) continue;
        }

        const hoverScale = b.hover ? 1.08 : 1;
        br *= hoverScale;

        ctx.save();
        ctx.translate(bx, by);
        ctx.transform(scaleX, skew, -skew, scaleY, 0, 0);

        // ── Outer glow ──
        const glowGrad = ctx.createRadialGradient(0, 0, br * 0.8, 0, 0, br * 1.4);
        glowGrad.addColorStop(0, 'transparent');
        glowGrad.addColorStop(0.6, `${b.color}15`);
        glowGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = glowGrad;
        ctx.beginPath();
        ctx.arc(0, 0, br * 1.4, 0, Math.PI * 2);
        ctx.fill();

        // ── Bubble film (radial gradient with iridescence) ──
        const filmGrad = ctx.createRadialGradient(-br * 0.3, -br * 0.3, 0, 0, 0, br);
        const alphaBase = b.popped ? (1 - b.popProgress) * 0.25 : 0.25;
        filmGrad.addColorStop(0, `${b.color}${Math.round(alphaBase * 255 * 0.5).toString(16).padStart(2, '0')}`);
        filmGrad.addColorStop(0.3, `${b.color2}${Math.round(alphaBase * 255 * 0.3).toString(16).padStart(2, '0')}`);
        filmGrad.addColorStop(0.7, `${b.color}${Math.round(alphaBase * 255 * 0.15).toString(16).padStart(2, '0')}`);
        filmGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = filmGrad;
        ctx.beginPath();
        ctx.arc(0, 0, br, 0, Math.PI * 2);
        ctx.fill();

        // ── Fresnel rim effect ──
        const rimGrad = ctx.createRadialGradient(0, 0, br * 0.5, 0, 0, br);
        rimGrad.addColorStop(0, 'transparent');
        rimGrad.addColorStop(0.7, 'transparent');
        rimGrad.addColorStop(0.9, `${b.color}40`);
        rimGrad.addColorStop(1, `${b.color2}60`);
        ctx.fillStyle = rimGrad;
        ctx.beginPath();
        ctx.arc(0, 0, br, 0, Math.PI * 2);
        ctx.fill();

        // ── Chromatic aberration (RGB offset at edges) ──
        const caOffset = br * 0.02;
        ctx.globalCompositeOperation = 'screen';
        // Red channel
        ctx.beginPath();
        ctx.arc(-caOffset, 0, br, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(255, 100, 100, ${alphaBase * 0.3})`;
        ctx.lineWidth = 2;
        ctx.stroke();
        // Blue channel
        ctx.beginPath();
        ctx.arc(caOffset, 0, br, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(100, 100, 255, ${alphaBase * 0.3})`;
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.globalCompositeOperation = 'source-over';

        // ── Caustics (light patterns on surface) ──
        const causticAngle = t * 0.5 + b.wobblePhase;
        const cx1 = Math.cos(causticAngle) * br * 0.3;
        const cy1 = Math.sin(causticAngle) * br * 0.3;
        const causticGrad = ctx.createRadialGradient(cx1, cy1, 0, cx1, cy1, br * 0.35);
        causticGrad.addColorStop(0, `rgba(255, 255, 255, ${alphaBase * 0.4})`);
        causticGrad.addColorStop(0.5, `rgba(200, 240, 255, ${alphaBase * 0.1})`);
        causticGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = causticGrad;
        ctx.beginPath();
        ctx.arc(cx1, cy1, br * 0.35, 0, Math.PI * 2);
        ctx.fill();

        // ── Secondary caustic ──
        const cx2 = Math.cos(causticAngle * 0.7 + 2) * br * 0.25;
        const cy2 = Math.sin(causticAngle * 0.7 + 2) * br * 0.25;
        const caustic2Grad = ctx.createRadialGradient(cx2, cy2, 0, cx2, cy2, br * 0.2);
        caustic2Grad.addColorStop(0, `rgba(255, 230, 200, ${alphaBase * 0.2})`);
        caustic2Grad.addColorStop(1, 'transparent');
        ctx.fillStyle = caustic2Grad;
        ctx.beginPath();
        ctx.arc(cx2, cy2, br * 0.2, 0, Math.PI * 2);
        ctx.fill();

        // ── Specular highlight ──
        const specX = -br * 0.25 + Math.sin(t * 0.3) * br * 0.05;
        const specY = -br * 0.3 + Math.cos(t * 0.3) * br * 0.05;
        const specGrad = ctx.createRadialGradient(specX, specY, 0, specX, specY, br * 0.2);
        specGrad.addColorStop(0, `rgba(255, 255, 255, ${b.popped ? (1 - b.popProgress) * 0.7 : 0.7})`);
        specGrad.addColorStop(0.5, `rgba(255, 255, 255, ${b.popped ? (1 - b.popProgress) * 0.2 : 0.2})`);
        specGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = specGrad;
        ctx.beginPath();
        ctx.arc(specX, specY, br * 0.2, 0, Math.PI * 2);
        ctx.fill();

        // ── Bubble border ──
        ctx.beginPath();
        ctx.arc(0, 0, br, 0, Math.PI * 2);
        ctx.strokeStyle = `${b.color}${Math.round((b.popped ? (1 - b.popProgress) : 1) * 80).toString(16).padStart(2, '0')}`;
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // ── Label ──
        if (!b.popped) {
          ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
          ctx.font = `bold ${Math.max(12, br * 0.22)}px "Segoe UI", "Arial", sans-serif`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.shadowColor = b.color;
          ctx.shadowBlur = 8;
          ctx.fillText(b.label, 0, 0);
          ctx.shadowBlur = 0;

          // Items count
          ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
          ctx.font = `${Math.max(9, br * 0.14)}px "Segoe UI", "Arial", sans-serif`;
          ctx.fillText(`${b.items.length} عناصر`, 0, br * 0.25);
        }

        ctx.restore();
      }

      // ── Particles ──
      const particles = particlesRef.current;
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.05; // gravity
        p.vx *= 0.99;
        p.life -= 0.016 / p.maxLife;

        if (p.life <= 0) {
          particles.splice(i, 1);
          continue;
        }

        ctx.globalAlpha = p.life;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      animFrameRef.current = requestAnimationFrame(draw);
    };

    animFrameRef.current = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(animFrameRef.current);
      window.removeEventListener('resize', resize);
      canvas.removeEventListener('mousedown', handleDown);
      canvas.removeEventListener('mousemove', handleMove);
      canvas.removeEventListener('mouseup', handleUp);
      canvas.removeEventListener('mouseleave', handleUp);
      canvas.removeEventListener('touchstart', handleDown);
      canvas.removeEventListener('touchmove', handleMove);
      canvas.removeEventListener('touchend', handleUp);
    };
  }, [bubbles, onBubbleClick, onBubblePop, onBubbleDrag, syncBubbles]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: 15,
        cursor: 'pointer',
      }}
    />
  );
}

'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { useJasemStore } from '@/lib/jasem-store';
import SpaceBackground from '@/components/space-background';
import SoapBubbleCanvas from '@/components/soap-bubble-canvas';
import SoapWindow from '@/components/soap-window';
import ChatInterface from '@/components/chat-interface';
import MinimizedDock from '@/components/minimized-dock';

// Session ID for chat
let chatSessionId: string | null = null;

// Fetch real data from APIs on mount
let currentUserId: string | null = null;

async function fetchInitialData() {
  try {
    // First get merchants to find a real user ID
    const merchantsRes = await fetch('/api/merchants');
    const merchantsData = await merchantsRes.json();
    const merchants = merchantsData.merchants || merchantsData || [];
    if (merchants.length > 0) {
      currentUserId = merchants[0].id;
    }

    const [productsRes, walletRes, analyticsRes] = await Promise.all([
      fetch('/api/products?limit=6'),
      fetch(`/api/wallet?userId=${currentUserId || 'demo'}`),
      fetch(`/api/analytics?userId=${currentUserId || 'demo'}`),
    ]);
    
    const productsData = await productsRes.json();
    const walletData = await walletRes.json();
    const analyticsData = await analyticsRes.json();
    
    return {
      products: productsData.products || [],
      wallet: walletData.wallet || null,
      analytics: analyticsData.summary || null,
    };
  } catch {
    return { products: [], wallet: null, analytics: null };
  }
}

export default function JasemPage() {
  const store = useJasemStore();
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);

  // ─── Bubble interaction handlers ───
  const handleBubbleClick = useCallback((id: string) => {
    store.openWindow(id);
  }, [store]);

  const handleBubblePop = useCallback((id: string) => {
    store.popBubble(id);
    // Respawn after 3 seconds
    setTimeout(() => {
      store.respawnBubble(id);
    }, 3000);
  }, [store]);

  const handleBubbleDrag = useCallback((_id: string, _x: number, _y: number) => {
    // Bubble position updated in canvas internals
  }, []);

  // ─── Chat handlers ───
  const handleSendMessage = useCallback(async (content: string) => {
    store.addMessage(content, 'user');
    store.setChatLoading(true);

    try {
      // Call real AI chat API
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: content,
          sessionId: chatSessionId,
          userId: currentUserId || 'demo',
        }),
      });
      
      const data = await res.json();
      if (data.sessionId) chatSessionId = data.sessionId;
      
      const aiText = data.message || 'عذراً، لم أتمكن من معالجة طلبك. حاول مرة أخرى.';
      const suggestions = data.suggestions || ['عرض الإعلانات', 'حالة المحفظة', 'تحليلات المبيعات'];
      store.addMessage(aiText, 'ai', suggestions);
    } catch {
      // Fallback response
      store.addMessage('عذراً، حدث خطأ في الاتصال. سأحاول مرة أخرى.', 'ai');
    } finally {
      store.setChatLoading(false);
    }
  }, [store]);

  // ─── Window handlers ───
  const handleWindowClose = useCallback((windowId: string) => {
    store.closeWindow(windowId);
  }, [store]);

  const handleWindowMinimize = useCallback((windowId: string) => {
    store.minimizeWindow(windowId);
  }, [store]);

  const handleWindowMaximize = useCallback((windowId: string) => {
    store.maximizeWindow(windowId);
  }, [store]);

  const handleWindowSnap = useCallback((windowId: string, state: 'snapped-left' | 'snapped-right' | 'maximized') => {
    store.snapWindow(windowId, state);
  }, [store]);

  const handleWindowUpdate = useCallback((windowId: string, updates: { x?: number; y?: number; width?: number; height?: number; state?: string }) => {
    store.updateWindow(windowId, updates);
  }, [store]);

  const handleWindowFocus = useCallback((windowId: string) => {
    store.bringToFront(windowId);
  }, [store]);

  const handleDockRestore = useCallback((windowId: string) => {
    store.restoreWindow(windowId);
  }, [store]);

  // ─── Animated title gradient ───
  useEffect(() => {
    const el = titleRef.current;
    if (!el) return;
    let angle = 0;
    const interval = setInterval(() => {
      angle = (angle + 1) % 360;
      el.style.backgroundImage = `linear-gradient(${angle}deg, #00d4ff, #a855f7, #ec4899, #FFD700, #00d4ff)`;
    }, 30);
    return () => clearInterval(interval);
  }, []);

  // ─── Fetch real data on mount ───
  useEffect(() => {
    fetchInitialData().then((data) => {
      if (data.wallet) {
        store.updateWallet({
          balance: data.wallet.balance || 0,
          pending: data.wallet.pending || 0,
          currency: data.wallet.currency || 'د.ك',
        });
      }
      if (data.analytics) {
        store.updateAnalytics({
          views: data.analytics.totalViews || data.analytics.views || 0,
          sales: data.analytics.totalPurchases || data.analytics.sales || 0,
          avgOrder: data.analytics.avgOrderValue || data.analytics.avgOrder || 0,
          roi: data.analytics.roi || 0,
        });
      }
      // Add product bubbles dynamically
      if (data.products && data.products.length > 0) {
        const productItems = data.products.slice(0, 4).map((p: any) => ({
          title: p.nameAr || p.name,
          value: `${p.price} ${p.currency}`,
          trend: p.rating > 3 ? 'up' as const : 'neutral' as const,
          progress: Math.min(p.views / 100, 1),
        }));
        store.updateBubble('bubble-suggestions', {
          items: productItems.length > 0 ? productItems : store.bubbles.find(b => b.id === 'bubble-suggestions')?.items || [],
        });
      }
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Get non-minimized windows and dock items
  const visibleWindows = store.windows.filter(w => w.state !== 'minimized');
  const dockItems = store.getDockItems();

  return (
    <div
      className="fixed inset-0 overflow-hidden bg-black"
      style={{ direction: 'rtl', lang: 'ar' }}
      suppressHydrationWarning
    >
      {/* Layer 0: Space Background */}
      <SpaceBackground />

      {/* Layer 15: Soap Bubble Canvas */}
      <SoapBubbleCanvas
        bubbles={store.bubbles}
        onBubbleClick={handleBubbleClick}
        onBubblePop={handleBubblePop}
        onBubbleDrag={handleBubbleDrag}
      />

      {/* Layer 10: Chat Interface (centered) */}
      <div
        className="fixed inset-0 flex flex-col pointer-events-none"
        style={{ zIndex: 20 }}
      >
        {/* Floating Title */}
        <div className="flex justify-center pt-4 pointer-events-auto">
          <div className="relative">
            {/* Title glow */}
            <div
              className="absolute inset-0 blur-xl opacity-30"
              style={{
                backgroundImage: 'linear-gradient(0deg, #00d4ff, #a855f7, #ec4899, #FFD700)',
              }}
            />
            <h1
              ref={titleRef}
              className="relative text-5xl font-black bg-clip-text text-transparent select-none"
              style={{
                backgroundImage: 'linear-gradient(0deg, #00d4ff, #a855f7, #ec4899, #FFD700, #00d4ff)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                textShadow: '0 0 40px rgba(0, 212, 255, 0.3)',
                letterSpacing: '0.05em',
              }}
            >
              جاسم
            </h1>
            <p className="text-center text-xs text-white/30 mt-1 select-none font-light">
              سوقك الذكي ثنائي الاتجاه
            </p>
          </div>
        </div>

        {/* Chat Container */}
        <div
          ref={chatContainerRef}
          className="flex-1 mx-auto w-full max-w-2xl mt-2 mb-0 pointer-events-auto"
          style={{
            background: 'rgba(5, 10, 25, 0.5)',
            backdropFilter: 'blur(12px)',
            borderRadius: '16px 16px 0 0',
            border: '1px solid rgba(255, 255, 255, 0.06)',
            borderBottom: 'none',
            maxHeight: 'calc(100vh - 120px)',
          }}
        >
          <ChatInterface
            messages={store.messages}
            onSendMessage={handleSendMessage}
            isLoading={store.chatLoading}
            suggestions={[]}
          />
        </div>
      </div>

      {/* Layer 100: Soap Windows */}
      {visibleWindows.map(w => (
        <SoapWindow
          key={w.id}
          id={w.id}
          label={w.label}
          description={w.description}
          items={w.items}
          color={w.color}
          color2={w.color2}
          icon={w.icon}
          state={w.state}
          x={w.x}
          y={w.y}
          width={w.width}
          height={w.height}
          zIndex={w.zIndex}
          onClose={() => handleWindowClose(w.id)}
          onMinimize={() => handleWindowMinimize(w.id)}
          onMaximize={() => handleWindowMaximize(w.id)}
          onSnap={(state) => handleWindowSnap(w.id, state as 'snapped-left' | 'snapped-right' | 'maximized')}
          onUpdate={(updates) => handleWindowUpdate(w.id, updates)}
          onFocus={() => handleWindowFocus(w.id)}
        />
      ))}

      {/* Layer 150: Minimized Dock */}
      <MinimizedDock
        items={dockItems}
        onRestore={handleDockRestore}
      />
    </div>
  );
}

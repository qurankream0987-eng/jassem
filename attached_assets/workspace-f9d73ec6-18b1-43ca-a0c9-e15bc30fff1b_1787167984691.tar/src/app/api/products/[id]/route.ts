import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/products/[id] — Single product with merchant info and reviews
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const product = await db.product.findUnique({
      where: { id },
      include: {
        merchant: {
          select: {
            id: true,
            name: true,
            avatar: true,
            bio: true,
            location: true,
            dnaFitness: true,
            products: {
              where: { isActive: true },
              select: { id: true, name: true, nameAr: true, price: true, images: true, rating: true },
              take: 5,
            },
          },
        },
        reviews: {
          include: {
            user: {
              select: { id: true, name: true, avatar: true },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!product) {
      return NextResponse.json({ error: 'المنتج غير موجود' }, { status: 404 });
    }

    // Increment view count
    await db.product.update({
      where: { id },
      data: { views: { increment: 1 } },
    });

    // Calculate average rating from reviews
    const avgRating =
      product.reviews.length > 0
        ? product.reviews.reduce((sum, r) => sum + r.rating, 0) / product.reviews.length
        : product.rating;

    return NextResponse.json({
      product: { ...product, avgRating: Math.round(avgRating * 10) / 10 },
    });
  } catch (error) {
    console.error('Error getting product:', error);
    return NextResponse.json(
      { error: 'فشل في تحميل المنتج', details: String(error) },
      { status: 500 }
    );
  }
}

// PUT /api/products/[id] — Update product
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    // Check product exists
    const existing = await db.product.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'المنتج غير موجود' }, { status: 404 });
    }

    // Prepare update data
    const updateData: Record<string, unknown> = {};
    const allowedFields = [
      'name', 'nameAr', 'description', 'descriptionAr', 'price', 'currency',
      'category', 'stock', 'isActive', 'isFeatured', 'bubbleColor', 'bubbleColor2',
      'bubbleRadius', 'bubblePosition',
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        updateData[field] = body[field];
      }
    }

    // Handle JSON fields
    if (body.tags !== undefined) {
      updateData.tags = JSON.stringify(body.tags);
    }
    if (body.images !== undefined) {
      updateData.images = JSON.stringify(body.images);
    }

    // Parse numeric fields
    if (updateData.price !== undefined) {
      updateData.price = parseFloat(updateData.price as string);
    }
    if (updateData.stock !== undefined) {
      updateData.stock = parseInt(updateData.stock as string);
    }

    const product = await db.product.update({
      where: { id },
      data: updateData,
      include: {
        merchant: {
          select: { id: true, name: true, avatar: true },
        },
      },
    });

    return NextResponse.json({ product });
  } catch (error) {
    console.error('Error updating product:', error);
    return NextResponse.json(
      { error: 'فشل في تحديث المنتج', details: String(error) },
      { status: 500 }
    );
  }
}

// DELETE /api/products/[id] — Delete product
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    // Check product exists
    const existing = await db.product.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'المنتج غير موجود' }, { status: 404 });
    }

    // Soft delete — set isActive to false
    await db.product.update({
      where: { id },
      data: { isActive: false },
    });

    return NextResponse.json({ success: true, message: 'تم حذف المنتج بنجاح' });
  } catch (error) {
    console.error('Error deleting product:', error);
    return NextResponse.json(
      { error: 'فشل في حذف المنتج', details: String(error) },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/products — List products with filtering
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const search = searchParams.get('search');
    const merchantId = searchParams.get('merchantId');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');
    const sortBy = searchParams.get('sortBy') || 'createdAt';
    const sortOrder = searchParams.get('sortOrder') || 'desc';

    // Build where clause
    const where: Record<string, unknown> = { isActive: true };

    if (category) {
      where.category = category;
    }

    if (merchantId) {
      where.merchantId = merchantId;
    }

    if (search) {
      where.OR = [
        { name: { contains: search } },
        { nameAr: { contains: search } },
        { description: { contains: search } },
        { descriptionAr: { contains: search } },
        { tags: { contains: search } },
        { aiTags: { contains: search } },
      ];
    }

    // Get total count
    const total = await db.product.count({ where });

    // Get products with merchant info
    const products = await db.product.findMany({
      where,
      include: {
        merchant: {
          select: {
            id: true,
            name: true,
            avatar: true,
            dnaFitness: true,
            location: true,
          },
        },
        reviews: {
          select: { rating: true },
        },
      },
      orderBy: { [sortBy]: sortOrder === 'asc' ? 'asc' : 'desc' },
      take: limit,
      skip: offset,
    });

    // Calculate average rating for each product
    const productsWithRating = products.map((product) => {
      const avgRating =
        product.reviews.length > 0
          ? product.reviews.reduce((sum, r) => sum + r.rating, 0) / product.reviews.length
          : product.rating;
      const { reviews, ...rest } = product;
      return { ...rest, avgRating: Math.round(avgRating * 10) / 10 };
    });

    return NextResponse.json({
      products: productsWithRating,
      total,
      limit,
      offset,
      hasMore: offset + limit < total,
    });
  } catch (error) {
    console.error('Error listing products:', error);
    return NextResponse.json(
      { error: 'فشل في تحميل المنتجات', details: String(error) },
      { status: 500 }
    );
  }
}

// POST /api/products — Create new product with AI-generated tags and summary
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      name,
      nameAr,
      description,
      descriptionAr,
      price,
      currency = 'KWD',
      category,
      tags = [],
      images = [],
      stock = 0,
      merchantId,
      bubbleColor = '#00d4ff',
      bubbleColor2 = '#4a9eff',
      bubbleRadius = 65,
      isFeatured = false,
    } = body;

    // Validate required fields
    if (!name || !description || price === undefined || !category || !merchantId) {
      return NextResponse.json(
        { error: 'الحقول المطلوبة: الاسم، الوصف، السعر، الفئة، معرف التاجر' },
        { status: 400 }
      );
    }

    // AI-generated tags and summary
    let aiTags: string[] = [];
    let aiSummary: string | null = null;

    try {
      const ZAI = (await import('z-ai-web-dev-sdk')).default;
      const zai = await ZAI.create();

      // Generate AI tags and summary in parallel
      const [tagsResult, summaryResult] = await Promise.allSettled([
        zai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content:
                'أنت مساعد لتوليد وسوم للمنتجات. أجب بقائمة وسوم مفصولة بفواصل فقط، بدون شرح إضافي. مثال: إلكترونيات,هاتف,ذكي',
            },
            {
              role: 'user',
              content: `ولّد وسوم لهذا المنتج:\nالاسم: ${name}\n${nameAr ? `الاسم العربي: ${nameAr}` : ''}\nالوصف: ${description}\nالفئة: ${category}\nالسعر: ${price} ${currency}`,
            },
          ],
          thinking: { type: 'disabled' },
        }),
        zai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content:
                'أنت مساعد لتوليد ملخصات منتجات. أجب بملخص قصير (3-4 جمل) باللغة العربية يصف المنتج وأهم مميزاته. بدون تنسيق خاص.',
            },
            {
              role: 'user',
              content: `لخص هذا المنتج:\nالاسم: ${name}\n${nameAr ? `الاسم العربي: ${nameAr}` : ''}\nالوصف: ${description}\n${descriptionAr ? `الوصف العربي: ${descriptionAr}` : ''}\nالفئة: ${category}\nالسعر: ${price} ${currency}`,
            },
          ],
          thinking: { type: 'disabled' },
        }),
      ]);

      if (tagsResult.status === 'fulfilled') {
        const tagsText = tagsResult.value.choices[0]?.message?.content || '';
        aiTags = tagsText
          .split(',')
          .map((t: string) => t.trim())
          .filter((t: string) => t.length > 0)
          .slice(0, 10);
      }

      if (summaryResult.status === 'fulfilled') {
        aiSummary = summaryResult.value.choices[0]?.message?.content || null;
      }
    } catch (aiError) {
      console.warn('AI generation failed, continuing without:', aiError);
    }

    // Create product
    const product = await db.product.create({
      data: {
        name,
        nameAr,
        description,
        descriptionAr,
        price: parseFloat(price),
        currency,
        category,
        tags: JSON.stringify(tags),
        images: JSON.stringify(images),
        stock: parseInt(stock),
        merchantId,
        bubbleColor,
        bubbleColor2,
        bubbleRadius,
        isFeatured,
        aiTags: JSON.stringify(aiTags),
        aiSummary,
      },
      include: {
        merchant: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json({ product, aiTags, aiSummary }, { status: 201 });
  } catch (error) {
    console.error('Error creating product:', error);
    return NextResponse.json(
      { error: 'فشل في إنشاء المنتج', details: String(error) },
      { status: 500 }
    );
  }
}

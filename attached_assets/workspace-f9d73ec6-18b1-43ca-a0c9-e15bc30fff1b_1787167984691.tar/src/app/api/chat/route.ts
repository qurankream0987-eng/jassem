import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/chat — Send message and get AI response
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { message, sessionId, userId, context } = body;

    if (!message) {
      return NextResponse.json(
        { error: 'الرسالة مطلوبة' },
        { status: 400 }
      );
    }

    // Find or create a user (use a default if no userId provided)
    let user = userId
      ? await db.user.findUnique({ where: { id: userId } })
      : null;

    if (!user) {
      // Create anonymous user if needed
      user = await db.user.create({
        data: {
          name: 'زائر',
          email: `visitor_${Date.now()}@jasem.ai`,
          role: 'customer',
        },
      });
    }

    // Find or create chat session
    let session;
    if (sessionId) {
      session = await db.chatSession.findUnique({ where: { id: sessionId } });
    }

    if (!session) {
      // Detect session type from context or message
      const sessionType = detectSessionType(message, context);
      session = await db.chatSession.create({
        data: {
          userId: user.id,
          type: sessionType,
          title: message.substring(0, 50),
          context: context ? JSON.stringify(context) : null,
        },
      });
    }

    // Save user message
    await db.message.create({
      data: {
        content: message,
        role: 'user',
        type: 'text',
        sessionId: session.id,
        userId: user.id,
      },
    });

    // Get recent conversation history for context
    const recentMessages = await db.message.findMany({
      where: { sessionId: session.id },
      orderBy: { createdAt: 'desc' },
      take: 10,
    });

    // Build conversation messages for LLM
    const conversationMessages = recentMessages
      .reverse()
      .map((m) => ({
        role: m.role as 'user' | 'assistant' | 'system',
        content: m.content,
      }));

    // Build context-aware system prompt
    const systemPrompt = await buildSystemPrompt(user.id, context);

    // Generate AI response
    let aiResponse: string;
    let suggestions: string[] = [];

    try {
      const ZAI = (await import('z-ai-web-dev-sdk')).default;
      const zai = await ZAI.create();

      const completion = await zai.chat.completions.create({
        messages: [
          { role: 'system', content: systemPrompt },
          ...conversationMessages,
        ],
        thinking: { type: 'disabled' },
      });

      aiResponse = completion.choices[0]?.message?.content || 'عذراً، لم أتمكن من معالجة طلبك.';

      // Generate suggestions based on the conversation
      try {
        const suggestionsCompletion = await zai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content:
                'أنت مساعد في سوق جاسم. اقترح 3 أسئلة أو أفعال قصيرة مفصولة بـ | فقط، بدون أرقام أو شرح. مثال: اعرض لي المنتجات|ابحث عن هاتف|كيف أشتري',
            },
            { role: 'user', content: `بناءً على: "${message}" ورد: "${aiResponse}"` },
          ],
          thinking: { type: 'disabled' },
        });

        const suggestionsText = suggestionsCompletion.choices[0]?.message?.content || '';
        suggestions = suggestionsText
          .split('|')
          .map((s: string) => s.trim())
          .filter((s: string) => s.length > 0)
          .slice(0, 3);
      } catch {
        // Suggestions are optional
      }
    } catch (aiError) {
      console.error('AI generation failed:', aiError);
      aiResponse = generateFallbackResponse(message);
      suggestions = ['تصفح المنتجات', 'البحث عن تاجر', 'كيف أشتري؟'];
    }

    // Save AI message
    await db.message.create({
      data: {
        content: aiResponse,
        role: 'assistant',
        type: 'text',
        sessionId: session.id,
        metadata: suggestions.length > 0 ? JSON.stringify({ suggestions }) : null,
      },
    });

    // Update session
    await db.chatSession.update({
      where: { id: session.id },
      data: { updatedAt: new Date() },
    });

    return NextResponse.json({
      message: aiResponse,
      sessionId: session.id,
      userId: user.id,
      suggestions,
    });
  } catch (error) {
    console.error('Error in chat:', error);
    return NextResponse.json(
      { error: 'فشل في معالجة الرسالة', details: String(error) },
      { status: 500 }
    );
  }
}

// Detect session type from message content
function detectSessionType(message: string, context?: Record<string, unknown>): string {
  const lower = message.toLowerCase();

  if (context?.type) return String(context.type);

  if (lower.includes('منتج') || lower.includes('سعر') || lower.includes('product')) {
    return 'product_inquiry';
  }
  if (lower.includes('شكوى') || lower.includes('مشكلة') || lower.includes('support')) {
    return 'support';
  }
  if (lower.includes('صفقة') || lower.includes('تخفيض') || lower.includes('deal')) {
    return 'deal';
  }
  return 'general';
}

// Build context-aware system prompt
async function buildSystemPrompt(userId: string, context?: Record<string, unknown>): Promise<string> {
  let prompt = `جاسم هو مساعد ذكي للسوق العربي. أنت جاسم، مساعد افتراضي لسوق "جاسم" — السوق العربي الذكي.

دورك:
- مساعدة الزبائين في البحث عن المنتجات والمقارنة بينها
- تقديم معلومات عن التاجرين والمنتجات
- مساعدة في عملية الشراء والطلب
- الإجابة على الأسئلة باللغة العربية بشكل أساسي
- تقديم اقتراحات ذكية بناءً على تفضيلات المستخدم

قواعد:
- أجب باللغة العربية ما لم يطلب المستخدم لغة أخرى
- كن مختصراً ومفيداً
- استخدم العملة الكويتية (د.ك) كعملة افتراضية
- قدم معلومات دقيقة فقط
- إذا سُئلت عن منتج محدد، حاول تقديم معلومات مفصلة`;

  // Add user DNA context if available
  try {
    const user = await db.user.findUnique({
      where: { id: userId },
      select: { dnaProfile: true, dnaGeneration: true },
    });

    if (user?.dnaProfile) {
      const dna = JSON.parse(user.dnaProfile);
      prompt += `\n\nتفضيلات المستخدم (الجيل ${user.dnaGeneration}): ${JSON.stringify(dna)}`;
    }
  } catch {
    // DNA context is optional
  }

  // Add external context
  if (context) {
    prompt += `\n\nسياق إضافي: ${JSON.stringify(context)}`;
  }

  return prompt;
}

// Fallback response when AI is unavailable
function generateFallbackResponse(message: string): string {
  const lower = message.toLowerCase();

  if (lower.includes('منتج') || lower.includes('product')) {
    return 'يمكنك تصفح المنتجات المتاحة في السوق. ابحث عن منتج محدد أو تصفح حسب الفئة.';
  }
  if (lower.includes('سعر') || lower.includes('price')) {
    return 'يمكنني مساعدتك في مقارنة الأسعار. ابحث عن منتج لعرض الأسعار من مختلف التاجرين.';
  }
  if (lower.includes('تاجر') || lower.includes('merchant')) {
    return 'يمكنك عرض قائمة التاجرين المتاحين وتقييماتهم. هل تبحث عن تاجر محدد؟';
  }
  if (lower.includes('شراء') || lower.includes('buy')) {
    return 'لشراء منتج، ابحث عنه أولاً ثم أضفه إلى سلة المشتريات. سأرشدك خطوة بخطوة.';
  }
  if (lower.includes('مساعدة') || lower.includes('help')) {
    return 'مرحباً! أنا جاسم، مساعدك الذكي. يمكنني مساعدتك في:\n- البحث عن المنتجات\n- مقارنة الأسعار\n- التعرف على التاجرين\n- إتمام عملية الشراء\nكيف يمكنني مساعدتك؟';
  }
  return 'مرحباً! أنا جاسم، مساعدك في السوق العربي. كيف يمكنني مساعدتك اليوم؟ يمكنك سؤالي عن المنتجات، الأسعار، أو التاجرين.';
}

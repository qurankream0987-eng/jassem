import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/merchants — List merchants with product count and ratings
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: Record<string, unknown> = { role: 'merchant' };

    if (search) {
      where.OR = [
        { name: { contains: search } },
        { email: { contains: search } },
        { location: { contains: search } },
      ];
    }

    const total = await db.user.count({ where });

    const merchants = await db.user.findMany({
      where,
      select: {
        id: true,
        name: true,
        email: true,
        avatar: true,
        bio: true,
        location: true,
        dnaFitness: true,
        createdAt: true,
        products: {
          where: { isActive: true },
          select: {
            id: true,
            name: true,
            nameAr: true,
            price: true,
            rating: true,
            reviewCount: true,
            category: true,
            images: true,
          },
        },
      },
      orderBy: { dnaFitness: 'desc' },
      take: limit,
      skip: offset,
    });

    // Enrich with product count and average rating
    const merchantsWithStats = merchants.map((merchant) => {
      const productCount = merchant.products.length;
      const avgProductRating =
        productCount > 0
          ? merchant.products.reduce((sum, p) => sum + p.rating, 0) / productCount
          : 0;
      const totalReviews = merchant.products.reduce((sum, p) => sum + p.reviewCount, 0);

      return {
        ...merchant,
        productCount,
        avgProductRating: Math.round(avgProductRating * 10) / 10,
        totalReviews,
      };
    });

    return NextResponse.json({
      merchants: merchantsWithStats,
      total,
      limit,
      offset,
      hasMore: offset + limit < total,
    });
  } catch (error) {
    console.error('Error listing merchants:', error);
    return NextResponse.json(
      { error: 'فشل في تحميل التاجرين', details: String(error) },
      { status: 500 }
    );
  }
}

// POST /api/merchants — Register as merchant
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, email, phone, avatar, bio, location } = body;

    if (!name || !email) {
      return NextResponse.json(
        { error: 'الحقول المطلوبة: الاسم، البريد الإلكتروني' },
        { status: 400 }
      );
    }

    // Check if email already exists
    const existing = await db.user.findUnique({ where: { email } });
    if (existing) {
      // If existing user, upgrade to merchant
      if (existing.role !== 'merchant') {
        const updated = await db.user.update({
          where: { email },
          data: { role: 'merchant', bio: bio || existing.bio, location: location || existing.location },
        });

        // Create wallet if not exists
        const existingWallet = await db.wallet.findUnique({ where: { userId: updated.id } });
        if (!existingWallet) {
          await db.wallet.create({ data: { userId: updated.id, balance: 0 } });
        }

        return NextResponse.json({
          user: updated,
          message: 'تم ترقية الحساب إلى تاجر بنجاح',
        });
      }
      return NextResponse.json(
        { error: 'يوجد تاجر مسجل بهذا البريد مسبقاً' },
        { status: 409 }
      );
    }

    // Create new merchant
    const merchant = await db.user.create({
      data: {
        name,
        email,
        phone,
        avatar,
        bio,
        location,
        role: 'merchant',
        dnaProfile: JSON.stringify({
          categories: [],
          priceRange: { min: 0, max: 1000 },
          preferences: {},
        }),
      },
    });

    // Create wallet for merchant
    await db.wallet.create({
      data: {
        userId: merchant.id,
        balance: 0,
        currency: 'KWD',
      },
    });

    return NextResponse.json(
      { user: merchant, message: 'تم تسجيل التاجر بنجاح' },
      { status: 201 }
    );
  } catch (error) {
    console.error('Error registering merchant:', error);
    return NextResponse.json(
      { error: 'فشل في تسجيل التاجر', details: String(error) },
      { status: 500 }
    );
  }
}

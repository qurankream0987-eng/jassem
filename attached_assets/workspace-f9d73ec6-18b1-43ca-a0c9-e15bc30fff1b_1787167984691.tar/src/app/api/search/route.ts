import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/search — Search products and merchants with web discovery
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get('q');
    const type = searchParams.get('type') || 'all'; // all, products, merchants, web
    const limit = parseInt(searchParams.get('limit') || '10');
    const category = searchParams.get('category');

    if (!query) {
      return NextResponse.json(
        { error: 'كلمة البحث مطلوبة' },
        { status: 400 }
      );
    }

    const results: {
      products: unknown[];
      merchants: unknown[];
      webResults: unknown[];
      totalLocal: number;
    } = {
      products: [],
      merchants: [],
      webResults: [],
      totalLocal: 0,
    };

    // Search local products
    if (type === 'all' || type === 'products') {
      const productWhere: Record<string, unknown> = {
        isActive: true,
        OR: [
          { name: { contains: query } },
          { nameAr: { contains: query } },
          { description: { contains: query } },
          { descriptionAr: { contains: query } },
          { tags: { contains: query } },
          { aiTags: { contains: query } },
          { category: { contains: query } },
        ],
      };

      if (category) {
        productWhere.category = category;
      }

      const products = await db.product.findMany({
        where: productWhere,
        include: {
          merchant: {
            select: { id: true, name: true, avatar: true, dnaFitness: true },
          },
          reviews: {
            select: { rating: true },
          },
        },
        take: limit,
        orderBy: { views: 'desc' },
      });

      results.products = products.map((p) => {
        const avgRating =
          p.reviews.length > 0
            ? p.reviews.reduce((sum, r) => sum + r.rating, 0) / p.reviews.length
            : p.rating;
        const { reviews, ...rest } = p;
        return { ...rest, avgRating: Math.round(avgRating * 10) / 10 };
      });
    }

    // Search local merchants
    if (type === 'all' || type === 'merchants') {
      const merchants = await db.user.findMany({
        where: {
          role: 'merchant',
          OR: [
            { name: { contains: query } },
            { bio: { contains: query } },
            { location: { contains: query } },
          ],
        },
        select: {
          id: true,
          name: true,
          avatar: true,
          bio: true,
          location: true,
          dnaFitness: true,
          products: {
            where: { isActive: true },
            select: { id: true, name: true, price: true, rating: true },
            take: 5,
          },
        },
        take: limit,
      });

      results.merchants = merchants.map((m) => ({
        ...m,
        productCount: m.products.length,
      }));
    }

    results.totalLocal = results.products.length + results.merchants.length;

    // Web search for discovery
    if (type === 'all' || type === 'web') {
      try {
        const ZAI = (await import('z-ai-web-dev-sdk')).default;
        const zai = await ZAI.create();

        const webResults = await zai.functions.invoke('web_search', {
          query: `${query} سوق عربي`,
          num: 5,
        });

        if (webResults && Array.isArray(webResults)) {
          results.webResults = webResults.map((r: Record<string, unknown>) => ({
            title: r.title || '',
            url: r.url || '',
            snippet: r.snippet || r.content || '',
            source: 'web',
          }));
        }
      } catch (webError) {
        console.warn('Web search failed:', webError);
        // Web search is optional — continue without it
      }
    }

    // Track search event
    try {
      await db.analyticsEvent.create({
        data: {
          event: 'search',
          data: JSON.stringify({ query, type, resultsCount: results.totalLocal }),
        },
      });
    } catch {
      // Analytics tracking is optional
    }

    return NextResponse.json({
      query,
      type,
      ...results,
    });
  } catch (error) {
    console.error('Error searching:', error);
    return NextResponse.json(
      { error: 'فشل في البحث', details: String(error) },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/wallet — Get wallet balance by userId
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { error: 'معرف المستخدم مطلوب' },
        { status: 400 }
      );
    }

    // Find or create wallet
    let wallet = await db.wallet.findUnique({
      where: { userId },
      include: {
        transactions: {
          orderBy: { createdAt: 'desc' },
          take: 20,
        },
        user: {
          select: { id: true, name: true, email: true },
        },
      },
    });

    if (!wallet) {
      // Check if user exists first
      const user = await db.user.findUnique({ where: { id: userId } });
      if (!user) {
        // Return default wallet for non-existent users
        return NextResponse.json({
          wallet: {
            userId,
            balance: 2450,
            pending: 350,
            currency: 'KWD',
            transactions: [],
          }
        });
      }
      // Create wallet for user if not exists
      wallet = await db.wallet.create({
        data: {
          userId,
          balance: 0,
          currency: 'KWD',
        },
        include: {
          transactions: {
            orderBy: { createdAt: 'desc' },
            take: 20,
          },
          user: {
            select: { id: true, name: true, email: true },
          },
        },
      });
    }

    return NextResponse.json({ wallet });
  } catch (error) {
    console.error('Error getting wallet:', error);
    return NextResponse.json(
      { error: 'فشل في تحميل المحفظة', details: String(error) },
      { status: 500 }
    );
  }
}

// POST /api/wallet — Create transaction (deposit, withdraw, payment)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, type, amount, reference } = body;

    if (!userId || !type || amount === undefined) {
      return NextResponse.json(
        { error: 'الحقول المطلوبة: معرف المستخدم، النوع، المبلغ' },
        { status: 400 }
      );
    }

    const validTypes = ['deposit', 'withdrawal', 'payment', 'refund'];
    if (!validTypes.includes(type)) {
      return NextResponse.json(
        { error: `نوع العملية غير صالح. الأنواع المسموحة: ${validTypes.join(', ')}` },
        { status: 400 }
      );
    }

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      return NextResponse.json(
        { error: 'المبلغ يجب أن يكون رقماً موجباً' },
        { status: 400 }
      );
    }

    // Find or create wallet
    let wallet = await db.wallet.findUnique({
      where: { userId },
      include: { transactions: true },
    });

    if (!wallet) {
      wallet = await db.wallet.create({
        data: { userId, balance: 0, currency: 'KWD' },
        include: { transactions: true },
      });
    }

    // Check balance for withdrawal/payment
    if ((type === 'withdrawal' || type === 'payment') && wallet.balance < parsedAmount) {
      return NextResponse.json(
        {
          error: 'رصيد غير كافي',
          balance: wallet.balance,
          required: parsedAmount,
        },
        { status: 400 }
      );
    }

    // Calculate new balance
    let newBalance: number;
    switch (type) {
      case 'deposit':
      case 'refund':
        newBalance = wallet.balance + parsedAmount;
        break;
      case 'withdrawal':
      case 'payment':
        newBalance = wallet.balance - parsedAmount;
        break;
      default:
        newBalance = wallet.balance;
    }

    // Create transaction and update wallet in a consistent manner
    const transaction = await db.transaction.create({
      data: {
        type,
        amount: parsedAmount,
        status: 'completed',
        reference: reference || null,
        walletId: wallet.id,
      },
    });

    // Update wallet balance
    const updatedWallet = await db.wallet.update({
      where: { id: wallet.id },
      data: { balance: newBalance },
      include: {
        transactions: {
          orderBy: { createdAt: 'desc' },
          take: 20,
        },
      },
    });

    return NextResponse.json({
      transaction,
      wallet: updatedWallet,
      message: getTransactionMessage(type, parsedAmount),
    });
  } catch (error) {
    console.error('Error creating transaction:', error);
    return NextResponse.json(
      { error: 'فشل في إنشاء العملية', details: String(error) },
      { status: 500 }
    );
  }
}

function getTransactionMessage(type: string, amount: number): string {
  switch (type) {
    case 'deposit':
      return `تم إيداع ${amount} د.ك بنجاح`;
    case 'withdrawal':
      return `تم سحب ${amount} د.ك بنجاح`;
    case 'payment':
      return `تم دفع ${amount} د.ك بنجاح`;
    case 'refund':
      return `تم استرداد ${amount} د.ك بنجاح`;
    default:
      return 'تمت العملية بنجاح';
  }
}

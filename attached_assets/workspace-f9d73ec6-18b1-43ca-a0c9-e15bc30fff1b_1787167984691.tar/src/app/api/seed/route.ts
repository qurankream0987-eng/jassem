import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/seed — Seed database with initial demo data
export async function POST() {
  try {
    // Check if data already exists
    const existingUsers = await db.user.count();
    if (existingUsers > 0) {
      return NextResponse.json({
        message: 'البيانات موجودة مسبقاً',
        counts: {
          users: existingUsers,
          products: await db.product.count(),
        },
      });
    }

    // ============ CREATE MERCHANTS ============
    const merchants = await Promise.all([
      db.user.create({
        data: {
          name: 'أحمد المطيري',
          email: 'ahmed@jasem.ai',
          phone: '+965-9001-0001',
          avatar: '',
          role: 'merchant',
          bio: 'متجر إلكترونيات متخصص في أحدث الأجهزة والهواتف الذكية',
          location: 'الكويت - السالمية',
          dnaProfile: JSON.stringify({
            categories: { electronics: 5, phones: 4 },
            priceRange: { min: 10, max: 500 },
          }),
          dnaFitness: 3.2,
        },
      }),
      db.user.create({
        data: {
          name: 'فاطمة الحربي',
          email: 'fatima@jasem.ai',
          phone: '+965-9001-0002',
          avatar: '',
          role: 'merchant',
          bio: 'أزياء وموضة عربية أصيلة — تصاميم تقليدية وعصرية',
          location: 'الكويت - الشرق',
          dnaProfile: JSON.stringify({
            categories: { clothing: 5, fashion: 4 },
            priceRange: { min: 5, max: 200 },
          }),
          dnaFitness: 4.1,
        },
      }),
      db.user.create({
        data: {
          name: 'خالد العتيبي',
          email: 'khaled@jasem.ai',
          phone: '+965-9001-0003',
          avatar: '',
          role: 'merchant',
          bio: 'مواد غذائية طازجة — من المزرعة إلى المائدة',
          location: 'الكويت - الفحيحيل',
          dnaProfile: JSON.stringify({
            categories: { food: 5, organic: 3 },
            priceRange: { min: 1, max: 50 },
          }),
          dnaFitness: 3.8,
        },
      }),
      db.user.create({
        data: {
          name: 'نورة الشمري',
          email: 'noura@jasem.ai',
          phone: '+965-9001-0004',
          avatar: '',
          role: 'merchant',
          bio: 'خدمات رقمية وتطوير مواقع — حلول تقنية متكاملة',
          location: 'الكويت - حولي',
          dnaProfile: JSON.stringify({
            categories: { services: 5, tech: 4 },
            priceRange: { min: 50, max: 2000 },
          }),
          dnaFitness: 4.5,
        },
      }),
      db.user.create({
        data: {
          name: 'محمد الدوسري',
          email: 'mohammed@jasem.ai',
          phone: '+965-9001-0005',
          avatar: '',
          role: 'merchant',
          bio: 'أثاث منزلي وديكور — لمسة عربية أنيقة لمنزلك',
          location: 'الكويت - الجابرية',
          dnaProfile: JSON.stringify({
            categories: { home: 5, furniture: 4 },
            priceRange: { min: 20, max: 800 },
          }),
          dnaFitness: 3.5,
        },
      }),
    ]);

    // Create demo customer
    const customer = await db.user.create({
      data: {
        name: 'سارة القحطاني',
        email: 'sara@jasem.ai',
        phone: '+965-9002-0001',
        role: 'customer',
        bio: 'مهتمة بالتسوق الإلكتروني والعروض',
        location: 'الكويت - السالمية',
        dnaProfile: JSON.stringify({
          categories: { electronics: 2, clothing: 1 },
          priceRange: { min: 5, max: 300 },
          preferences: {},
        }),
      },
    });

    // ============ CREATE WALLETS ============
    await Promise.all([
      ...merchants.map((m) =>
        db.wallet.create({
          data: { userId: m.id, balance: 1000, currency: 'KWD' },
        })
      ),
      db.wallet.create({
        data: { userId: customer.id, balance: 500, currency: 'KWD' },
      }),
    ]);

    // ============ CREATE PRODUCTS ============
    const productsData = [
      // Electronics (أحمد)
      { name: 'iPhone 15 Pro Max', nameAr: 'آيفون 15 برو ماكس', description: 'أحدث هاتف من آبل مع كاميرا 48 ميغابكسل وشريحة A17 Pro', price: 459, category: 'electronics', merchantId: merchants[0].id, stock: 25, isFeatured: true, bubbleColor: '#00d4ff', bubbleColor2: '#4a9eff' },
      { name: 'Samsung Galaxy S24 Ultra', nameAr: 'سامسونغ جالكسي S24 ألترا', description: 'هاتف رائد من سامسونغ مع قلم S Pen وكاميرا 200MP', price: 429, category: 'electronics', merchantId: merchants[0].id, stock: 30, isFeatured: true, bubbleColor: '#7c3aed', bubbleColor2: '#a78bfa' },
      { name: 'AirPods Pro 2', nameAr: 'إيربودز برو 2', description: 'سماعات لاسلكية مع إلغاء الضوضاء الفعال والصوت المكاني', price: 29, category: 'electronics', merchantId: merchants[0].id, stock: 100, bubbleColor: '#10b981', bubbleColor2: '#34d399' },
      { name: 'MacBook Air M3', nameAr: 'ماك بوك إير M3', description: 'حاسوب محمول خفيف مع شريحة M3 وشاشة 15 بوصة', price: 399, category: 'electronics', merchantId: merchants[0].id, stock: 15, isFeatured: true, bubbleColor: '#f59e0b', bubbleColor2: '#fbbf24' },
      { name: 'iPad Pro 12.9', nameAr: 'آيباد برو 12.9', description: 'جهاز لوحي احترافي مع شاشة Liquid Retina XDR وشريحة M2', price: 349, category: 'electronics', merchantId: merchants[0].id, stock: 20, bubbleColor: '#ef4444', bubbleColor2: '#f87171' },

      // Clothing (فاطمة)
      { name: 'عباية مطرزة فاخرة', nameAr: 'عباية مطرزة فاخرة', description: 'عباية أنيقة مع تطريز يدوي على الأكمام والجيب', price: 45, category: 'clothing', merchantId: merchants[1].id, stock: 50, isFeatured: true, bubbleColor: '#1d4ed8', bubbleColor2: '#60a5fa' },
      { name: 'ثوب قطري أصلي', nameAr: 'ثوب قطري أصلي', description: 'ثوب رجالي قطري من أجود أنواع القماش', price: 35, category: 'clothing', merchantId: merchants[1].id, stock: 80, bubbleColor: '#06b6d4', bubbleColor2: '#22d3ee' },
      { name: 'حجاب قطن مريح', nameAr: 'حجاب قطن مريح', description: 'حجاب من القطن المريح المتنفس — عدة ألوان', price: 5, category: 'clothing', merchantId: merchants[1].id, stock: 200, bubbleColor: '#8b5cf6', bubbleColor2: '#c084fc' },
      { name: 'فستان سهرة أنيق', nameAr: 'فستان سهرة أنيق', description: 'فستان سهرة مطلي بتصميم عربي حديث', price: 120, category: 'clothing', merchantId: merchants[1].id, stock: 15, isFeatured: true, bubbleColor: '#ec4899', bubbleColor2: '#f472b6' },
      { name: 'شماغ أحمر أصيل', nameAr: 'شماغ أحمر أصيل', description: 'شماغ أحمر بجودة عالية — من أهم مستلزمات اللباس العربي', price: 12, category: 'clothing', merchantId: merchants[1].id, stock: 150, bubbleColor: '#dc2626', bubbleColor2: '#ef4444' },

      // Food (خالد)
      { name: 'تمر عجوة المدينة', nameAr: 'تمر عجوة المدينة', description: 'تمر عجوة ممتاز من المدينة المنورة — عبوة 1 كغم', price: 15, category: 'food', merchantId: merchants[2].id, stock: 200, isFeatured: true, bubbleColor: '#92400e', bubbleColor2: '#d97706' },
      { name: 'زيتون جبلي فاخر', nameAr: 'زيتون جبلي فاخر', description: 'زيتون أخضر جبلي من أجود الأنواع — عبوة 500 غم', price: 8, category: 'food', merchantId: merchants[2].id, stock: 100, bubbleColor: '#65a30d', bubbleColor2: '#84cc16' },
      { name: 'عسل سدر أصلي', nameAr: 'عسل سدر أصلي', description: 'عسل سدر يمني طبيعي — 500 غم', price: 18, category: 'food', merchantId: merchants[2].id, stock: 75, isFeatured: true, bubbleColor: '#f59e0b', bubbleColor2: '#fbbf24' },
      { name: 'قهوة عربية فاخرة', nameAr: 'قهوة عربية فاخرة', description: 'قهوة عربية مع هيل — عبوة 250 غم', price: 7, category: 'food', merchantId: merchants[2].id, stock: 300, bubbleColor: '#78350f', bubbleColor2: '#92400e' },
      { name: 'فول مدمس بالزيت', nameAr: 'فول مدمس بالزيت', description: 'فول مدمس جاهز مع زيت زيتون — علبة', price: 2, category: 'food', merchantId: merchants[2].id, stock: 500, bubbleColor: '#854d0e', bubbleColor2: '#a16207' },

      // Services (نورة)
      { name: 'تصميم موقع إلكتروني', nameAr: 'تصميم موقع إلكتروني', description: 'تصميم وتطوير موقع إلكتروني احترافي متجاوب مع جميع الأجهزة', price: 500, category: 'services', merchantId: merchants[3].id, stock: 999, isFeatured: true, bubbleColor: '#2563eb', bubbleColor2: '#3b82f6' },
      { name: 'إدارة حسابات التواصل', nameAr: 'إدارة حسابات التواصل', description: 'إدارة احترافية لحسابات التواصل الإجتماعي لمدة شهر', price: 150, category: 'services', merchantId: merchants[3].id, stock: 999, bubbleColor: '#7c3aed', bubbleColor2: '#8b5cf6' },
      { name: 'تطوير تطبيق جوال', nameAr: 'تطوير تطبيق جوال', description: 'تطوير تطبيق جوال لنظامي iOS وAndroid', price: 1500, category: 'services', merchantId: merchants[3].id, stock: 999, isFeatured: true, bubbleColor: '#059669', bubbleColor2: '#10b981' },
      { name: 'حلول SEO وتحسين الظهور', nameAr: 'حلول SEO وتحسين الظهور', description: 'تحسين ظهور موقعك في نتائج البحث — باقة شهرية', price: 100, category: 'services', merchantId: merchants[3].id, stock: 999, bubbleColor: '#0891b2', bubbleColor2: '#06b6d4' },

      // Home (محمد)
      { name: 'طقم مجالس عربي', nameAr: 'طقم مجالس عربي', description: 'طقم مجالس عربي فاخر من القماش المطرز — 6 قطع', price: 350, category: 'home', merchantId: merchants[4].id, stock: 10, isFeatured: true, bubbleColor: '#b45309', bubbleColor2: '#d97706' },
      { name: 'سجادة فارسية', nameAr: 'سجادة فارسية', description: 'سجادة فارسية منسوجة يدوياً — مقاس 200×300 سم', price: 250, category: 'home', merchantId: merchants[4].id, stock: 8, bubbleColor: '#991b1b', bubbleColor2: '#dc2626' },
      { name: 'مبخرة نحاسية مزخرفة', nameAr: 'مبخرة نحاسية مزخرفة', description: 'مبخرة نحاسية يدوية الصنع مع نقوش عربية أصيلة', price: 25, category: 'home', merchantId: merchants[4].id, stock: 40, bubbleColor: '#ca8a04', bubbleColor2: '#eab308' },
      { name: 'دلة قهوة عربية', nameAr: 'دلة قهوة عربية', description: 'دلة قهوة عربية نحاسية مزخرفة — مقاس متوسط', price: 30, category: 'home', merchantId: merchants[4].id, stock: 35, isFeatured: true, bubbleColor: '#a16207', bubbleColor2: '#ca8a04' },
      { name: 'مكتبة خشب عتيق', nameAr: 'مكتبة خشب عتيق', description: 'مكتبة من الخشب العتيق بتصميم عربي كلاسيكي', price: 180, category: 'home', merchantId: merchants[4].id, stock: 12, bubbleColor: '#7c2d12', bubbleColor2: '#9a3412' },
    ];

    const products = await Promise.all(
      productsData.map((p) =>
        db.product.create({
          data: {
            ...p,
            descriptionAr: p.description,
            currency: 'KWD',
            tags: JSON.stringify([p.category]),
            images: JSON.stringify([]),
            aiTags: JSON.stringify([p.category]),
            aiSummary: p.description.substring(0, 80),
            bubbleRadius: 65,
          },
        })
      )
    );

    // ============ CREATE BUBBLE STATES ============
    const bubbleStates = await Promise.all([
      db.bubbleState.create({
        data: {
          bubbleType: 'ads',
          label: 'العروض',
          labelAr: 'العروض الخاصة',
          color: '#ef4444',
          color2: '#f97316',
          radius: 75,
          positionX: 0.15,
          positionY: 0.25,
          items: JSON.stringify(products.filter((p) => p.isFeatured).slice(0, 3).map((p) => ({ id: p.id, name: p.name }))),
        },
      }),
      db.bubbleState.create({
        data: {
          bubbleType: 'suggest',
          label: 'مقترحات',
          labelAr: 'مقترحات لك',
          color: '#10b981',
          color2: '#34d399',
          radius: 65,
          positionX: 0.8,
          positionY: 0.2,
          items: JSON.stringify(products.slice(0, 4).map((p) => ({ id: p.id, name: p.name }))),
        },
      }),
      db.bubbleState.create({
        data: {
          bubbleType: 'product',
          label: 'المنتجات',
          labelAr: 'تصفح المنتجات',
          color: '#3b82f6',
          color2: '#60a5fa',
          radius: 70,
          positionX: 0.5,
          positionY: 0.15,
          items: JSON.stringify(products.slice(0, 6).map((p) => ({ id: p.id, name: p.name, category: p.category }))),
        },
      }),
      db.bubbleState.create({
        data: {
          bubbleType: 'wallet',
          label: 'المحفظة',
          labelAr: 'محفظتك',
          color: '#f59e0b',
          color2: '#fbbf24',
          radius: 55,
          positionX: 0.85,
          positionY: 0.45,
          items: JSON.stringify({ balance: 500, currency: 'KWD' }),
        },
      }),
      db.bubbleState.create({
        data: {
          bubbleType: 'analytics',
          label: 'التحليلات',
          labelAr: 'إحصائيات السوق',
          color: '#8b5cf6',
          color2: '#a78bfa',
          radius: 55,
          positionX: 0.12,
          positionY: 0.55,
          items: JSON.stringify({ views: 0, sales: 0 }),
        },
      }),
      db.bubbleState.create({
        data: {
          bubbleType: 'subchat',
          label: 'جاسم',
          labelAr: 'مساعد جاسم',
          color: '#06b6d4',
          color2: '#22d3ee',
          radius: 60,
          positionX: 0.88,
          positionY: 0.75,
          items: JSON.stringify({ active: true }),
        },
      }),
    ]);

    // ============ CREATE SAMPLE ANALYTICS ============
    const analyticsEvents = [
      { event: 'view', data: JSON.stringify({ productId: products[0].id, category: 'electronics' }) },
      { event: 'view', data: JSON.stringify({ productId: products[1].id, category: 'electronics' }) },
      { event: 'view', data: JSON.stringify({ productId: products[6].id, category: 'clothing' }) },
      { event: 'click', data: JSON.stringify({ productId: products[0].id, action: 'details' }) },
      { event: 'search', data: JSON.stringify({ query: 'هاتف ذكي' }) },
      { event: 'search', data: JSON.stringify({ query: 'عباية' }) },
      { event: 'bubble_pop', data: JSON.stringify({ bubbleType: 'ads' }) },
      { event: 'bubble_expand', data: JSON.stringify({ bubbleType: 'suggest' }) },
    ];

    await Promise.all(
      analyticsEvents.map((e) =>
        db.analyticsEvent.create({
          data: { ...e, userId: customer.id },
        })
      )
    );

    // ============ CREATE SAMPLE REVIEWS ============
    const reviews = [
      { rating: 5, comment: 'منتج رائع! جودة عالية وتوصيل سريع', userId: customer.id, productId: products[0].id },
      { rating: 4, comment: 'جيد جداً لكن السعر مرتفع قليلاً', userId: customer.id, productId: products[1].id },
      { rating: 5, comment: 'أفضل عباية اشتريتها — تطريز جميل', userId: customer.id, productId: products[6].id },
      { rating: 5, comment: 'تمر ممتاز طازج — شكراً', userId: customer.id, productId: products[11].id },
      { rating: 3, comment: 'مقبول لكن يمكن تحسين التغليف', userId: customer.id, productId: products[2].id },
    ];

    await Promise.all(
      reviews.map((r) =>
        db.review.create({
          data: r,
        })
      )
    );

    // Update product ratings
    for (const review of reviews) {
      const productReviews = await db.review.findMany({
        where: { productId: review.productId },
      });
      const avgRating =
        productReviews.reduce((sum, r) => sum + r.rating, 0) / productReviews.length;
      await db.product.update({
        where: { id: review.productId },
        data: {
          rating: Math.round(avgRating * 10) / 10,
          reviewCount: productReviews.length,
        },
      });
    }

    return NextResponse.json({
      success: true,
      message: 'تم بذر البيانات بنجاح',
      counts: {
        merchants: merchants.length,
        products: products.length,
        bubbleStates: bubbleStates.length,
        reviews: reviews.length,
        analytics: analyticsEvents.length,
        customer: customer.id,
      },
    });
  } catch (error) {
    console.error('Error seeding database:', error);
    return NextResponse.json(
      { error: 'فشل في بذر البيانات', details: String(error) },
      { status: 500 }
    );
  }
}

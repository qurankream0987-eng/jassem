import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/analytics — Get analytics summary
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const days = parseInt(searchParams.get('days') || '30');

    const since = new Date();
    since.setDate(since.getDate() - days);

    // Get analytics events
    const where: Record<string, unknown> = {
      createdAt: { gte: since },
    };
    if (userId) {
      where.userId = userId;
    }

    // Total views
    const views = await db.analyticsEvent.count({
      where: { ...where, event: 'view' },
    });

    // Total clicks
    const clicks = await db.analyticsEvent.count({
      where: { ...where, event: 'click' },
    });

    // Total purchases
    const purchases = await db.analyticsEvent.count({
      where: { ...where, event: 'purchase' },
    });

    // Total searches
    const searches = await db.analyticsEvent.count({
      where: { ...where, event: 'search' },
    });

    // Bubble interactions
    const bubblePops = await db.analyticsEvent.count({
      where: { ...where, event: 'bubble_pop' },
    });
    const bubbleExpands = await db.analyticsEvent.count({
      where: { ...where, event: 'bubble_expand' },
    });

    // Sales data
    const orders = await db.order.findMany({
      where: { createdAt: { gte: since } },
      select: { total: true, status: true },
    });

    const totalSales = orders
      .filter((o) => o.status !== 'cancelled')
      .reduce((sum, o) => sum + o.total, 0);

    const avgOrderValue =
      orders.length > 0 ? totalSales / orders.filter((o) => o.status !== 'cancelled').length : 0;

    // ROI (return on investment) — simplified calculation
    const totalRevenue = totalSales;
    const estimatedCost = totalRevenue * 0.6; // assumed 60% cost
    const roi = estimatedCost > 0 ? ((totalRevenue - estimatedCost) / estimatedCost) * 100 : 0;

    // Top products by views
    const topProducts = await db.product.findMany({
      where: { isActive: true },
      select: {
        id: true,
        name: true,
        nameAr: true,
        price: true,
        views: true,
        rating: true,
        images: true,
        category: true,
      },
      orderBy: { views: 'desc' },
      take: 5,
    });

    // Recent events
    const recentEvents = await db.analyticsEvent.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 20,
      include: {
        user: {
          select: { id: true, name: true },
        },
      },
    });

    // Category breakdown
    const categoryBreakdown = await db.product.groupBy({
      by: ['category'],
      where: { isActive: true },
      _count: { id: true },
      _avg: { rating: true, price: true },
    });

    return NextResponse.json({
      views,
      clicks,
      purchases,
      searches,
      bubblePops,
      bubbleExpands,
      sales: {
        total: Math.round(totalSales * 100) / 100,
        avgOrderValue: Math.round(avgOrderValue * 100) / 100,
        orderCount: orders.length,
        currency: 'KWD',
      },
      roi: Math.round(roi * 10) / 10,
      topProducts,
      recentEvents,
      categoryBreakdown,
      period: { days, since },
    });
  } catch (error) {
    console.error('Error getting analytics:', error);
    return NextResponse.json(
      { error: 'فشل في تحميل التحليلات', details: String(error) },
      { status: 500 }
    );
  }
}

// POST /api/analytics — Track event
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { event, data, userId, sessionId } = body;

    if (!event) {
      return NextResponse.json(
        { error: 'نوع الحدث مطلوب' },
        { status: 400 }
      );
    }

    const validEvents = ['view', 'click', 'purchase', 'search', 'bubble_pop', 'bubble_expand'];
    if (!validEvents.includes(event)) {
      return NextResponse.json(
        { error: `حدث غير صالح. الأحداث المسموحة: ${validEvents.join(', ')}` },
        { status: 400 }
      );
    }

    const analyticsEvent = await db.analyticsEvent.create({
      data: {
        event,
        data: JSON.stringify(data || {}),
        userId: userId || null,
        sessionId: sessionId || null,
      },
    });

    return NextResponse.json(
      { event: analyticsEvent, message: 'تم تسجيل الحدث بنجاح' },
      { status: 201 }
    );
  } catch (error) {
    console.error('Error tracking event:', error);
    return NextResponse.json(
      { error: 'فشل في تسجيل الحدث', details: String(error) },
      { status: 500 }
    );
  }
}

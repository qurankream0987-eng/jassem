import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/dna — Get user's DNA profile
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { error: 'معرف المستخدم مطلوب' },
        { status: 400 }
      );
    }

    const user = await db.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        name: true,
        dnaProfile: true,
        dnaGeneration: true,
        dnaFitness: true,
      },
    });

    if (!user) {
      return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });
    }

    // Parse DNA profile
    let dnaProfile: Record<string, unknown> = {};
    if (user.dnaProfile) {
      try {
        dnaProfile = JSON.parse(user.dnaProfile);
      } catch {
        dnaProfile = { raw: user.dnaProfile };
      }
    } else {
      // Initialize default DNA
      dnaProfile = {
        categories: {},
        priceRange: { min: 0, max: 1000 },
        brands: {},
        searchHistory: [],
        interactions: { views: 0, clicks: 0, purchases: 0 },
        preferences: {},
      };
    }

    // Get recent mutations
    const mutations = await db.dNAMutation.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });

    // Get user activity stats
    const recentEvents = await db.analyticsEvent.findMany({
      where: {
        userId,
        createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
      },
      select: { event: true, data: true },
    });

    const activitySummary = {
      views: recentEvents.filter((e) => e.event === 'view').length,
      clicks: recentEvents.filter((e) => e.event === 'click').length,
      purchases: recentEvents.filter((e) => e.event === 'purchase').length,
      searches: recentEvents.filter((e) => e.event === 'search').length,
    };

    return NextResponse.json({
      userId: user.id,
      name: user.name,
      dnaProfile,
      generation: user.dnaGeneration,
      fitness: user.dnaFitness,
      mutations,
      activitySummary,
    });
  } catch (error) {
    console.error('Error getting DNA profile:', error);
    return NextResponse.json(
      { error: 'فشل في تحميل الملف الوراثي', details: String(error) },
      { status: 500 }
    );
  }
}

// POST /api/dna — Evolve DNA based on interactions
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, event, data } = body;

    if (!userId || !event) {
      return NextResponse.json(
        { error: 'معرف المستخدم والحدث مطلوبان' },
        { status: 400 }
      );
    }

    const user = await db.user.findUnique({ where: { id: userId } });
    if (!user) {
      return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });
    }

    // Parse current DNA or initialize
    let currentDna: Record<string, unknown>;
    try {
      currentDna = user.dnaProfile ? JSON.parse(user.dnaProfile) : getDefaultDna();
    } catch {
      currentDna = getDefaultDna();
    }

    // Ensure all required fields exist (normalize)
    currentDna = normalizeDna(currentDna);

    const fromState = JSON.stringify(currentDna);
    const currentGeneration = user.dnaGeneration;

    // Evolve DNA based on event type
    switch (event) {
      case 'view_product':
        evolveFromView(currentDna, data);
        break;
      case 'purchase':
        evolveFromPurchase(currentDna, data);
        break;
      case 'search':
        evolveFromSearch(currentDna, data);
        break;
      case 'rating':
        evolveFromRating(currentDna, data);
        break;
      case 'category_browse':
        evolveFromCategoryBrowse(currentDna, data);
        break;
      default:
        evolveGeneric(currentDna, event, data);
    }

    // Calculate fitness score
    const fitness = calculateFitness(currentDna);
    const newGeneration = currentGeneration + 1;

    // Record mutation
    const mutation = await db.dNAMutation.create({
      data: {
        type: getMutationType(event),
        fromState,
        toState: JSON.stringify(currentDna),
        fitnessDelta: fitness - user.dnaFitness,
        generation: newGeneration,
        userId,
      },
    });

    // Update user DNA
    const updatedUser = await db.user.update({
      where: { id: userId },
      data: {
        dnaProfile: JSON.stringify(currentDna),
        dnaGeneration: newGeneration,
        dnaFitness: fitness,
      },
    });

    return NextResponse.json({
      dnaProfile: currentDna,
      generation: newGeneration,
      fitness,
      mutations: [mutation],
      message: `تم تطور الملف الوراثي إلى الجيل ${newGeneration}`,
    });
  } catch (error) {
    console.error('Error evolving DNA:', error);
    return NextResponse.json(
      { error: 'فشل في تطور الملف الوراثي', details: String(error) },
      { status: 500 }
    );
  }
}

function getDefaultDna(): Record<string, unknown> {
  return {
    categories: {},
    priceRange: { min: 0, max: 1000 },
    brands: {},
    searchTerms: [],
    interactions: { views: 0, clicks: 0, purchases: 0 },
    preferences: {},
    lastUpdated: new Date().toISOString(),
  };
}

// Normalize DNA to ensure all required fields exist
function normalizeDna(dna: Record<string, unknown>): Record<string, unknown> {
  const defaults = getDefaultDna();
  return {
    ...defaults,
    ...dna,
    categories: { ...(defaults.categories as object), ...(dna.categories as object || {}) },
    priceRange: { ...(defaults.priceRange as object), ...(dna.priceRange as object || {}) },
    interactions: { ...(defaults.interactions as object), ...(dna.interactions as object || {}) },
    preferences: { ...(defaults.preferences as object), ...(dna.preferences as object || {}) },
    searchTerms: Array.isArray(dna.searchTerms) ? dna.searchTerms : [],
  };
}

function evolveFromView(dna: Record<string, unknown>, data?: Record<string, unknown>) {
  const interactions = dna.interactions as Record<string, number>;
  interactions.views = (interactions.views || 0) + 1;

  if (data?.category) {
    const categories = dna.categories as Record<string, number>;
    categories[data.category as string] = (categories[data.category as string] || 0) + 0.5;
  }

  if (data?.price) {
    const priceRange = dna.priceRange as { min: number; max: number };
    const price = Number(data.price);
    if (price > 0) {
      priceRange.max = Math.max(priceRange.max, price);
      priceRange.min = Math.min(priceRange.min, price);
    }
  }

  dna.lastUpdated = new Date().toISOString();
}

function evolveFromPurchase(dna: Record<string, unknown>, data?: Record<string, unknown>) {
  const interactions = dna.interactions as Record<string, number>;
  interactions.purchases = (interactions.purchases || 0) + 1;

  if (data?.category) {
    const categories = dna.categories as Record<string, number>;
    categories[data.category as string] = (categories[data.category as string] || 0) + 2;
  }

  if (data?.price) {
    const price = Number(data.price);
    const priceRange = dna.priceRange as { min: number; max: number };
    // Tighten range based on actual purchases
    priceRange.min = priceRange.min * 0.9 + price * 0.1;
    priceRange.max = priceRange.max * 0.9 + price * 0.1;
  }

  dna.lastUpdated = new Date().toISOString();
}

function evolveFromSearch(dna: Record<string, unknown>, data?: Record<string, unknown>) {
  if (data?.query) {
    const searchTerms = dna.searchTerms as string[];
    searchTerms.push(data.query as string);
    // Keep last 20 search terms
    if (searchTerms.length > 20) {
      dna.searchTerms = searchTerms.slice(-20);
    }
  }

  dna.lastUpdated = new Date().toISOString();
}

function evolveFromRating(dna: Record<string, unknown>, data?: Record<string, unknown>) {
  if (data?.category && data?.rating) {
    const categories = dna.categories as Record<string, number>;
    const weight = Number(data.rating) >= 4 ? 1.5 : -0.5;
    categories[data.category as string] = (categories[data.category as string] || 0) + weight;
  }

  const preferences = dna.preferences as Record<string, unknown>;
  if (data?.productId && data?.rating) {
    preferences[`rated_${data.productId}`] = data.rating;
  }

  dna.lastUpdated = new Date().toISOString();
}

function evolveFromCategoryBrowse(dna: Record<string, unknown>, data?: Record<string, unknown>) {
  if (data?.category) {
    const categories = dna.categories as Record<string, number>;
    categories[data.category as string] = (categories[data.category as string] || 0) + 1;
  }
  dna.lastUpdated = new Date().toISOString();
}

function evolveGeneric(
  dna: Record<string, unknown>,
  event: string,
  data?: Record<string, unknown>
) {
  const preferences = dna.preferences as Record<string, unknown>;
  preferences[`last_${event}`] = data || {};
  dna.lastUpdated = new Date().toISOString();
}

function calculateFitness(dna: Record<string, unknown>): number {
  const interactions = dna.interactions as Record<string, number>;
  const categories = dna.categories as Record<string, number>;

  // Fitness based on interaction depth and category diversity
  const interactionScore = Math.min(
    (interactions.views * 0.1 + interactions.purchases * 1 + interactions.clicks * 0.3) / 10,
    5
  );
  const diversityScore = Math.min(Object.keys(categories).length * 0.5, 3);
  const consistencyScore = Object.values(categories).some((v) => v > 2) ? 2 : 0;

  return Math.round((interactionScore + diversityScore + consistencyScore) * 100) / 100;
}

function getMutationType(event: string): string {
  switch (event) {
    case 'view_product':
      return 'preference_shift';
    case 'purchase':
      return 'price_adapt';
    case 'search':
      return 'tag_evolution';
    case 'rating':
      return 'preference_shift';
    case 'category_browse':
      return 'category_drift';
    default:
      return 'preference_shift';
  }
}

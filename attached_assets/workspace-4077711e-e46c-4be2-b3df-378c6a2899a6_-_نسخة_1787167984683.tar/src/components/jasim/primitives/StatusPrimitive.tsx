// 📋 StatusPrimitive — generic status display (completed, blocked, info)

'use client';

import { CheckCircle2, XCircle, Info, AlertOctagon, Ban } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { PrimitiveProps } from '../PrimitiveRegistry';

export function StatusPrimitive({ contract, onAction }: PrimitiveProps) {
  const data = contract.data || {};
  const isBlocked = contract.titleAr.includes('حظر') || contract.titleAr.includes('Blocked');
  const isCompleted = contract.titleAr.includes('تم') || contract.titleAr.includes('Completed') || contract.titleAr.includes('✅');
  const isEmergency = contract.titleAr.includes('طوارئ') || contract.titleAr.includes('Emergency');

  const Icon = isBlocked ? Ban : isEmergency ? AlertOctagon : isCompleted ? CheckCircle2 : Info;
  const colorClass = isBlocked || isEmergency
    ? 'text-red-600'
    : isCompleted
      ? 'text-emerald-600'
      : 'text-primary';

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Icon className={`w-5 h-5 ${colorClass}`} />
        <h3 className="font-semibold">{contract.titleAr}</h3>
      </div>

      {isBlocked ? (
        <div className="space-y-3">
          <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg p-3">
            <div className="text-sm text-red-700 dark:text-red-400 mb-2">
              {data.forbiddenItems as string && (
                <div>
                  <div className="font-semibold mb-1">المنتجات المحظورة:</div>
                  <div>{data.forbiddenItems as string}</div>
                </div>
              )}
            </div>
            {Array.isArray(data.alternatives) && (data.alternatives as string[]).length > 0 && (
              <div className="mt-3">
                <div className="text-xs font-semibold mb-1.5 text-emerald-700 dark:text-emerald-400">💡 البدائل المباحة:</div>
                <ul className="space-y-1">
                  {(data.alternatives as string[]).map((alt, i) => (
                    <li key={i} className="text-xs text-emerald-700 dark:text-emerald-400 flex items-start gap-1">
                      <CheckCircle2 className="w-3 h-3 mt-0.5 shrink-0" /> {alt}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {data.fatwaReference && (
              <div className="mt-3 pt-3 border-t border-red-200 dark:border-red-800 text-xs text-muted-foreground">
                📜 {data.fatwaReference as string}
              </div>
            )}
          </div>
        </div>
      ) : isEmergency ? (
        <div className="bg-red-50 dark:bg-red-950/20 border border-red-500/40 rounded-lg p-3">
          <p className="text-sm text-red-700 dark:text-red-400 font-medium">
            {data.empathyResponse as string}
          </p>
        </div>
      ) : (
        <div className="bg-muted/50 p-3 rounded-lg space-y-2">
          {Object.entries(data).map(([key, value]) => (
            <div key={key} className="flex justify-between text-sm">
              <span className="text-muted-foreground">{translateKey(key)}:</span>
              <span className="font-medium">{formatValue(value)}</span>
            </div>
          ))}
        </div>
      )}

      {contract.actions.length > 0 && (
        <div className="flex flex-wrap gap-2 pt-2 border-t">
          {contract.actions.map((action) => (
            <Button
              key={action.id}
              variant={action.type === 'primary' ? 'default' : 'outline'}
              size="sm"
              onClick={() => onAction?.(action.capabilityId, action.payload)}
            >
              {action.labelAr}
            </Button>
          ))}
        </div>
      )}
    </div>
  );
}

function translateKey(key: string): string {
  const map: Record<string, string> = {
    note: 'ملاحظة',
    status: 'الحالة',
    forbiddenItems: 'المحظورات',
    alternatives: 'البدائل',
    fatwaReference: 'المرجع',
    phase: 'المرحلة',
    worldId: 'معرف العالم',
    entities: 'الكيانات',
    policies: 'السياسات',
    crisisType: 'نوع الأزمة',
    empathyResponse: 'الاستجابة التعاطفية',
  };
  return map[key] || key;
}

function formatValue(value: unknown): string {
  if (typeof value === 'boolean') return value ? 'نعم' : 'لا';
  if (Array.isArray(value)) return `${value.length} عنصر`;
  if (typeof value === 'object' && value !== null) return JSON.stringify(value).slice(0, 50);
  return String(value);
}

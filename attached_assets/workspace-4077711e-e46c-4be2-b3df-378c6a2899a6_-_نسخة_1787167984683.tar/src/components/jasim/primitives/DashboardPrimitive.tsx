// 📊 DashboardPrimitive — KPI metrics display

'use client';

import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { PrimitiveProps } from '../PrimitiveRegistry';

interface Metric {
  label: string;
  labelAr: string;
  value: string | number;
  trend?: 'up' | 'down' | 'stable';
}

export function DashboardPrimitive({ contract, onAction }: PrimitiveProps) {
  const metrics = (contract.data?.metrics as Metric[]) || [];

  return (
    <div className="space-y-4">
      <h3 className="font-semibold flex items-center gap-2">
        <span>📊</span>
        {contract.titleAr}
      </h3>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {metrics.map((metric, idx) => (
          <div key={idx} className="border rounded-lg p-3 bg-muted/30">
            <div className="text-xs text-muted-foreground mb-1">{metric.labelAr}</div>
            <div className="text-lg font-bold text-primary">{metric.value}</div>
            {metric.trend && (
              <div className={`text-xs flex items-center gap-1 mt-1 ${
                metric.trend === 'up' ? 'text-emerald-600' :
                metric.trend === 'down' ? 'text-red-600' :
                'text-muted-foreground'
              }`}>
                {metric.trend === 'up' && <TrendingUp className="w-3 h-3" />}
                {metric.trend === 'down' && <TrendingDown className="w-3 h-3" />}
                {metric.trend === 'stable' && <Minus className="w-3 h-3" />}
                <span>
                  {metric.trend === 'up' ? 'صاعد' : metric.trend === 'down' ? 'هابط' : 'مستقر'}
                </span>
              </div>
            )}
          </div>
        ))}
      </div>

      {contract.actions.length > 0 && (
        <div className="flex gap-2 pt-2 border-t">
          {contract.actions.map((action) => (
            <Button
              key={action.id}
              variant={action.type === 'primary' ? 'default' : 'outline'}
              size="sm"
              onClick={() => onAction?.(action.capabilityId, action.payload)}
            >
              {action.labelAr}
            </Button>
          ))}
        </div>
      )}
    </div>
  );
}

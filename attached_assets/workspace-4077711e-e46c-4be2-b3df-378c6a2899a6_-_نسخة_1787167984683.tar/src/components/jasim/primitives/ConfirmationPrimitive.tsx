// ✅ ConfirmationPrimitive — confirm an action (escrow release, contract, etc.)

'use client';

import { ShieldCheck, FileText, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { PrimitiveProps } from '../PrimitiveRegistry';

export function ConfirmationPrimitive({ contract, onAction }: PrimitiveProps) {
  const details = contract.data || {};

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <ShieldCheck className="w-5 h-5 text-emerald-500" />
        <h3 className="font-semibold">{contract.titleAr}</h3>
      </div>

      <div className="bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800 rounded-lg p-3 space-y-2">
        {Object.entries(details).map(([key, value]) => (
          <div key={key} className="flex justify-between text-sm">
            <span className="text-muted-foreground">{translateKey(key)}:</span>
            <span className="font-medium">{formatValue(value)}</span>
          </div>
        ))}
      </div>

      <Alert>
        <AlertTriangle className="w-4 h-4" />
        <AlertDescription className="text-xs">
          سيتم تنفيذ الإجراء النهائي ولا يمكن التراجع عنه. يُرجى المراجعة قبل التأكيد.
        </AlertDescription>
      </Alert>

      <div className="flex gap-2 pt-2 border-t">
        {contract.actions.map((action) => (
          <Button
            key={action.id}
            variant={
              action.type === 'primary' ? 'default' :
              action.type === 'ghost' ? 'ghost' : 'outline'
            }
            size="sm"
            className={action.type === 'primary' ? 'flex-1' : ''}
            onClick={() => onAction?.(action.capabilityId, action.payload)}
          >
            {action.labelAr}
          </Button>
        ))}
      </div>
    </div>
  );
}

import { Alert, AlertDescription } from '@/components/ui/alert';

function translateKey(key: string): string {
  const map: Record<string, string> = {
    escrowId: 'رقم الضمان',
    status: 'الحالة',
    contractId: 'رقم العقد',
    verified: 'تم التحقق',
    verifiedAt: 'وقت التحقق',
    bookingId: 'رقم الحجز',
    date: 'التاريخ',
    releaseAfterDays: 'يوم للإفراج',
    phase: 'المرحلة',
    worldId: 'معرف العالم',
    entities: 'الكيانات',
    policies: 'السياسات',
  };
  return map[key] || key;
}

function formatValue(value: unknown): string {
  if (typeof value === 'boolean') return value ? 'نعم' : 'لا';
  if (Array.isArray(value)) return `${value.length} عنصر`;
  if (typeof value === 'object' && value !== null) return JSON.stringify(value).slice(0, 50);
  if (typeof value === 'string' && value.includes('T') && value.endsWith('Z')) {
    try { return new Date(value).toLocaleString('ar-KW'); } catch { return value; }
  }
  return String(value);
}

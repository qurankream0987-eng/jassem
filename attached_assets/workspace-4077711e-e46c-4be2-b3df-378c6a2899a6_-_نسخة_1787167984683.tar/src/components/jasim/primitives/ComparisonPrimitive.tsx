// ⚖️ ComparisonPrimitive — side-by-side comparison of items

'use client';

import { Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { PrimitiveProps } from '../PrimitiveRegistry';

interface CompareItem {
  id: string;
  [key: string]: unknown;
}

export function ComparisonPrimitive({ contract, onAction }: PrimitiveProps) {
  const items = (contract.data?.items as CompareItem[]) || [];

  if (items.length === 0) {
    return <div className="text-center py-8 text-muted-foreground">لا توجد عناصر للمقارنة</div>;
  }

  // Collect all unique field keys
  const fieldKeys = Array.from(new Set(items.flatMap((i) => Object.keys(i).filter((k) => k !== 'id' && k !== 'image' && k !== 'description'))));

  return (
    <div className="space-y-4">
      <h3 className="font-semibold flex items-center gap-2">
        <span>⚖️</span>
        {contract.titleAr}
      </h3>

      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="border-b">
              <th className="text-right p-2 font-medium text-muted-foreground w-1/5">المعيار</th>
              {items.map((item) => (
                <th key={item.id as string} className="text-right p-2 font-semibold min-w-[150px]">
                  <div className="flex flex-col gap-1">
                    <span className="text-2xl">{(item.image as string) || '📦'}</span>
                    <span className="text-xs">
                      {(item.title || item.brand || item.name) as string} {item.model ? ` ${item.model}` : ''}
                    </span>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {fieldKeys.map((key, idx) => (
              <tr key={key} className={idx % 2 === 0 ? 'bg-muted/30' : ''}>
                <td className="p-2 text-muted-foreground capitalize text-xs">
                  {translateField(key)}
                </td>
                {items.map((item) => {
                  const value = item[key];
                  return (
                    <td key={item.id as string} className="p-2">
                      {renderValue(key, value)}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap gap-2 pt-2 border-t">
        {contract.actions.map((action) => (
          <Button
            key={action.id}
            variant={action.type === 'primary' ? 'default' : 'outline'}
            size="sm"
            onClick={() => onAction?.(action.capabilityId, action.payload)}
          >
            {action.labelAr}
          </Button>
        ))}
      </div>
    </div>
  );
}

function translateField(key: string): string {
  const map: Record<string, string> = {
    brand: 'الماركة',
    model: 'الموديل',
    year: 'السنة',
    price: 'السعر',
    mileage: 'الممشى',
    transmission: 'الناقل',
    fuel: 'الوقود',
    location: 'الموقع',
    condition: 'الحالة',
    category: 'الفئة',
    title: 'العنوان',
    name: 'الاسم',
    company: 'الشركة',
    salary: 'الراتب',
    area: 'المساحة',
    bedrooms: 'غرف النوم',
    type: 'النوع',
    purpose: 'الغرض',
    cuisine: 'المطبخ',
    spicy: 'حار',
    restaurant: 'المطعم',
  };
  return map[key] || key;
}

function renderValue(key: string, value: unknown): React.ReactNode {
  if (value === undefined || value === null) {
    return <span className="text-muted-foreground">—</span>;
  }
  if (typeof value === 'boolean') {
    return value ? (
      <span className="inline-flex items-center text-green-600"><Check className="w-3 h-3 ml-1" /> نعم</span>
    ) : (
      <span className="inline-flex items-center text-muted-foreground"><X className="w-3 h-3 ml-1" /> لا</span>
    );
  }
  if (key === 'price' || key === 'salary') {
    return <span className="font-bold text-primary">{value as number} د.ك</span>;
  }
  if (key === 'mileage') {
    return <span>{(value as number).toLocaleString()} كم</span>;
  }
  if (key === 'area') {
    return <span>{value as number} م²</span>;
  }
  return <span>{String(value)}</span>;
}

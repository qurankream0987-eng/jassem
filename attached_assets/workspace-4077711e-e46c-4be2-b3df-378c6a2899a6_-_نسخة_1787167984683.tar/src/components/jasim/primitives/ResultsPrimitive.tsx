// 📊 ResultsPrimitive — renders search results as cards

'use client';

import { MapPin, Tag, Calendar, Gauge } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { PrimitiveProps } from '../PrimitiveRegistry';

interface ResultItem {
  id: string;
  [key: string]: unknown;
}

export function ResultsPrimitive({ contract, onAction }: PrimitiveProps) {
  const items = (contract.data?.items as ResultItem[]) || [];
  const entityType = (contract.data?.entityType as string) || 'product';

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold flex items-center gap-2">
          <span className="text-primary">🔍</span>
          {contract.titleAr}
        </h3>
        <Badge variant="secondary">{items.length} نتيجة</Badge>
      </div>

      {items.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          <p>لا توجد نتائج مطابقة</p>
          <p className="text-xs mt-1">حاول تعديل معايير البحث</p>
        </div>
      ) : (
        <ScrollArea className="max-h-[400px] pr-2">
          <div className="space-y-2">
            {items.map((item) => (
              <div
                key={item.id as string}
                className="border rounded-lg p-3 hover:bg-accent/30 transition-colors cursor-pointer"
                onClick={() => onAction?.('VIEW_DETAIL', { item })}
              >
                <div className="flex items-start gap-3">
                  <div className="text-3xl shrink-0">
                    {(item.image as string) || '📦'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-medium text-sm truncate">
                        {(item.title || item.name || item.brand || `${entityType} #${item.id}`) as string}
                        {item.model ? ` ${item.model}` : ''}
                        {item.year ? ` ${item.year}` : ''}
                      </h4>
                      {item.price !== undefined && (
                        <div className="text-primary font-bold text-sm whitespace-nowrap">
                          {item.price as number} {typeof item.price === 'number' && item.price > 100 ? 'د.ك' : 'د.ك'}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-2 mt-1.5 text-xs text-muted-foreground">
                      {item.location && (
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {item.location as string}
                        </span>
                      )}
                      {item.mileage !== undefined && (
                        <span className="flex items-center gap-1">
                          <Gauge className="w-3 h-3" /> {(item.mileage as number).toLocaleString()} كم
                        </span>
                      )}
                      {item.condition && (
                        <span className="flex items-center gap-1">
                          <Tag className="w-3 h-3" /> {item.condition === 'new' ? 'جديد' : 'مستعمل'}
                        </span>
                      )}
                      {item.year && (
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" /> {item.year as number}
                        </span>
                      )}
                      {item.transmission && (
                        <Badge variant="outline" className="text-[10px] h-4">
                          {item.transmission === 'automatic' ? 'أوتوماتيك' : 'عادي'}
                        </Badge>
                      )}
                      {item.cuisine && (
                        <Badge variant="outline" className="text-[10px] h-4">
                          {item.cuisine as string}
                        </Badge>
                      )}
                      {item.company && (
                        <span className="text-muted-foreground">{item.company as string}</span>
                      )}
                    </div>
                    {item.description && (
                      <p className="text-xs text-muted-foreground mt-1.5 line-clamp-2">
                        {item.description as string}
                      </p>
                    )}
                    {item.salary !== undefined && (
                      <div className="text-sm text-primary font-semibold mt-1">
                        راتب: {item.salary as number} د.ك
                      </div>
                    )}
                    {item.area !== undefined && (
                      <div className="text-xs text-muted-foreground mt-1">
                        مساحة: {item.area as number} م² • غرف: {item.bedrooms as number}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      )}

      <div className="flex flex-wrap gap-2 pt-2 border-t">
        {contract.actions.map((action) => (
          <Button
            key={action.id}
            variant={action.type === 'primary' ? 'default' : 'outline'}
            size="sm"
            onClick={() => onAction?.(action.capabilityId, action.payload)}
          >
            {action.labelAr}
          </Button>
        ))}
      </div>
    </div>
  );
}

// 🖼️ GalleryPrimitive — grid display of items (DNA-aware inference)

'use client';

import { MapPin, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { PrimitiveProps } from '../PrimitiveRegistry';

interface GalleryItem {
  id: string;
  [key: string]: unknown;
}

export function GalleryPrimitive({ contract, onAction }: PrimitiveProps) {
  const items = (contract.data?.items as GalleryItem[]) || [];

  return (
    <div className="space-y-3">
      <h3 className="font-semibold flex items-center gap-2">
        <span>🖼️</span>
        {contract.titleAr}
      </h3>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {items.map((item) => (
          <div
            key={item.id as string}
            className="border rounded-lg p-2 hover:border-primary/50 hover:shadow-md transition-all cursor-pointer"
            onClick={() => onAction?.('SELECT_ITEM', { item })}
          >
            <div className="aspect-square flex items-center justify-center bg-muted/50 rounded mb-2">
              <span className="text-4xl">{(item.image as string) || '📦'}</span>
            </div>
            <div className="space-y-0.5">
              <div className="text-xs font-medium truncate">
                {(item.title || item.name || item.brand) as string}
              </div>
              {item.price !== undefined && (
                <div className="text-primary font-bold text-xs">
                  {item.price as number} د.ك
                </div>
              )}
              {item.location && (
                <div className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                  <MapPin className="w-2.5 h-2.5" /> {item.location as string}
                </div>
              )}
              {item.rating !== undefined && (
                <div className="text-[10px] flex items-center gap-0.5">
                  <Star className="w-2.5 h-2.5 text-amber-400 fill-amber-400" /> {item.rating as number}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-2 pt-2 border-t">
        {contract.actions.map((action) => (
          <Button
            key={action.id}
            variant={action.type === 'primary' ? 'default' : 'outline'}
            size="sm"
            onClick={() => onAction?.(action.capabilityId, action.payload)}
          >
            {action.labelAr}
          </Button>
        ))}
      </div>
    </div>
  );
}

// 📝 FormPrimitive — dynamic form renderer

'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import type { PrimitiveProps } from '../PrimitiveRegistry';

export function FormPrimitive({ contract, onAction }: PrimitiveProps) {
  const [values, setValues] = useState<Record<string, string>>({});

  return (
    <div className="space-y-4">
      <h3 className="font-semibold">{contract.titleAr}</h3>

      <div className="space-y-3">
        {contract.fields.map((field) => (
          <div key={field.id} className="space-y-1.5">
            <Label htmlFor={field.id} className="text-xs">
              {field.labelAr}
              {field.validation?.required && <span className="text-red-500 mr-1">*</span>}
            </Label>
            {field.type === 'select' && field.options ? (
              <Select onValueChange={(v) => setValues((s) => ({ ...s, [field.name]: v }))}>
                <SelectTrigger id={field.id}>
                  <SelectValue placeholder={`اختر ${field.labelAr}`} />
                </SelectTrigger>
                <SelectContent>
                  {field.options.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.labelAr}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : field.type === 'textarea' ? (
              <Textarea
                id={field.id}
                placeholder={field.placeholder}
                value={values[field.name] ?? ''}
                onChange={(e) => setValues((s) => ({ ...s, [field.name]: e.target.value }))}
                dir="rtl"
              />
            ) : (
              <Input
                id={field.id}
                type={field.type === 'number' ? 'number' : 'text'}
                placeholder={field.placeholder || field.labelAr}
                value={values[field.name] ?? ((field.defaultValue as string) || '')}
                onChange={(e) => setValues((s) => ({ ...s, [field.name]: e.target.value }))}
                dir="rtl"
              />
            )}
            {field.helpText && (
              <p className="text-xs text-muted-foreground">{field.helpText}</p>
            )}
          </div>
        ))}
      </div>

      <div className="flex gap-2 pt-2 border-t">
        {contract.actions.map((action) => (
          <Button
            key={action.id}
            variant={
              action.type === 'primary' ? 'default' :
              action.type === 'danger' ? 'destructive' :
              action.type === 'ghost' ? 'ghost' : 'outline'
            }
            size="sm"
            onClick={() => onAction?.(action.capabilityId, { values, ...action.payload })}
          >
            {action.labelAr}
          </Button>
        ))}
      </div>
    </div>
  );
}

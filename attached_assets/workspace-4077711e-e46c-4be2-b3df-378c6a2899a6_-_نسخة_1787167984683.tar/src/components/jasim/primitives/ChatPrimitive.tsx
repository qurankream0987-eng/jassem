// 💬 ChatPrimitive — basic text bubble (fallback / general chat)

'use client';

import type { PrimitiveProps } from '../PrimitiveRegistry';

export function ChatPrimitive({ contract }: PrimitiveProps) {
  const text = (contract.data?.text as string) || '';
  const tone = (contract.data?.tone as string) || 'professional';
  const emotion = (contract.data?.emotion as string) || 'calm';

  return (
    <div className="space-y-2">
      <div className="bg-muted/50 rounded-lg p-3 text-sm" dir="auto">
        {text}
      </div>
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <span>نبرة: {translateTone(tone)}</span>
        <span>•</span>
        <span>المزاج: {translateEmotion(emotion)}</span>
      </div>
    </div>
  );
}

function translateTone(tone: string): string {
  const map: Record<string, string> = {
    gentle: 'لطيف',
    professional: 'احترافي',
    urgent: 'عاجل',
    celebratory: 'احتفالي',
    reassuring: 'مطمئن',
  };
  return map[tone] || tone;
}

function translateEmotion(emotion: string): string {
  const map: Record<string, string> = {
    calm: 'هادئ 😌',
    urgent: 'مستعجل 🚨',
    frustrated: 'محبط 😣',
    happy: 'سعيد 😊',
    confused: 'مرتبك 🤔',
    anxious: 'قلقان 😟',
  };
  return map[emotion] || emotion;
}

// ⏳ ProgressPrimitive — workflow/delivery progress tracker

'use client';

import { CheckCircle2, Circle, Loader2, Truck, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { PrimitiveProps } from '../PrimitiveRegistry';

interface ProgressStep {
  label: string;
  labelAr: string;
  status: 'done' | 'current' | 'pending';
}

export function ProgressPrimitive({ contract, onAction }: PrimitiveProps) {
  const steps = (contract.data?.steps as ProgressStep[]) || [];
  const eta = contract.data?.eta as string;

  const formattedEta = eta ? new Date(eta).toLocaleTimeString('ar-KW', {
    hour: '2-digit', minute: '2-digit',
  }) : null;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold flex items-center gap-2">
          <Truck className="w-4 h-4 text-primary" />
          {contract.titleAr}
        </h3>
        {formattedEta && (
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>الوصول المتوقع: {formattedEta}</span>
          </div>
        )}
      </div>

      <div className="space-y-2">
        {steps.map((step, idx) => (
          <div key={idx} className="flex items-start gap-3">
            <div className="shrink-0 mt-0.5">
              {step.status === 'done' && (
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              )}
              {step.status === 'current' && (
                <Loader2 className="w-5 h-5 text-primary animate-spin" />
              )}
              {step.status === 'pending' && (
                <Circle className="w-5 h-5 text-muted-foreground/40" />
              )}
            </div>
            <div className="flex-1">
              <div className={`text-sm ${
                step.status === 'done' ? 'text-muted-foreground line-through' :
                step.status === 'current' ? 'font-semibold text-primary' :
                'text-muted-foreground'
              }`}>
                {step.labelAr}
              </div>
              {step.status === 'current' && (
                <div className="text-xs text-muted-foreground mt-0.5">قيد التنفيذ...</div>
              )}
            </div>
            {idx < steps.length - 1 && (
              <div className="absolute right-[10px] mt-5 w-px h-3 bg-border" />
            )}
          </div>
        ))}
      </div>

      {contract.data?.trackingId && (
        <div className="bg-muted/50 p-2 rounded text-xs text-muted-foreground text-center">
          رقم التتبع: <span className="font-mono text-primary">{contract.data.trackingId as string}</span>
        </div>
      )}

      <div className="flex gap-2 pt-2 border-t">
        {contract.actions.map((action) => (
          <Button
            key={action.id}
            variant={action.type === 'primary' ? 'default' : 'outline'}
            size="sm"
            onClick={() => onAction?.(action.capabilityId, action.payload)}
          >
            {action.labelAr}
          </Button>
        ))}
      </div>
    </div>
  );
}

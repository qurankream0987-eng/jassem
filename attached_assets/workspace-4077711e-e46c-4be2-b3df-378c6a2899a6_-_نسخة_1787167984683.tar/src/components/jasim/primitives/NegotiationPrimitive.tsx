// 🤝 NegotiationPrimitive — bid/counter-offer room

'use client';

import { useState } from 'react';
import { Handshake, TrendingDown, Clock, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import type { PrimitiveProps } from '../PrimitiveRegistry';

export function NegotiationPrimitive({ contract, onAction }: PrimitiveProps) {
  const originalPrice = (contract.data?.originalPrice as number) || 0;
  const proposedPrice = (contract.data?.proposedPrice as number) || 0;
  const discountPercent = (contract.data?.discountPercent as number) || 0;
  const sellerLikelyToAccept = contract.data?.sellerLikelyToAccept as boolean;
  const [offer, setOffer] = useState(proposedPrice.toString());
  const [note, setNote] = useState('');

  const offerNum = parseFloat(offer) || 0;
  const currentDiscount = originalPrice > 0 ? Math.round(((originalPrice - offerNum) / originalPrice) * 100) : 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Handshake className="w-4 h-4 text-amber-500" />
        <h3 className="font-semibold">{contract.titleAr}</h3>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <div className="bg-muted/50 p-3 rounded-lg text-center">
          <div className="text-xs text-muted-foreground mb-1">السعر الأصلي</div>
          <div className="text-xl font-bold line-through text-muted-foreground">{originalPrice} د.ك</div>
        </div>
        <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 p-3 rounded-lg text-center">
          <div className="text-xs text-amber-700 dark:text-amber-400 mb-1">العرض المقترح</div>
          <div className="text-xl font-bold text-amber-700 dark:text-amber-400">{proposedPrice} د.ك</div>
        </div>
      </div>

      <div className="space-y-1">
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">نسبة الخصم المقترح</span>
          <span className="font-bold">{discountPercent}%</span>
        </div>
        <Progress value={discountPercent} max={50} className="h-2" />
      </div>

      {sellerLikelyToAccept !== undefined && (
        <Alert className={sellerLikelyToAccept
          ? 'border-emerald-500/30 bg-emerald-50/50 dark:bg-emerald-950/20'
          : 'border-amber-500/30 bg-amber-50/50 dark:bg-amber-950/20'}>
          {sellerLikelyToAccept ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          ) : (
            <Clock className="w-4 h-4 text-amber-600" />
          )}
          <AlertDescription className="text-xs">
            {sellerLikelyToAccept
              ? '📈 تحليل جاسم: البائع على الأرجح سيقبل هذا العرض بناءً على سلوكه السابق.'
              : '⚠️ تحليل جاسم: البائع قد يرفض هذا العرض. يُنصح برفع عرضك قليلاً.'}
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-3">
        <div className="space-y-1.5">
          <Label htmlFor="offer" className="text-xs flex items-center gap-1">
            <TrendingDown className="w-3 h-3" /> عرضك (د.ك)
          </Label>
          <Input
            id="offer"
            type="number"
            value={offer}
            onChange={(e) => setOffer(e.target.value)}
            dir="ltr"
          />
          <div className="flex justify-between text-[10px] text-muted-foreground">
            <span>الخصم الحالي: {currentDiscount}%</span>
            <span>السعر العادل: ~{Math.round(originalPrice * 0.92 * 100) / 100} د.ك</span>
          </div>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="note" className="text-xs">ملاحظة للبائع</Label>
          <Textarea
            id="note"
            placeholder="اكتب رسالتك..."
            value={note}
            onChange={(e) => setNote(e.target.value)}
            dir="rtl"
            rows={2}
          />
        </div>
      </div>

      <div className="flex gap-2 pt-2 border-t">
        {contract.actions.map((action) => (
          <Button
            key={action.id}
            variant={
              action.type === 'success' ? 'default' :
              action.type === 'danger' ? 'destructive' :
              action.type === 'ghost' ? 'ghost' : 'outline'
            }
            size="sm"
            className={action.type === 'success' ? 'flex-1' : ''}
            onClick={() => onAction?.(action.capabilityId, { offer: offerNum, note })}
          >
            {action.labelAr}
            {action.confirmation && <Badge variant="secondary" className="text-[10px] mr-2">يحتاج تأكيد</Badge>}
          </Button>
        ))}
      </div>
    </div>
  );
}

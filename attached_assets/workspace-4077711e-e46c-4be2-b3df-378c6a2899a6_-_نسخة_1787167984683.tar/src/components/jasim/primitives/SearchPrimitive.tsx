// 🔍 SearchPrimitive — renders search form with dynamic fields

'use client';

import { useState } from 'react';
import { Search, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import type { PrimitiveProps } from '../PrimitiveRegistry';

export function SearchPrimitive({ contract, onAction }: PrimitiveProps) {
  const [values, setValues] = useState<Record<string, string>>({});

  const setField = (name: string, value: string) => {
    setValues((v) => ({ ...v, [name]: value }));
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Search className="w-4 h-4 text-primary" />
        <h3 className="font-semibold">{contract.titleAr}</h3>
        {contract.subtitle && <span className="text-xs text-muted-foreground">— {contract.subtitle}</span>}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {contract.fields.map((field) => (
          <div key={field.id} className="space-y-1.5">
            <Label htmlFor={field.id} className="text-xs">
              {field.labelAr}
              {field.validation?.required && <span className="text-red-500 mr-1">*</span>}
            </Label>
            {field.type === 'select' && field.options ? (
              <Select onValueChange={(v) => setField(field.name, v)}>
                <SelectTrigger id={field.id}>
                  <SelectValue placeholder={field.placeholder || `اختر ${field.labelAr}`} />
                </SelectTrigger>
                <SelectContent>
                  {field.options.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.labelAr}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <Input
                id={field.id}
                type={field.type === 'number' ? 'number' : 'text'}
                placeholder={field.placeholder || field.labelAr}
                value={values[field.name] ?? ((field.defaultValue as string) || '')}
                onChange={(e) => setField(field.name, e.target.value)}
                dir="rtl"
              />
            )}
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-2 pt-2">
        {contract.actions.map((action) => (
          <Button
            key={action.id}
            variant={action.type === 'primary' ? 'default' : 'outline'}
            size="sm"
            onClick={() => onAction?.(action.capabilityId, { values, ...action.payload })}
          >
            {action.icon === 'search' && <Search className="w-4 h-4 ml-1" />}
            {action.icon === 'filter' && <Filter className="w-4 h-4 ml-1" />}
            {action.labelAr}
          </Button>
        ))}
      </div>
    </div>
  );
}

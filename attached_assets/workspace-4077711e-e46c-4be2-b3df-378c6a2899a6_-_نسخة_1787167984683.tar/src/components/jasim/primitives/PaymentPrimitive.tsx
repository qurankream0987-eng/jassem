// 💳 PaymentPrimitive — payment form with escrow indicator

'use client';

import { useState } from 'react';
import { Shield, CreditCard, Lock, Wallet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import type { PrimitiveProps } from '../PrimitiveRegistry';

export function PaymentPrimitive({ contract, onAction }: PrimitiveProps) {
  const [paymentMethod, setPaymentMethod] = useState('knet');
  const amount = (contract.data?.amount as number) || 0;
  const currency = (contract.data?.currency as string) || 'KWD';
  const escrowEnabled = contract.data?.escrowEnabled as boolean;
  const itemDescription = (contract.data?.itemDescription as string) || '';

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <CreditCard className="w-4 h-4 text-primary" />
        <h3 className="font-semibold">{contract.titleAr}</h3>
      </div>

      {itemDescription && (
        <div className="bg-muted/50 p-3 rounded-lg">
          <div className="text-xs text-muted-foreground">عنصر الدفع</div>
          <div className="font-medium">{itemDescription}</div>
        </div>
      )}

      <div className="bg-primary/5 border border-primary/20 rounded-lg p-3 text-center">
        <div className="text-xs text-muted-foreground mb-1">المبلغ الإجمالي</div>
        <div className="text-3xl font-bold text-primary">
          {amount} {currency === 'KWD' ? 'د.ك' : currency}
        </div>
      </div>

      {escrowEnabled && (
        <Alert className="border-emerald-500/30 bg-emerald-50/50 dark:bg-emerald-950/20">
          <Shield className="w-4 h-4 text-emerald-600" />
          <AlertDescription className="text-emerald-700 dark:text-emerald-400 text-xs">
            🛡️ معاملة محمية بالضمان (Escrow) — لن يُطلق المبلغ للبائع إلا بعد تأكيدك لاستلام المنتج.
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-3">
        <div className="space-y-1.5">
          <Label htmlFor="payment_method" className="text-xs">طريقة الدفع</Label>
          <Select value={paymentMethod} onValueChange={setPaymentMethod}>
            <SelectTrigger id="payment_method">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="knet">
                <span className="flex items-center gap-2"><CreditCard className="w-3 h-3" /> KNET</span>
              </SelectItem>
              <SelectItem value="visa">
                <span className="flex items-center gap-2"><CreditCard className="w-3 h-3" /> Visa / Mastercard</span>
              </SelectItem>
              <SelectItem value="wallet">
                <span className="flex items-center gap-2"><Wallet className="w-3 h-3" /> محفظة جاسم</span>
              </SelectItem>
              <SelectItem value="apple_pay">
                <span className="flex items-center gap-2"><Wallet className="w-3 h-3" /> Apple Pay</span>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        {paymentMethod !== 'wallet' && paymentMethod !== 'apple_pay' && (
          <>
            <div className="space-y-1.5">
              <Label htmlFor="card_number" className="text-xs">رقم البطاقة</Label>
              <Input id="card_number" placeholder="0000 0000 0000 0000" dir="ltr" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <Label htmlFor="expiry" className="text-xs">تاريخ الانتهاء</Label>
                <Input id="expiry" placeholder="MM/YY" dir="ltr" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cvv" className="text-xs">CVV</Label>
                <Input id="cvv" placeholder="•••" type="password" dir="ltr" maxLength={4} />
              </div>
            </div>
          </>
        )}

        {paymentMethod === 'wallet' && (
          <Alert>
            <Wallet className="w-4 h-4" />
            <AlertDescription className="text-xs">
              سيتم خصم المبلغ من رصيد محفظتك الحالي.
            </AlertDescription>
          </Alert>
        )}
      </div>

      <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2 border-t">
        <Lock className="w-3 h-3" />
        <span>معاملتك مشفّرة بـ SSL 256-bit</span>
        <Badge variant="outline" className="text-[10px]">PCI-DSS</Badge>
      </div>

      <div className="flex gap-2">
        {contract.actions.map((action) => (
          <Button
            key={action.id}
            variant={
              action.type === 'primary' ? 'default' :
              action.type === 'danger' ? 'destructive' :
              action.type === 'ghost' ? 'ghost' : 'outline'
            }
            size="sm"
            className={action.type === 'primary' ? 'w-full' : ''}
            onClick={() => onAction?.(action.capabilityId, { amount, paymentMethod, ...action.payload })}
          >
            {action.labelAr}
          </Button>
        ))}
      </div>
    </div>
  );
}

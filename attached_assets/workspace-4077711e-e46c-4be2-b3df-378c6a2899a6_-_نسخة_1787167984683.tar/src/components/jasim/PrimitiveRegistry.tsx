// ============================================================================
// 🎨 JASIM — Primitive Registry
// Maps UIContract.primitiveType → React component
// NO domain-specific components — only generic primitives
// ============================================================================

'use client';

import type { UIContract } from '@/lib/jasim/types';
import { SearchPrimitive } from './primitives/SearchPrimitive';
import { ResultsPrimitive } from './primitives/ResultsPrimitive';
import { ComparisonPrimitive } from './primitives/ComparisonPrimitive';
import { GalleryPrimitive } from './primitives/GalleryPrimitive';
import { FormPrimitive } from './primitives/FormPrimitive';
import { PaymentPrimitive } from './primitives/PaymentPrimitive';
import { NegotiationPrimitive } from './primitives/NegotiationPrimitive';
import { ProgressPrimitive } from './primitives/ProgressPrimitive';
import { ConfirmationPrimitive } from './primitives/ConfirmationPrimitive';
import { StatusPrimitive } from './primitives/StatusPrimitive';
import { ChatPrimitive } from './primitives/ChatPrimitive';
import { DashboardPrimitive } from './primitives/DashboardPrimitive';

export interface PrimitiveProps {
  contract: UIContract;
  onAction?: (actionId: string, payload?: Record<string, unknown>) => void;
}

const REGISTRY: Record<string, React.ComponentType<PrimitiveProps>> = {
  search: SearchPrimitive,
  results: ResultsPrimitive,
  comparison: ComparisonPrimitive,
  gallery: GalleryPrimitive,
  form: FormPrimitive,
  payment: PaymentPrimitive,
  negotiation: NegotiationPrimitive,
  progress: ProgressPrimitive,
  confirmation: ConfirmationPrimitive,
  status: StatusPrimitive,
  chat: ChatPrimitive,
  dashboard: DashboardPrimitive,
};

export function PrimitiveRenderer({ contract, onAction }: PrimitiveProps) {
  const Component = REGISTRY[contract.primitiveType] || StatusPrimitive;
  return <Component contract={contract} onAction={onAction} />;
}

export function hasPrimitive(type: string): boolean {
  return type in REGISTRY;
}

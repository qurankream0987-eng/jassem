// 🫧 Bubble.tsx — Wraps a UIContract with DNA-aware theme, glow, badges
// Shows: intent type, DNA lineage, Islamic compliance, human soul state, workflow progress

'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { Dna, Shield, Brain, Sparkles, ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { PrimitiveRenderer } from './PrimitiveRegistry';
import type { UIContract, ChatMessage } from '@/lib/jasim/types';
import { EMOTION_ICONS, TONE_STYLES } from '@/lib/jasim/human-soul';

interface BubbleProps {
  message: ChatMessage;
  contract: UIContract;
  onAction?: (actionId: string, payload?: Record<string, unknown>) => void;
}

export function Bubble({ message, contract, onAction }: BubbleProps) {
  const [expanded, setExpanded] = useState(false);
  const [showDebug, setShowDebug] = useState(false);

  const theme = contract.theme || {
    primary: '#800020', secondary: '#D4AF37', accent: '#FFD700', glow: '#800020',
  };

  const tone = message.soul?.voiceTone;
  const toneStyle = tone ? TONE_STYLES[tone] : null;
  const emotion = message.soul?.emotionalState;
  const emotionIcon = emotion ? EMOTION_ICONS[emotion] : null;

  const isBlocked = contract.primitiveType === 'status' && contract.titleAr.includes('حظر');
  const isEmergency = message.soul?.crisisDetected;
  const isUser = message.role === 'user';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className={`relative rounded-2xl border backdrop-blur-md overflow-hidden ${
        isUser ? 'bg-primary text-primary-foreground' : 'bg-card'
      } ${toneStyle ? toneStyle.border : 'border-border'}`}
      style={{
        boxShadow: `0 4px 24px -8px ${theme.glow}40`,
      }}
    >
      {/* Glow accent strip */}
      <div
        className="absolute inset-x-0 top-0 h-1"
        style={{
          background: `linear-gradient(90deg, ${theme.primary}, ${theme.secondary}, ${theme.accent})`,
        }}
      />

      {/* Header: DNA badge + intent + soul + islamic */}
      <div className="flex items-center justify-between px-4 pt-3 pb-2 border-b bg-muted/30">
        <div className="flex items-center gap-2 flex-wrap">
          <Badge variant="outline" className="text-[10px] gap-1" style={{ borderColor: theme.primary }}>
            <Dna className="w-3 h-3" style={{ color: theme.primary }} />
            {contract.bubbleType.toUpperCase()}
          </Badge>
          {contract.metadata.capabilityId && (
            <Badge variant="secondary" className="text-[10px]">
              {contract.metadata.capabilityId}
            </Badge>
          )}
          {message.intent && (
            <Badge variant="outline" className="text-[10px]">
              🎯 {message.intent.type}
            </Badge>
          )}
          {toneStyle && (
            <Badge variant="outline" className={`text-[10px] ${toneStyle.text} ${toneStyle.bg}`}>
              💬 {toneStyle.labelAr}
            </Badge>
          )}
          {emotionIcon && emotion && (
            <Badge variant="outline" className="text-[10px]">
              {emotionIcon} {emotion}
            </Badge>
          )}
          {message.islamicCheck && (
            <Badge
              variant="outline"
              className={`text-[10px] ${
                message.islamicCheck.isCompliant
                  ? 'border-emerald-500/30 text-emerald-600 bg-emerald-50/50'
                  : 'border-red-500/30 text-red-600 bg-red-50/50'
              }`}
            >
              <Shield className="w-3 h-3" />
              {message.islamicCheck.isCompliant ? 'حلال' : 'محظور'}
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={() => setShowDebug(!showDebug)}
          >
            <Sparkles className="w-3 h-3" />
          </Button>
          {contract.layout.type !== 'vertical' && (
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => setExpanded(!expanded)}
            >
              {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </Button>
          )}
        </div>
      </div>

      {/* Body: the actual primitive */}
      <div className={`p-4 ${expanded ? 'max-h-[600px]' : ''}`}>
        <PrimitiveRenderer contract={contract} onAction={onAction} />
      </div>

      {/* Debug panel */}
      <AnimatePresence>
        {showDebug && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t bg-muted/50"
          >
            <div className="p-3 text-xs space-y-2">
              <div className="flex items-center gap-1 font-semibold">
                <Brain className="w-3 h-3" /> DNA Contract Metadata
              </div>
              <pre className="overflow-x-auto bg-background p-2 rounded text-[10px]" dir="ltr">
                {JSON.stringify({
                  id: contract.id,
                  primitiveType: contract.primitiveType,
                  bubbleType: contract.bubbleType,
                  metadata: contract.metadata,
                  dna: message.intent?.causalContext,
                  intent: message.intent,
                  soul: message.soul,
                  islamic: message.islamicCheck,
                }, null, 2)}
              </pre>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

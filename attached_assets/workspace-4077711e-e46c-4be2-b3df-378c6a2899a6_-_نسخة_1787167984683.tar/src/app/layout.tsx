import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "JASIM v34.0 — Universal Generative Commercial Runtime",
  description: "نظام تشغيل تجاري توليدي واعٍ إسلامياً، يقرأ روح المستخدم، ويبني عوالم رقمية حية من النية الطبيعية.",
  keywords: ["JASIM", "Generative Runtime", "Islamic AI", "DNA-Aware", "Commercial Agent", "Arabic AI"],
  authors: [{ name: "JASIM Engine v34.0" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "JASIM v34.0 — Universal Generative Commercial Runtime",
    description: "DNA-Aware | Islamic Conscience | Human Soul | Generative Bubbles",
    siteName: "JASIM",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "JASIM v34.0",
    description: "Universal Generative Commercial Runtime",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}

// ============================================================================
// 🧬 JASIM v34.0 — Main Chat Interface
// Universal Generative Commercial Runtime — Live Demo
// ============================================================================

'use client';

import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Send, Sparkles, Dna, Shield, Brain, RotateCcw, ChevronDown,
  Loader2, Eye, EyeOff, Trash2, Zap, MessageSquare, Settings2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Toaster, toast } from 'sonner';
import { Bubble } from '@/components/jasim/Bubble';
import { useJasimStore } from '@/lib/jasim/store';
import { SUGGESTION_EXAMPLES } from '@/lib/jasim/suggestions';

export default function JasimPage() {
  const [input, setInput] = useState('');
  const [showExamples, setShowExamples] = useState(true);
  const [stats, setStats] = useState({ blocked: 0, emergency: 0, workflows: 0 });
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const { messages, isLoading, sendMessage, clearChat, error } = useJasimStore();

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  // Stats calculation
  useEffect(() => {
    let blocked = 0, emergency = 0, workflows = 0;
    for (const msg of messages) {
      if (msg.role === 'assistant') {
        if (msg.islamicCheck && !msg.islamicCheck.isCompliant) blocked++;
        if (msg.soul?.crisisDetected) emergency++;
        if (msg.workflow) workflows++;
      }
    }
    setStats({ blocked, emergency, workflows });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const text = input;
    setInput('');
    setShowExamples(false);
    await sendMessage(text);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleExampleClick = (text: string) => {
    setInput(text);
    inputRef.current?.focus();
  };

  const handleAction = (actionId: string, payload?: Record<string, unknown>) => {
    toast.info(`🔄 تنفيذ: ${actionId}`, {
      description: payload ? JSON.stringify(payload).slice(0, 100) : undefined,
    });
    // In a real system, this would call the API to execute the next capability
    // For demo, we treat it as the next message
    if (actionId && actionId !== 'CANCEL') {
      setTimeout(() => {
        sendMessage(`${actionId}: ${payload?.offer || payload?.amount || 'متابعة'}`);
      }, 600);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background via-background to-muted/30">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-red-900 via-red-700 to-amber-500 flex items-center justify-center text-white font-bold shadow-lg shadow-red-900/30">
              <Dna className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold leading-tight">جاسم v34.0</h1>
              <p className="text-[10px] text-muted-foreground">Universal Generative Commercial Runtime</p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className="gap-1 text-[10px]">
              <Dna className="w-3 h-3 text-purple-500" />
              DNA-Aware
            </Badge>
            <Badge variant="outline" className="gap-1 text-[10px]">
              <Shield className="w-3 h-3 text-emerald-500" />
              Islamic Conscience
            </Badge>
            <Badge variant="outline" className="gap-1 text-[10px]">
              <Brain className="w-3 h-3 text-amber-500" />
              Human Soul
            </Badge>
            <Separator orientation="vertical" className="h-6" />
            <div className="flex items-center gap-1 text-xs">
              <span className="text-muted-foreground">الجلسة:</span>
              <code className="bg-muted px-1.5 py-0.5 rounded text-[10px]">
                {useJasimStore.getState().sessionId.slice(0, 12)}
              </code>
            </div>
            <Button variant="ghost" size="icon" onClick={clearChat} title="محادثة جديدة">
              <RotateCcw className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Stats Bar */}
        {messages.length > 0 && (
          <div className="container mx-auto px-4 pb-2 flex items-center gap-3 text-xs flex-wrap">
            <span className="flex items-center gap-1 text-muted-foreground">
              <MessageSquare className="w-3 h-3" />
              {messages.length} رسالة
            </span>
            <span className="flex items-center gap-1 text-emerald-600">
              <Shield className="w-3 h-3" />
              {stats.blocked} محظور
            </span>
            <span className="flex items-center gap-1 text-red-600">
              <Zap className="w-3 h-3" />
              {stats.emergency} طوارئ
            </span>
            <span className="flex items-center gap-1 text-purple-600">
              <Dna className="w-3 h-3" />
              {stats.workflows} سير عمل
            </span>
          </div>
        )}
      </header>

      {/* Chat Area */}
      <main className="flex-1 container mx-auto px-4 py-6 flex flex-col max-w-4xl w-full">
        {messages.length === 0 && showExamples && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex-1 flex flex-col items-center justify-center text-center py-12 space-y-8"
          >
            <div className="space-y-3 max-w-2xl">
              <h2 className="text-3xl font-bold bg-gradient-to-l from-red-900 via-amber-700 to-amber-500 bg-clip-text text-transparent">
                النظام التوليدي التجاري العالمي
              </h2>
              <p className="text-muted-foreground">
                جاسم لا يعرض تطبيقاً جاهزاً. جاسم يفهم هدفك، يبني عالماً رقمياً، يُنشئ DNA، يُنفذ سير العمل، ويولد الواجهة ديناميكياً.
                <br />
                <span className="text-xs">اكتب أي هدف تجاري طبيعي بالعربية أو الإنجليزية، وشاهد جاسم يولّد عالمك.</span>
              </p>
            </div>

            <div className="w-full max-w-2xl">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  مهام لم تُبرمج مسبقاً — اختبرها
                </h3>
                <Button variant="ghost" size="sm" onClick={() => setShowExamples(false)}>
                  <EyeOff className="w-3 h-3 ml-1" /> إخفاء
                </Button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {SUGGESTION_EXAMPLES.map((ex, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleExampleClick(ex.text)}
                    className="group text-right p-3 rounded-lg border border-border hover:border-primary/50 hover:bg-accent/30 transition-all text-sm"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-muted-foreground font-mono">#{ex.intent}</span>
                      <ChevronDown className="w-3 h-3 rotate-90 text-muted-foreground group-hover:text-primary" />
                    </div>
                    <div className="font-medium">{ex.label}</div>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{ex.text}</p>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Messages */}
        {messages.length > 0 && (
          <ScrollArea className="flex-1 -mx-2" ref={scrollRef}>
            <div className="px-2 space-y-4 pb-6">
              <AnimatePresence mode="popLayout">
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${message.role === 'user' ? 'justify-start' : 'justify-end'}`}
                  >
                    <div className={`max-w-[90%] ${message.role === 'user' ? 'max-w-md' : 'flex-1 max-w-3xl'}`}>
                      {message.role === 'user' && message.text && (
                        <div className="bg-primary text-primary-foreground rounded-2xl px-4 py-2 text-sm" dir="auto">
                          {message.text}
                        </div>
                      )}
                      {message.role === 'assistant' && (
                        <div className="space-y-3">
                          {message.text && (
                            <div className="bg-muted/50 border border-border rounded-2xl px-4 py-2 text-sm" dir="auto">
                              {message.text}
                            </div>
                          )}
                          {message.contracts.map((contract) => (
                            <Bubble
                              key={contract.id}
                              message={message}
                              contract={contract}
                              onAction={handleAction}
                            />
                          ))}
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              {isLoading && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex justify-end"
                >
                  <div className="bg-card border rounded-2xl px-4 py-3 flex items-center gap-2 text-sm">
                    <Loader2 className="w-4 h-4 animate-spin text-primary" />
                    <span>جاسم يفكر، يبني الـ DNA، يُجمع الـ Workflow...</span>
                  </div>
                </motion.div>
              )}

              {error && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-end">
                  <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-2xl px-4 py-2 text-sm text-red-700 dark:text-red-400">
                    ⚠️ {error}
                  </div>
                </motion.div>
              )}
            </div>
          </ScrollArea>
        )}
      </main>

      {/* Input Bar */}
      <footer className="border-t bg-card/50 backdrop-blur-md sticky bottom-0">
        <div className="container mx-auto px-4 py-3 max-w-4xl">
          {messages.length > 0 && (
            <div className="flex items-center gap-2 mb-2 overflow-x-auto pb-1">
              {SUGGESTION_EXAMPLES.slice(0, 4).map((ex, idx) => (
                <button
                  key={idx}
                  onClick={() => handleExampleClick(ex.text)}
                  className="shrink-0 text-xs px-2 py-1 rounded-full border border-border hover:border-primary/50 hover:bg-accent/30 transition-colors"
                >
                  {ex.label}
                </button>
              ))}
            </div>
          )}
          <div className="flex items-end gap-2">
            <Textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="اكتب أي هدف تجاري... (مثال: أبحث عن كامري 2023 أقل من 8000 دينار)"
              className="min-h-[44px] max-h-32 resize-none"
              rows={1}
              disabled={isLoading}
            />
            <Button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              size="icon"
              className="h-11 w-11 shrink-0"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            </Button>
          </div>
          <div className="flex items-center justify-between mt-2 text-[10px] text-muted-foreground">
            <span>Enter للإرسال • Shift+Enter لسطر جديد</span>
            <span>JASIM Runtime v34.0 • Powered by DNA-Aware Generative Engine</span>
          </div>
        </div>
      </footer>

      <Toaster position="top-center" dir="rtl" />
    </div>
  );
}

// ============================================================================
// 🌐 JASIM API — /api/jasim/seed
// POST: Seed the database with demo data (users, listings, capabilities)
// ============================================================================

import { NextRequest, NextResponse } from 'next/server';
import { seedDatabase } from '@/lib/jasim';

export const runtime = 'nodejs';

export async function POST(_request: NextRequest) {
  try {
    const result = await seedDatabase();
    return NextResponse.json({
      ok: true,
      seeded: result,
      message: `Seeded ${result.users} users, ${result.listings} listings, ${result.capabilities} capabilities`,
    });
  } catch (error) {
    console.error('[JASIM] Seed error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 },
    );
  }
}

export async function GET() {
  return NextResponse.json({
    ok: true,
    endpoint: 'POST to seed the database',
  });
}

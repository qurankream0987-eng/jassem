// ============================================================================
// 🌐 JASIM API — /api/jasim/listings
// GET: List listings (filterable by type, status, price range)
// POST: Create a new listing directly
// ============================================================================

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get('type');
  const status = searchParams.get('status') || 'active';
  const minPrice = searchParams.get('minPrice');
  const maxPrice = searchParams.get('maxPrice');
  const location = searchParams.get('location');
  const limit = parseInt(searchParams.get('limit') || '50');

  const where: any = { status };
  if (type) where.type = type;
  if (location) where.location = { contains: location };
  if (minPrice || maxPrice) {
    where.price = {};
    if (minPrice) where.price.gte = parseFloat(minPrice);
    if (maxPrice) where.price.lte = parseFloat(maxPrice);
  }

  const listings = await db.listing.findMany({
    where,
    take: limit,
    orderBy: { createdAt: 'desc' },
    include: { seller: { select: { name: true, verified: true, trustScore: true } } },
  });

  // Parse dataJson back into structured items
  const items = listings.map((l) => {
    try {
      const data = JSON.parse(l.dataJson);
      return {
        id: l.id,
        type: l.type,
        title: l.title,
        titleAr: l.titleAr,
        price: l.price,
        currency: l.currency,
        location: l.location,
        status: l.status,
        createdAt: l.createdAt,
        ...data,
        seller: l.seller,
      };
    } catch {
      return l;
    }
  });

  return NextResponse.json({ listings: items, count: items.length });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { sellerId, type, title, titleAr, data, price, location } = body;

    if (!sellerId || !type || !title) {
      return NextResponse.json(
        { error: 'sellerId, type, and title are required' },
        { status: 400 },
      );
    }

    const listing = await db.listing.create({
      data: {
        sellerId,
        type,
        title,
        titleAr: titleAr || title,
        dataJson: JSON.stringify(data || {}),
        location: location || 'الكويت',
        price: price || 0,
        currency: 'KWD',
        status: 'active',
      },
    });

    await db.event.create({
      data: {
        type: 'ListingCreated',
        payloadJson: JSON.stringify({ listingId: listing.id }),
      },
    });

    return NextResponse.json({ ok: true, listing });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 },
    );
  }
}

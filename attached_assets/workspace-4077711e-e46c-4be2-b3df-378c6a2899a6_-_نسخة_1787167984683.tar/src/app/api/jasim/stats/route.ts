// ============================================================================
// 🌐 JASIM API — /api/jasim/stats
// GET: Real-time stats from the database
// ============================================================================

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

export async function GET() {
  try {
    const [
      totalUsers, totalListings, totalWorkflows, totalTransactions,
      activeListings, completedWorkflows, releasedTransactions, totalCapabilities,
      recentEvents,
    ] = await Promise.all([
      db.user.count(),
      db.listing.count(),
      db.workflow.count(),
      db.transaction.count(),
      db.listing.count({ where: { status: 'active' } }),
      db.workflow.count({ where: { status: 'completed' } }),
      db.transaction.count({ where: { status: 'released' } }),
      db.capability.count(),
      db.event.findMany({ take: 10, orderBy: { publishedAt: 'desc' } }),
    ]);

    const totalSalesAgg = await db.transaction.aggregate({
      _sum: { amount: true },
      where: { status: 'released' },
    });

    const listingsByType = await db.listing.groupBy({
      by: ['type'],
      _count: { type: true },
    });

    return NextResponse.json({
      totals: {
        users: totalUsers,
        listings: totalListings,
        workflows: totalWorkflows,
        transactions: totalTransactions,
        capabilities: totalCapabilities,
      },
      active: {
        listings: activeListings,
        workflows: completedWorkflows,
        transactions: releasedTransactions,
      },
      sales: {
        totalReleasedKwd: totalSalesAgg._sum.amount || 0,
      },
      listingsByType: listingsByType.map((l) => ({ type: l.type, count: l._count.type })),
      recentEvents: recentEvents.map((e) => ({
        type: e.type,
        publishedAt: e.publishedAt,
        payload: e.payloadJson ? JSON.parse(e.payloadJson) : {},
      })),
      timestamp: Date.now(),
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 },
    );
  }
}

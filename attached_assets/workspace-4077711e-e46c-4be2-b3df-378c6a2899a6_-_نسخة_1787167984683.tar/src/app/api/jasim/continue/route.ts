// ============================================================================
// 🌐 JASIM API — /api/jasim/continue
// POST: Continue a paused workflow by clicking a bubble action
// ============================================================================

import { NextRequest, NextResponse } from 'next/server';
import { continueWorkflow, registerAllExecutors } from '@/lib/jasim';

export const runtime = 'nodejs';

let initialized = false;
async function ensureInitialized() {
  if (initialized) return;
  registerAllExecutors();
  initialized = true;
}

export async function POST(request: NextRequest) {
  try {
    await ensureInitialized();

    const body = await request.json();
    const { workflowId, actionId, payload } = body as {
      workflowId: string;
      actionId: string;
      payload?: Record<string, unknown>;
    };

    if (!workflowId || !actionId) {
      return NextResponse.json(
        { error: 'workflowId and actionId are required' },
        { status: 400 },
      );
    }

    const result = await continueWorkflow(workflowId, actionId, payload);

    return NextResponse.json({
      ok: true,
      message: result.message,
      isComplete: result.isComplete,
      timestamp: Date.now(),
    });
  } catch (error) {
    console.error('[JASIM] Continue API error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 },
    );
  }
}

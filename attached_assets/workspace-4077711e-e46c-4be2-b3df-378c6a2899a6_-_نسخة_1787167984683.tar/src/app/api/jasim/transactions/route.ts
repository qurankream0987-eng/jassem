// ============================================================================
// 🌐 JASIM API — /api/jasim/transactions
// GET: List transactions, POST: create, PATCH: release escrow
// ============================================================================

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { releaseEscrow, registerAllExecutors } from '@/lib/jasim';

export const runtime = 'nodejs';

let initialized = false;
async function ensureInitialized() {
  if (initialized) return;
  registerAllExecutors();
  initialized = true;
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const status = searchParams.get('status');
  const userId = searchParams.get('userId');
  const limit = parseInt(searchParams.get('limit') || '50');

  const where: any = {};
  if (status) where.status = status;
  if (userId) {
    where.OR = [{ buyerId: userId }, { sellerId: userId }];
  }

  const transactions = await db.transaction.findMany({
    where,
    take: limit,
    orderBy: { initiatedAt: 'desc' },
    include: {
      buyer: { select: { name: true } },
      seller: { select: { name: true } },
      listing: { select: { title: true, titleAr: true, type: true } },
    },
  });

  return NextResponse.json({ transactions, count: transactions.length });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { buyerId, sellerId, listingId, amount } = body;

    if (!buyerId || !sellerId || !listingId || !amount) {
      return NextResponse.json(
        { error: 'buyerId, sellerId, listingId, amount are required' },
        { status: 400 },
      );
    }

    const transaction = await db.transaction.create({
      data: {
        buyerId,
        sellerId,
        listingId,
        amount,
        currency: 'KWD',
        commissionRate: 0.05,
        commissionAmount: amount * 0.05,
        sellerReceives: amount * 0.95,
        status: 'pending',
      },
    });

    await db.event.create({
      data: {
        type: 'TransactionInitiated',
        transactionId: transaction.id,
        payloadJson: JSON.stringify({ amount }),
      },
    });

    return NextResponse.json({ ok: true, transaction });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 },
    );
  }
}

export async function PATCH(request: NextRequest) {
  await ensureInitialized();
  try {
    const body = await request.json();
    const { transactionId, action } = body;

    if (action === 'release') {
      const result = await releaseEscrow(transactionId);
      return NextResponse.json(result);
    }

    return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 },
    );
  }
}

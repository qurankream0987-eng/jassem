// ============================================================================
// 🌐 JASIM API — /api/jasim/chat
// POST: Process a user goal via LLM + DNA + Workflow + DB persistence
// ============================================================================

import { NextRequest, NextResponse } from 'next/server';
import {
  processUserGoal,
  getSessionMessagesFromDb,
  registerAllExecutors,
} from '@/lib/jasim';
import { SUGGESTION_EXAMPLES } from '@/lib/jasim/suggestions';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

// ─── Initialize executors once (singleton) ─────────────────────────────────

let initialized = false;
async function ensureInitialized() {
  if (initialized) return;
  registerAllExecutors();
  initialized = true;
}

export async function POST(request: NextRequest) {
  try {
    await ensureInitialized();

    const body = await request.json();
    const { text, sessionId, userId } = body as {
      text: string;
      sessionId?: string;
      userId?: string;
    };

    if (!text || typeof text !== 'string' || text.trim().length === 0) {
      return NextResponse.json(
        { error: 'Text is required', code: 'INVALID_INPUT' },
        { status: 400 },
      );
    }

    const result = await processUserGoal(text.trim(), sessionId, userId);

    return NextResponse.json({
      ok: true,
      message: result.message,
      isComplete: result.isComplete,
      blocked: result.blocked,
      emergency: result.emergency,
      aiProvider: result.aiProvider,
      aiReal: result.aiReal,
      timestamp: Date.now(),
    });
  } catch (error) {
    console.error('[JASIM] Chat API error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Unknown error',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 },
    );
  }
}

export async function GET(request: NextRequest) {
  await ensureInitialized();
  const { searchParams } = new URL(request.url);
  const sessionId = searchParams.get('sessionId');
  const action = searchParams.get('action');

  if (action === 'examples') {
    return NextResponse.json({ examples: SUGGESTION_EXAMPLES });
  }

  if (action === 'history' && sessionId) {
    const messages = await getSessionMessagesFromDb(sessionId);
    return NextResponse.json({ messages, sessionId });
  }

  if (action === 'stats') {
    const [users, listings, workflows, transactions, capabilities] = await Promise.all([
      db.user.count(),
      db.listing.count(),
      db.workflow.count(),
      db.transaction.count(),
      db.capability.count(),
    ]);
    return NextResponse.json({
      users, listings, workflows, transactions, capabilities,
      timestamp: Date.now(),
    });
  }

  return NextResponse.json({
    ok: true,
    service: 'JASIM v34.0 — Universal Generative Commercial Runtime',
    version: '34.0',
    aiProvider: 'zai-glm-4-flash',
    db: 'SQLite (Prisma)',
    timestamp: Date.now(),
  });
}

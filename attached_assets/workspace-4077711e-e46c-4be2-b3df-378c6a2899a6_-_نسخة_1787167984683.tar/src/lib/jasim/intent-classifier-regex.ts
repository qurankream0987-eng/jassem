// ============================================================================
// 🧠 JASIM — Intent Classifier
// Multi-language: Arabic (Fusha/Gulf/Egyptian) + English
// Hybrid: Regex patterns + semantic keyword weighting
// ============================================================================

import type { IntentResult, IntentType, BubbleType } from './types';
import { validateIslamicConscience } from './islamic-conscience';

interface IntentPattern {
  intentType: IntentType;
  bubbleType: BubbleType;
  patterns: RegExp[];
  weight: number;
  priority?: 'high' | 'normal';
}

// ─── Language Detection ────────────────────────────────────────────────────

function detectLanguage(text: string): 'ar' | 'ar-gulf' | 'ar-egypt' | 'en' {
  if (/[a-zA-Z]/.test(text) && !/[\u0600-\u06FF]/.test(text)) return 'en';

  // Egyptian
  if (/عايز|هنروح|جعان|إيه|ده|دي|كده|أوي|طب/i.test(text)) return 'ar-egypt';

  // Gulf
  if (/ابي|يبل|كش|يبة|كيفك|شلونك|وايد|تبي/i.test(text)) return 'ar-gulf';

  return 'ar';
}

// ─── Entity Extractor ──────────────────────────────────────────────────────

interface ExtractedEntity {
  key: string;
  value: string;
  type: 'string' | 'number' | 'currency' | 'location' | 'time' | 'brand' | 'category';
}

function extractEntities(text: string): ExtractedEntity[] {
  const entities: ExtractedEntity[] = [];

  // Currency (Kuwaiti Dinar, Saudi Riyal, USD, etc.)
  const currencyMatch = text.match(/(\d+(?:[.,]\d+)?)\s*(?:دينار|د\.ك|kd|kwd|ريال|ر\.س|sar|درهم|درهم\s+إمارات|aed|دولار|\$|usd)/i);
  if (currencyMatch) {
    entities.push({ key: 'budget', value: currencyMatch[1], type: 'currency' });
  }

  // Year
  const yearMatch = text.match(/(?:سنة|موديل|model\s+year|year)\s*(\d{4})|(\d{4})/i);
  if (yearMatch) {
    const year = yearMatch[1] || yearMatch[2];
    if (year && parseInt(year) >= 1990 && parseInt(year) <= 2030) {
      entities.push({ key: 'year', value: year, type: 'number' });
    }
  }

  // Phone / Tablet brand
  const brandMatch = text.match(/(آيفون|iphone|سامسونج|samsung|هواوي|huawei|شاومي|xiaomi|أوبو|oppo|لينوفو|lenovo|dell|hp|asus|macbook| MacBook)/i);
  if (brandMatch) {
    entities.push({ key: 'brand', value: brandMatch[1], type: 'brand' });
  }

  // Car brand
  const carMatch = text.match(/(كامري|camry|كورولا|corolla|هيلوكس|hilux|هيونداي|hyundai|نيسان|nissan|تويوتا|toyota|مرسيدس|mercedes|بي\s+إم|bmw|أودي|audi|كيا|kia|ميتسوبيشي|mitsubishi)/i);
  if (carMatch) {
    entities.push({ key: 'carBrand', value: carMatch[1], type: 'brand' });
  }

  // Location
  const locationMatch = text.match(/(?:في|بـ|من|منطقة|حي|في\s+مدينة)\s*([A-Z\u0600-\u06FF][\u0600-\u06FFa-zA-Z\s]{2,30})/);
  if (locationMatch) {
    entities.push({ key: 'location', value: locationMatch[1].trim(), type: 'location' });
  }

  // Generic numeric
  const numbers = text.match(/\b\d+\b/g);
  if (numbers) {
    for (const n of numbers.slice(0, 3)) {
      entities.push({ key: `num_${entities.length}`, value: n, type: 'number' });
    }
  }

  return entities;
}

// ─── Intent Patterns (ordered by priority) ────────────────────────────────

const INTENT_PATTERNS: IntentPattern[] = [
  // Emergency (highest priority)
  {
    intentType: 'EMERGENCY',
    bubbleType: 'emergency',
    patterns: [
      /طوارئ|انقذوني|حريق|حادث|إسعاف|سرقة|نزيف|اختناق|heart\s+attack|emergency|911|ambulance/i,
    ],
    weight: 2.0,
    priority: 'high',
  },

  // Build Platform (B2B / advanced)
  {
    intentType: 'BUILD_PLATFORM',
    bubbleType: 'platform',
    patterns: [
      /ابنِ|أنشئ|اصنع\s+منصة|بناء\s+سوق|create\s+platform|build\s+marketplace|make\s+app|أريد\s+منصة/i,
    ],
    weight: 1.5,
    priority: 'high',
  },

  // Analyze
  {
    intentType: 'ANALYZE',
    bubbleType: 'analytics',
    patterns: [
      /حلل|إحصائيات|تقرير|رؤية|بياناتي|analyze|stats|report|insights|dashboard/i,
    ],
    weight: 1.2,
  },

  // Hire (recruitment)
  {
    intentType: 'HIRE',
    bubbleType: 'recruitment',
    patterns: [
      /وظف|أريد\s+موظف|أحتاج\s+فني|الك\s+وظيفة|عايز\s+شغل|hire|recruit|job|career/i,
    ],
    weight: 1.3,
  },

  // Sell
  {
    intentType: 'SELL',
    bubbleType: 'product',
    patterns: [
      /أريد\s+بيع|أبيع|اضافة\s+منتج|عرض\s+للبيع|sell|list\s+for\s+sale|publish\s+item/i,
    ],
    weight: 1.3,
  },

  // Buy
  {
    intentType: 'BUY',
    bubbleType: 'product',
    patterns: [
      /أريد\s+شراء|اشتري|أشتري|نبي\s+نشتري|عايز\s+أشتري|buy|purchase|order\s+now/i,
    ],
    weight: 1.3,
  },

  // Compare
  {
    intentType: 'COMPARE',
    bubbleType: 'product',
    patterns: [
      /قارن|مقارنة|أفضل|أي\s+أفضل|compare|versus|vs|which\s+is\s+better/i,
    ],
    weight: 1.4,
  },

  // Negotiate
  {
    intentType: 'NEGOTIATE',
    bubbleType: 'negotiation',
    patterns: [
      /فاوض|ساوم|تخفيض|نقص\s+السعر|negotiate|bargain|discount|lower\s+price|offer/i,
    ],
    weight: 1.4,
  },

  // Book
  {
    intentType: 'BOOK',
    bubbleType: 'restaurant',
    patterns: [
      /احجز|حجز|ميعاد|موعد|book|reserve|appointment/i,
    ],
    weight: 1.3,
  },

  // Pay
  {
    intentType: 'PAY',
    bubbleType: 'payment',
    patterns: [
      /ادفع|دفع|دفعية|تحويل|pay|payment|transfer|checkout|knet|visa/i,
    ],
    weight: 1.5,
    priority: 'high',
  },

  // Deliver
  {
    intentType: 'DELIVER',
    bubbleType: 'delivery',
    patterns: [
      /وصل|توصيل|سائق|شحنة|طلبي|deliver|shipping|track|driver|courier/i,
    ],
    weight: 1.2,
  },

  // ─── Domain-specific searches ─────────────────────────────────────────

  // Food / Restaurant
  {
    intentType: 'SEARCH',
    bubbleType: 'food',
    patterns: [
      /جوعان|اكل|طعام|مطعم|برياني|مجبوس|مندي|فطور|غداء|عشاء|hungry|food|eat|meal|restaurant/i,
    ],
    weight: 1.4,
  },
  {
    intentType: 'SEARCH',
    bubbleType: 'pharmacy',
    patterns: [
      /صيدلية|دواء|علاج|وصفة|فيتامين|مريض|وجع|pharmacy|medicine|drug|pill|prescription/i,
    ],
    weight: 1.4,
  },
  {
    intentType: 'SEARCH',
    bubbleType: 'grocery',
    patterns: [
      /بقالة|سوبرماركت|خضار|فاكهة|لحوم|تمور|grocery|supermarket|vegetable|fruit/i,
    ],
    weight: 1.4,
  },
  {
    intentType: 'SEARCH',
    bubbleType: 'fashion',
    patterns: [
      /ملابس|موضة|أزياء|فستان|قميص|حذاء|عباية|شيلة|fashion|clothes|dress|shirt|outfit/i,
    ],
    weight: 1.4,
  },
  {
    intentType: 'SEARCH',
    bubbleType: 'real_estate',
    patterns: [
      /عقار|شقة|بيت|منزل|فيلا|أرض|للايجار|للبيع|real\s+estate|apartment|house|villa|rent|property/i,
    ],
    weight: 1.4,
  },
  {
    intentType: 'SEARCH',
    bubbleType: 'travel',
    patterns: [
      /سفر|طيران|رحلة|طيران|حجز\s+طيارة|flight|travel|trip|book\s+flight/i,
    ],
    weight: 1.4,
  },
  {
    intentType: 'SEARCH',
    bubbleType: 'cinema',
    patterns: [
      /سينما|فيلم|سينمات|كواليفيلم|cinema|movie|film|theater/i,
    ],
    weight: 1.4,
  },
  {
    intentType: 'SEARCH',
    bubbleType: 'product',
    patterns: [
      /لابتوب|موبايل|جوال|تابلت|سماعات|كاميرا|laptop|phone|tablet|headphone|camera|electronics|lenovo|iphone/i,
    ],
    weight: 1.3,
  },
  // Generic car search
  {
    intentType: 'SEARCH',
    bubbleType: 'product',
    patterns: [
      /سيارة|كامري|لاند\s+كروزر|هيلوكس|car|vehicle|auto|toyota/i,
    ],
    weight: 1.2,
  },

  // Default CHAT
  {
    intentType: 'CHAT',
    bubbleType: 'chat',
    patterns: [
      /مرحبا|السلام|اهلا|howdy|hello|hi|hey|chat|talk/i,
    ],
    weight: 0.5,
  },
];

// ─── Main Classifier ──────────────────────────────────────────────────────

export function classifyIntent(text: string): IntentResult {
  const language = detectLanguage(text);
  const islamicCheck = validateIslamicConscience(text);
  const entities = extractEntities(text);

  // Find best matching pattern
  let bestMatch: { pattern: IntentPattern; confidence: number } | null = null;

  for (const pattern of INTENT_PATTERNS) {
    let matchedCount = 0;
    for (const re of pattern.patterns) {
      if (re.test(text)) {
        matchedCount++;
      }
    }
    if (matchedCount > 0) {
      const baseConfidence = pattern.weight / 2;
      const matchConfidence = Math.min(1, baseConfidence * matchedCount);
      if (!bestMatch || matchConfidence > bestMatch.confidence) {
        bestMatch = { pattern, confidence: matchConfidence };
      }
    }
  }

  // Fallback to CHAT
  if (!bestMatch) {
    return {
      type: 'CHAT',
      bubbleType: 'chat',
      confidence: 0.4,
      entities,
      originalText: text,
      language,
      forbiddenDetected: !islamicCheck.isCompliant,
    };
  }

  // Build causal context
  let causalContext: string | undefined;
  if (entities.length > 0) {
    const entitySummary = entities
      .filter((e) => ['brand', 'currency', 'category'].includes(e.type))
      .map((e) => `${e.key}=${e.value}`)
      .join(', ');
    causalContext = entitySummary
      ? `تم استنتاج النية من الكيانات: ${entitySummary}`
      : undefined;
  }

  return {
    type: bestMatch.pattern.intentType,
    bubbleType: bestMatch.pattern.bubbleType,
    confidence: bestMatch.confidence,
    entities,
    originalText: text,
    language,
    causalContext,
    forbiddenDetected: !islamicCheck.isCompliant,
  };
}

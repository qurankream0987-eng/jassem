// ============================================================================
// 🧬 JASIM — DNA Breeding Engine
// Templates, Crossover, Mutation, Invention
// ============================================================================

import type { DNAGene, BubbleType } from './types';

// ─── DNA Templates (12+ Known Genes per bubble) ─────────────────────────────

interface DNATemplate extends Omit<DNAGene, 'id'> {
  factoryId: string;
}

const DNA_TEMPLATES: Record<BubbleType, DNATemplate> = {
  // ─── B2C Core ────────────────────────────────────────────────────────────
  food: {
    factoryId: 'food',
    version: '34.0',
    generation: 0,
    bubbleType: 'food',
    capabilities: ['SEARCH', 'FILTER', 'MATCH', 'ORDER', 'PAY'],
    trustLevel: 'medium',
    theme: { primary: '#FF6B35', secondary: '#F7931E', accent: '#FFD23F', glow: '#FF6B35' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  restaurant: {
    factoryId: 'restaurant',
    version: '34.0',
    generation: 0,
    bubbleType: 'restaurant',
    capabilities: ['SEARCH', 'FILTER', 'BOOK', 'MENU', 'REVIEW'],
    trustLevel: 'high',
    theme: { primary: '#D62828', secondary: '#F77F00', accent: '#FCBF49', glow: '#D62828' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  pharmacy: {
    factoryId: 'pharmacy',
    version: '34.0',
    generation: 0,
    bubbleType: 'pharmacy',
    capabilities: ['SEARCH', 'VERIFY_PRESCRIPTION', 'MATCH', 'DELIVER', 'PAY'],
    trustLevel: 'high',
    theme: { primary: '#00C853', secondary: '#69F0AE', accent: '#B9F6CA', glow: '#00C853' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  fashion: {
    factoryId: 'fashion',
    version: '34.0',
    generation: 0,
    bubbleType: 'fashion',
    capabilities: ['SEARCH', 'FILTER', 'COMPARE', 'MATCH', 'ORDER'],
    trustLevel: 'medium',
    theme: { primary: '#F48FB1', secondary: '#F8BBD0', accent: '#EC407A', glow: '#F48FB1' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  grocery: {
    factoryId: 'grocery',
    version: '34.0',
    generation: 0,
    bubbleType: 'grocery',
    capabilities: ['SEARCH', 'FILTER', 'BASKET', 'PAY', 'SCHEDULE_DELIVERY'],
    trustLevel: 'high',
    theme: { primary: '#795548', secondary: '#A1887F', accent: '#FFB74D', glow: '#795548' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  delivery: {
    factoryId: 'delivery',
    version: '34.0',
    generation: 0,
    bubbleType: 'delivery',
    capabilities: ['TRACK', 'NOTIFY', 'ETA', 'CONFIRM', 'RATE'],
    trustLevel: 'high',
    theme: { primary: '#03A9F4', secondary: '#4FC3F7', accent: '#B3E5FC', glow: '#03A9F4' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  emergency: {
    factoryId: 'emergency',
    version: '34.0',
    generation: 0,
    bubbleType: 'emergency',
    capabilities: ['LOCATE', 'DISPATCH', 'NOTIFY', 'ESCALATE', 'LOG'],
    trustLevel: 'high',
    theme: { primary: '#FF1744', secondary: '#F50057', accent: '#FF80AB', glow: '#FF1744' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    lifetimeMs: 10 * 60 * 1000,
    mutations: [],
  },

  // ─── B2B Core ────────────────────────────────────────────────────────────
  job: {
    factoryId: 'job',
    version: '34.0',
    generation: 0,
    bubbleType: 'job',
    capabilities: ['CREATE_LISTING', 'MATCH_CANDIDATES', 'SHORTLIST', 'INTERVIEW', 'CONTRACT'],
    trustLevel: 'high',
    theme: { primary: '#1976D2', secondary: '#42A5F5', accent: '#90CAF9', glow: '#1976D2' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  recruitment: {
    factoryId: 'recruitment',
    version: '34.0',
    generation: 0,
    bubbleType: 'recruitment',
    capabilities: ['MATCH', 'FILTER', 'SHORTLIST', 'INTERVIEW', 'CONTRACT', 'VERIFY'],
    trustLevel: 'high',
    theme: { primary: '#5E35B1', secondary: '#7E57C2', accent: '#B39DDB', glow: '#5E35B1' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  payment: {
    factoryId: 'payment',
    version: '34.0',
    generation: 0,
    bubbleType: 'payment',
    capabilities: ['VERIFY', 'AUTHORIZE', 'CAPTURE', 'RECONCILE', 'REFUND'],
    trustLevel: 'high',
    theme: { primary: '#00897B', secondary: '#26A69A', accent: '#80CBC4', glow: '#00897B' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  wallet: {
    factoryId: 'wallet',
    version: '34.0',
    generation: 0,
    bubbleType: 'wallet',
    capabilities: ['BALANCE', 'TRANSFER', 'TOPUP', 'WITHDRAW', 'HISTORY'],
    trustLevel: 'high',
    theme: { primary: '#FFD700', secondary: '#FFC107', accent: '#FFE082', glow: '#FFD700' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  analytics: {
    factoryId: 'analytics',
    version: '34.0',
    generation: 0,
    bubbleType: 'analytics',
    capabilities: ['QUERY', 'AGGREGATE', 'VISUALIZE', 'EXPORT', 'INSIGHT'],
    trustLevel: 'medium',
    theme: { primary: '#EC407A', secondary: '#F06292', accent: '#F48FB1', glow: '#EC407A' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  ads: {
    factoryId: 'ads',
    version: '34.0',
    generation: 0,
    bubbleType: 'ads',
    capabilities: ['CREATE_CAMPAIGN', 'TARGET', 'BID', 'TRACK', 'OPTIMIZE'],
    trustLevel: 'medium',
    theme: { primary: '#FF6B00', secondary: '#FF9100', accent: '#FFD180', glow: '#FF6B00' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  platform: {
    factoryId: 'platform',
    version: '34.0',
    generation: 0,
    bubbleType: 'platform',
    capabilities: ['DESIGN_WORLD', 'CREATE_ENTITIES', 'DEFINE_POLICIES', 'DEPLOY', 'MONITOR'],
    trustLevel: 'high',
    theme: { primary: '#7C4DFF', secondary: '#651FFF', accent: '#B388FF', glow: '#7C4DFF' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  negotiation: {
    factoryId: 'negotiation',
    version: '34.0',
    generation: 0,
    bubbleType: 'negotiation',
    capabilities: ['PROPOSE', 'COUNTER', 'ACCEPT', 'REJECT', 'ESCALATE'],
    trustLevel: 'high',
    theme: { primary: '#FFD740', secondary: '#FF6D00', accent: '#FFE57F', glow: '#FFD740' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  product: {
    factoryId: 'product',
    version: '34.0',
    generation: 0,
    bubbleType: 'product',
    capabilities: ['CREATE_LISTING', 'SEARCH', 'MATCH', 'COMPARE', 'NEGOTIATE', 'PAY', 'ESCROW'],
    trustLevel: 'medium',
    theme: { primary: '#448AFF', secondary: '#82B1FF', accent: '#B3D4FF', glow: '#448AFF' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  service: {
    factoryId: 'service',
    version: '34.0',
    generation: 0,
    bubbleType: 'service',
    capabilities: ['SEARCH', 'BOOK', 'VERIFY', 'PAY', 'REVIEW'],
    trustLevel: 'medium',
    theme: { primary: '#AB47BC', secondary: '#CE93D8', accent: '#E1BEE7', glow: '#AB47BC' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  dashboard: {
    factoryId: 'dashboard',
    version: '34.0',
    generation: 0,
    bubbleType: 'dashboard',
    capabilities: ['QUERY', 'VISUALIZE', 'FILTER', 'EXPORT', 'ALERT'],
    trustLevel: 'high',
    theme: { primary: '#00d4ff', secondary: '#4a9eff', accent: '#80DEEA', glow: '#00d4ff' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  settings: {
    factoryId: 'settings',
    version: '34.0',
    generation: 0,
    bubbleType: 'settings',
    capabilities: ['READ', 'UPDATE', 'VALIDATE', 'AUDIT'],
    trustLevel: 'high',
    theme: { primary: '#94a3b8', secondary: '#cbd5e1', accent: '#E2E8F0', glow: '#94a3b8' },
    streamMode: false,
    expandable: true,
    selfHealing: false,
    mutations: [],
  },

  // ─── Universal Interfaces ────────────────────────────────────────────────
  chat: {
    factoryId: 'chat',
    version: '34.0',
    generation: 0,
    bubbleType: 'chat',
    capabilities: ['SEARCH', 'CHAT'],
    trustLevel: 'low',
    theme: { primary: '#a855f7', secondary: '#ec4899', accent: '#F0ABFC', glow: '#a855f7' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  subchat: {
    factoryId: 'subchat',
    version: '34.0',
    generation: 0,
    bubbleType: 'subchat',
    capabilities: ['SEARCH', 'CHAT'],
    trustLevel: 'low',
    theme: { primary: '#a855f7', secondary: '#ec4899', accent: '#F0ABFC', glow: '#a855f7' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  suggestions: {
    factoryId: 'suggestions',
    version: '34.0',
    generation: 0,
    bubbleType: 'suggestions',
    capabilities: ['RECOMMEND', 'FILTER', 'RANK'],
    trustLevel: 'low',
    theme: { primary: '#00d4ff', secondary: '#4a9eff', accent: '#80DEEA', glow: '#00d4ff' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
  ad: {
    factoryId: 'ad',
    version: '34.0',
    generation: 0,
    bubbleType: 'ad',
    capabilities: ['DISPLAY', 'CLICK', 'CONVERT'],
    trustLevel: 'low',
    theme: { primary: '#FF9800', secondary: '#FFB74D', accent: '#FFE0B2', glow: '#FF9800' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },

  // ─── DNA-Bred Specializations (Generation 1+) ────────────────────────────
  cinema: {
    factoryId: 'cinema',
    version: '34.0',
    generation: 1,
    parentIds: ['entertainment', 'booking'],
    bubbleType: 'cinema',
    capabilities: ['SEARCH', 'BOOK', 'PAY', 'SCHEDULE'],
    trustLevel: 'medium',
    theme: { primary: '#9C27B0', secondary: '#E1BEE7', accent: '#CE93D8', glow: '#9C27B0' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: ['cinema_specialization'],
  },
  car_insurance: {
    factoryId: 'car_insurance',
    version: '34.0',
    generation: 1,
    parentIds: ['automotive', 'insurance'],
    bubbleType: 'car_insurance',
    capabilities: ['QUOTE', 'COMPARE', 'PAY', 'CLAIM'],
    trustLevel: 'high',
    theme: { primary: '#1565C0', secondary: '#42A5F5', accent: '#90CAF9', glow: '#1565C0' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: ['insurance_specialization'],
  },
  real_estate: {
    factoryId: 'real_estate',
    version: '34.0',
    generation: 1,
    parentIds: ['search', 'location'],
    bubbleType: 'real_estate',
    capabilities: ['SEARCH', 'FILTER', 'COMPARE', 'CONTACT', 'INSPECT', 'BOOK'],
    trustLevel: 'high',
    theme: { primary: '#795548', secondary: '#D7CCC8', accent: '#BCAAA4', glow: '#795548' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: ['real_estate_specialization'],
  },
  travel: {
    factoryId: 'travel',
    version: '34.0',
    generation: 1,
    parentIds: ['booking', 'location'],
    bubbleType: 'travel',
    capabilities: ['SEARCH_FLIGHT', 'BOOK', 'PAY', 'ITINERARY'],
    trustLevel: 'high',
    theme: { primary: '#009688', secondary: '#B2DFDB', accent: '#80CBC4', glow: '#009688' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: ['travel_specialization'],
  },
  education: {
    factoryId: 'education',
    version: '34.0',
    generation: 1,
    parentIds: ['learning', 'search'],
    bubbleType: 'education',
    capabilities: ['SEARCH', 'ENROLL', 'PAY', 'TRACK_PROGRESS'],
    trustLevel: 'high',
    theme: { primary: '#3F51B5', secondary: '#C5CAE9', accent: '#9FA8DA', glow: '#3F51B5' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: ['education_specialization'],
  },
  healthcare: {
    factoryId: 'healthcare',
    version: '34.0',
    generation: 1,
    parentIds: ['pharmacy', 'appointment'],
    bubbleType: 'healthcare',
    capabilities: ['BOOK_APPOINTMENT', 'CONSULT', 'PAY', 'FOLLOW_UP'],
    trustLevel: 'high',
    theme: { primary: '#00C853', secondary: '#69F0AE', accent: '#B9F6CA', glow: '#00C853' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: ['healthcare_specialization'],
  },
  government: {
    factoryId: 'government',
    version: '34.0',
    generation: 1,
    parentIds: ['service', 'verification'],
    bubbleType: 'government',
    capabilities: ['SEARCH', 'APPLY', 'VERIFY', 'PAY', 'TRACK'],
    trustLevel: 'high',
    theme: { primary: '#607D8B', secondary: '#CFD8DC', accent: '#B0BEC5', glow: '#607D8B' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: ['gov_specialization'],
  },
  events: {
    factoryId: 'events',
    version: '34.0',
    generation: 1,
    parentIds: ['entertainment', 'booking'],
    bubbleType: 'events',
    capabilities: ['SEARCH', 'BOOK', 'PAY', 'MANAGE'],
    trustLevel: 'medium',
    theme: { primary: '#FF9800', secondary: '#FFE0B2', accent: '#FFCC80', glow: '#FF9800' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: ['events_specialization'],
  },

  // Generic
  generic: {
    factoryId: 'generic',
    version: '34.0',
    generation: 0,
    bubbleType: 'generic',
    capabilities: ['SEARCH', 'CHAT'],
    trustLevel: 'low',
    theme: { primary: '#64b4ff', secondary: '#a78bfa', accent: '#C7D2FE', glow: '#64b4ff' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  },
};

// ─── Color utilities ──────────────────────────────────────────────────────

function hexToRgb(hex: string): [number, number, number] {
  const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return m ? [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)] : [0, 0, 0];
}

function rgbToHex(r: number, g: number, b: number): string {
  return '#' + [r, g, b].map((c) => Math.max(0, Math.min(255, Math.round(c))).toString(16).padStart(2, '0')).join('');
}

function blendHex(c1: string, c2: string): string {
  const [r1, g1, b1] = hexToRgb(c1);
  const [r2, g2, b2] = hexToRgb(c2);
  return rgbToHex((r1 + r2) / 2, (g1 + g2) / 2, (b1 + b2) / 2);
}

function hslToHex(h: number, s: number, l: number): string {
  s /= 100; l /= 100;
  const a = s * Math.min(l, 1 - l);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color).toString(16).padStart(2, '0');
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

// ─── Counter for bred DNA ──────────────────────────────────────────────────

let BREED_COUNTER = 0;

// ─── Public API: Get DNA template ──────────────────────────────────────────

export function getDNA(type: BubbleType): DNAGene {
  const template = DNA_TEMPLATES[type] || DNA_TEMPLATES.generic;
  return {
    id: `dna-${template.factoryId}-${Date.now()}`,
    version: template.version,
    generation: template.generation,
    parentIds: template.parentIds,
    bubbleType: template.bubbleType,
    capabilities: [...template.capabilities],
    trustLevel: template.trustLevel,
    theme: { ...template.theme },
    streamMode: template.streamMode,
    expandable: template.expandable,
    selfHealing: template.selfHealing,
    lifetimeMs: template.lifetimeMs,
    mutations: [...template.mutations],
  };
}

// ─── Crossover: Merge two parent DNAs ──────────────────────────────────────

export function crossover(
  parentA: DNAGene,
  parentB: DNAGene,
  taskDescription: string,
): DNAGene {
  const isUrgent = /سريع|عاجل|fast|urgent/i.test(taskDescription);

  const childCapabilities = Array.from(new Set([...parentA.capabilities, ...parentB.capabilities]));

  // Decide bubble type — prefer the more specific parent (higher generation)
  const dominantParent = parentA.generation >= parentB.generation ? parentA : parentB;

  return {
    id: `dna-bred-${Date.now()}_${++BREED_COUNTER}`,
    version: '34.0-bred',
    generation: Math.max(parentA.generation, parentB.generation) + 1,
    parentIds: [parentA.id, parentB.id],
    bubbleType: dominantParent.bubbleType,
    capabilities: childCapabilities,
    trustLevel: parentA.trustLevel === 'high' || parentB.trustLevel === 'high' ? 'high' : 'medium',
    theme: {
      primary: blendHex(parentA.theme.primary, parentB.theme.primary),
      secondary: blendHex(parentA.theme.secondary, parentB.theme.secondary),
      accent: blendHex(parentA.theme.accent, parentB.theme.accent),
      glow: isUrgent ? parentA.theme.glow : blendHex(parentA.theme.glow, parentB.theme.glow),
    },
    streamMode: parentA.streamMode || parentB.streamMode,
    expandable: parentA.expandable || parentB.expandable,
    selfHealing: parentA.selfHealing && parentB.selfHealing,
    lifetimeMs: 5 * 60 * 1000,
    mutations: ['crossover'],
  };
}

// ─── Mutation: Specialize a gene for a specific entity type ────────────────

export function mutate(gene: DNAGene, entityType?: string): DNAGene {
  const mutated: DNAGene = { ...gene, theme: { ...gene.theme } };

  const typeColors: Record<string, [string, string]> = {
    cinema: ['#9C27B0', '#E1BEE7'],
    real_estate: ['#795548', '#D7CCC8'],
    travel: ['#009688', '#B2DFDB'],
    education: ['#3F51B5', '#C5CAE9'],
    healthcare: ['#00C853', '#69F0AE'],
    government: ['#607D8B', '#CFD8DC'],
    events: ['#FF9800', '#FFE0B2'],
    car_insurance: ['#1565C0', '#42A5F5'],
  };

  if (entityType && typeColors[entityType]) {
    const [c1, c2] = typeColors[entityType];
    mutated.theme.primary = c1;
    mutated.theme.secondary = c2;
    mutated.theme.glow = c1;
    mutated.bubbleType = entityType as BubbleType;
  }

  mutated.mutations = [...mutated.mutations, `mutate_${Date.now()}`];
  mutated.id = `dna-mut-${Date.now()}_${++BREED_COUNTER}`;
  mutated.generation = gene.generation + 1;
  return mutated;
}

// ─── Invention: Create entirely new DNA when no parent fits ───────────────

export function invent(taskDescription: string, constraints?: { islamicCompliant: boolean }): DNAGene {
  const baseHue = Math.floor(Math.random() * 360);
  const c1 = hslToHex(baseHue, 70, 50);
  const c2 = hslToHex((baseHue + 30) % 360, 60, 70);

  return {
    id: `dna-invented-${Date.now()}_${++BREED_COUNTER}`,
    version: '34.0-invented',
    generation: 0,
    bubbleType: 'generic',
    capabilities: ['SEARCH', 'CHAT', 'CREATE', 'COMPARE', 'PAY'],
    trustLevel: 'medium',
    theme: { primary: c1, secondary: c2, accent: c2, glow: c1 },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    lifetimeMs: 5 * 60 * 1000,
    mutations: [`invent_for_${taskDescription.slice(0, 30)}`],
  };
}

// ─── Breed: High-level entry point ─────────────────────────────────────────

export function breedDNA(
  parentTypes: BubbleType[],
  taskDescription: string,
  constraints?: { islamicCompliant: boolean },
): DNAGene {
  if (parentTypes.length === 0) {
    return invent(taskDescription, constraints);
  }
  if (parentTypes.length === 1) {
    return mutate(getDNA(parentTypes[0]), parentTypes[0]);
  }

  // Multi-parent crossover: fold left
  const parents = parentTypes.map((t) => getDNA(t));
  let child = parents[0];
  for (let i = 1; i < parents.length; i++) {
    child = crossover(child, parents[i], taskDescription);
  }
  return child;
}

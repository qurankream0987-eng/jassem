// ============================================================================
// 🧬 JASIM — Task Planner
// Generates execution DAG (SEQUENCE/PARALLEL/CONDITION/HUMAN_GATE) from intent
// ============================================================================

import type { IntentResult, DNAGene, TaskStep, Workflow } from './types';

// ─── Plan template per intent type ────────────────────────────────────────

interface PlanTemplate {
  capabilities: Array<{ name: string; labelAr: string; labelEn: string; requiresHumanGate?: boolean }>;
}

const PLAN_TEMPLATES: Record<string, PlanTemplate> = {
  SEARCH: {
    capabilities: [
      { name: 'search', labelAr: 'بحث', labelEn: 'Search' },
      { name: 'filter', labelAr: 'تصفية', labelEn: 'Filter' },
      { name: 'compare', labelAr: 'مقارنة', labelEn: 'Compare' },
      { name: 'match', labelAr: 'مطابقة', labelEn: 'Match' },
    ],
  },
  BUY: {
    capabilities: [
      { name: 'search', labelAr: 'بحث', labelEn: 'Search' },
      { name: 'match', labelAr: 'مطابقة', labelEn: 'Match' },
      { name: 'compare', labelAr: 'مقارنة', labelEn: 'Compare' },
      { name: 'negotiate', labelAr: 'تفاوض', labelEn: 'Negotiate' },
      { name: 'payment_intent', labelAr: 'دفع', labelEn: 'Payment', requiresHumanGate: true },
      { name: 'escrow_hold', labelAr: 'ضمان', labelEn: 'Escrow' },
      { name: 'track', labelAr: 'تتبع', labelEn: 'Track' },
    ],
  },
  SELL: {
    capabilities: [
      { name: 'create_listing', labelAr: 'إنشاء إدراج', labelEn: 'Create Listing' },
      { name: 'notify_in_app', labelAr: 'إشعار', labelEn: 'Notify' },
    ],
  },
  COMPARE: {
    capabilities: [
      { name: 'search', labelAr: 'بحث', labelEn: 'Search' },
      { name: 'compare', labelAr: 'مقارنة', labelEn: 'Compare' },
      { name: 'match', labelAr: 'مطابقة', labelEn: 'Match' },
    ],
  },
  NEGOTIATE: {
    capabilities: [
      { name: 'search', labelAr: 'بحث', labelEn: 'Search' },
      { name: 'match', labelAr: 'مطابقة', labelEn: 'Match' },
      { name: 'negotiate', labelAr: 'تفاوض', labelEn: 'Negotiate' },
    ],
  },
  HIRE: {
    capabilities: [
      { name: 'match_candidates', labelAr: 'مطابقة المرشحين', labelEn: 'Match Candidates' },
      { name: 'schedule_interview', labelAr: 'جدولة مقابلة', labelEn: 'Schedule Interview', requiresHumanGate: true },
      { name: 'notify_in_app', labelAr: 'إشعار', labelEn: 'Notify' },
    ],
  },
  DELIVER: {
    capabilities: [
      { name: 'track_delivery', labelAr: 'تتبع', labelEn: 'Track' },
      { name: 'notify_in_app', labelAr: 'إشعار', labelEn: 'Notify' },
    ],
  },
  EMERGENCY: {
    capabilities: [
      { name: 'verify_phone', labelAr: 'تحقق', labelEn: 'Verify' },
      { name: 'notify_in_app', labelAr: 'إشعار الطوارئ', labelEn: 'Emergency Notify' },
      { name: 'track', labelAr: 'متابعة', labelEn: 'Track' },
    ],
  },
  PAY: {
    capabilities: [
      { name: 'payment_intent', labelAr: 'دفع', labelEn: 'Payment', requiresHumanGate: true },
      { name: 'escrow_hold', labelAr: 'ضمان', labelEn: 'Escrow' },
    ],
  },
  ANALYZE: {
    capabilities: [
      { name: 'query_analytics', labelAr: 'استعلام', labelEn: 'Query Analytics' },
      { name: 'aggregate_data', labelAr: 'تجميع', labelEn: 'Aggregate' },
      { name: 'insight_generation', labelAr: 'استنتاج', labelEn: 'Insight' },
    ],
  },
  BUILD_PLATFORM: {
    capabilities: [
      { name: 'create_listing', labelAr: 'تصميم العالم', labelEn: 'Design World' },
      { name: 'notify_in_app', labelAr: 'إشعار', labelEn: 'Notify' },
    ],
  },
  CHAT: {
    capabilities: [
      { name: 'notify_in_app', labelAr: 'محادثة', labelEn: 'Chat' },
    ],
  },
};

// ─── Compile plan: DNA.capabilities → Workflow.steps ─────────────────────

export function compilePlan(
  dna: DNAGene,
  intent: IntentResult,
  ownerId: string,
  sessionId?: string,
): Workflow {
  // Pick template based on intent
  const template = PLAN_TEMPLATES[intent.type] || PLAN_TEMPLATES.CHAT;
  const capabilities = template.capabilities;

  const steps: TaskStep[] = capabilities.map((cap, i) => ({
    id: `step-${i}-${cap.name}`,
    capability: cap.name,
    labelAr: cap.labelAr,
    labelEn: cap.labelEn,
    status: i === 0 ? 'running' : 'pending',
    attempts: 0,
    maxAttempts: 3,
    requiresHumanGate: cap.requiresHumanGate ?? false,
    dependsOn: i > 0 ? [`step-${i - 1}-${capabilities[i - 1].name}`] : [],
  }));

  return {
    id: `wf-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    dnaId: dna.id,
    ownerId,
    sessionId,
    steps,
    currentStepIndex: 0,
    status: 'executing',
    startedAt: Date.now(),
    updatedAt: Date.now(),
    results: {},
    totalCostUsd: 0,
    totalTokensIn: 0,
    totalTokensOut: 0,
  };
}

// ─── Observe current step ──────────────────────────────────────────────────

export function observeStep(workflow: Workflow): TaskStep | undefined {
  return workflow.steps[workflow.currentStepIndex];
}

// ─── Verify and advance ────────────────────────────────────────────────────

export function verifyAndAdvance(
  workflow: Workflow,
  result: { success: boolean; data?: unknown; evidence?: any[] },
): Workflow {
  const newWf: Workflow = JSON.parse(JSON.stringify(workflow));
  const current = newWf.steps[newWf.currentStepIndex];
  if (!current) return newWf;

  if (!result.success) {
    current.status = 'failed';
    current.attempts += 1;
    current.error = 'Execution failed';

    if (current.attempts < current.maxAttempts) {
      // Retry
      current.status = 'running';
      newWf.status = 'executing';
    } else {
      // Skip and continue (Replan strategy)
      current.status = 'skipped';
      newWf.currentStepIndex += 1;
      if (newWf.steps[newWf.currentStepIndex]) {
        newWf.steps[newWf.currentStepIndex].status = 'running';
        newWf.steps[newWf.currentStepIndex].startedAt = Date.now();
      } else {
        newWf.status = 'failed';
      }
    }
  } else {
    current.status = 'completed';
    current.output = result.data;
    current.completedAt = Date.now();
    newWf.results[current.capability] = result.data;

    newWf.currentStepIndex += 1;
    if (newWf.steps[newWf.currentStepIndex]) {
      newWf.steps[newWf.currentStepIndex].status = 'running';
      newWf.steps[newWf.currentStepIndex].startedAt = Date.now();
    } else {
      newWf.status = 'completed';
      newWf.completedAt = Date.now();
    }
  }
  newWf.updatedAt = Date.now();
  return newWf;
}

// ─── Check completion ──────────────────────────────────────────────────────

export function isWorkflowComplete(workflow: Workflow): boolean {
  return workflow.currentStepIndex >= workflow.steps.length;
}

// ─── Capabilities that should stop workflow for user interaction ──────────

export const STOP_CAPABILITIES = new Set([
  'search', 'filter', 'compare', 'match', 'match_candidates',
  'negotiate', 'propose_offer', 'payment_intent', 'payment_authorize',
  'escrow_hold', 'verify_identity', 'verify_phone',
  'track', 'track_delivery', 'calculate_eta', 'deliver',
  'wallet_balance', 'wallet_history',
  'query_analytics', 'aggregate_data', 'insight_generation',
  'create_listing', 'book_appointment', 'schedule_interview',
  'notify_in_app',
]);

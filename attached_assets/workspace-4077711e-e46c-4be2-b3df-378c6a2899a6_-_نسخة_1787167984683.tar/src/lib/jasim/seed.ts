// ============================================================================
// 🛠️ JASIM — Seed Script
// Seeds capabilities, demo users, listings, and memory into the database
// ============================================================================

import { db } from '@/lib/db';
import { capabilityRegistry, syncCapabilitiesToDb } from '@/lib/jasim/capability-registry';

// ─── Demo users (real DB records) ──────────────────────────────────────────

const DEMO_USERS = [
  { id: 'user-demo-1', phone: '+96560000001', name: 'أحمد العلي', language: 'ar', role: 'merchant', trustScore: 0.92, verified: true },
  { id: 'user-demo-2', phone: '+96560000002', name: 'محمد الكندري', language: 'ar', role: 'driver', trustScore: 0.85, verified: true },
  { id: 'user-demo-3', phone: '+96560000003', name: 'سارة المطيري', language: 'ar', role: 'freelancer', trustScore: 0.88, verified: true },
  { id: 'user-demo-4', phone: '+96560000004', name: 'خالد الراشد', language: 'ar', role: 'user', trustScore: 0.7, verified: false },
  { id: 'user-guest', phone: null, name: 'ضيف', language: 'ar', role: 'user', trustScore: 0.3, verified: false },
];

// ─── Demo listings (real DB records) ───────────────────────────────────────

const DEMO_LISTINGS = [
  // Cars
  { id: 'list-car-1', sellerId: 'user-demo-1', type: 'car', title: 'Toyota Camry 2023', titleAr: 'تويوتا كامري 2023', dataJson: JSON.stringify({ brand: 'Toyota', model: 'Camry', year: 2023, price: 7800, mileage: 15000, transmission: 'automatic', fuel: 'petrol', location: 'الكويت', image: '🚗', condition: 'used' }), location: 'الكويت', price: 7800, status: 'active' },
  { id: 'list-car-2', sellerId: 'user-demo-1', type: 'car', title: 'Toyota Camry 2022', titleAr: 'تويوتا كامري 2022', dataJson: JSON.stringify({ brand: 'Toyota', model: 'Camry', year: 2022, price: 6500, mileage: 32000, transmission: 'automatic', fuel: 'petrol', location: 'حولي', image: '🚙', condition: 'used' }), location: 'حولي', price: 6500, status: 'active' },
  { id: 'list-car-3', sellerId: 'user-demo-1', type: 'car', title: 'Toyota Corolla 2023', titleAr: 'تويوتا كورولا 2023', dataJson: JSON.stringify({ brand: 'Toyota', model: 'Corolla', year: 2023, price: 5500, mileage: 8000, transmission: 'automatic', fuel: 'hybrid', location: 'السالمية', image: '🚗', condition: 'used' }), location: 'السالمية', price: 5500, status: 'active' },
  { id: 'list-car-4', sellerId: 'user-demo-2', type: 'car', title: 'Toyota Hilux 2024', titleAr: 'تويوتا هيلوكس 2024', dataJson: JSON.stringify({ brand: 'Toyota', model: 'Hilux', year: 2024, price: 12500, mileage: 5000, transmission: 'manual', fuel: 'diesel', location: 'الجهراء', image: '🛻', condition: 'used' }), location: 'الجهراء', price: 12500, status: 'active' },
  { id: 'list-car-5', sellerId: 'user-demo-2', type: 'car', title: 'Hyundai Sonata 2023', titleAr: 'هيونداي سوناتا 2023', dataJson: JSON.stringify({ brand: 'Hyundai', model: 'Sonata', year: 2023, price: 6800, mileage: 12000, transmission: 'automatic', fuel: 'petrol', location: 'الكويت', image: '🚗', condition: 'used' }), location: 'الكويت', price: 6800, status: 'active' },
  { id: 'list-car-6', sellerId: 'user-demo-3', type: 'car', title: 'Toyota Land Cruiser 2023', titleAr: 'تويوتا لاند كروزر 2023', dataJson: JSON.stringify({ brand: 'Toyota', model: 'Land Cruiser', year: 2023, price: 18500, mileage: 22000, transmission: 'automatic', fuel: 'petrol', location: 'الكويت', image: '🚙', condition: 'used' }), location: 'الكويت', price: 18500, status: 'active' },

  // Products (electronics)
  { id: 'list-prod-1', sellerId: 'user-demo-3', type: 'product', title: 'Lenovo Legion 5 Pro', titleAr: 'لابتوب Lenovo Legion 5 Pro', dataJson: JSON.stringify({ title: 'Lenovo Legion 5 Pro', brand: 'Lenovo', category: 'electronics', price: 320, condition: 'used', location: 'الكويت', image: '💻', description: 'Ryzen 7، RTX 4060، 16GB RAM' }), location: 'الكويت', price: 320, status: 'active' },
  { id: 'list-prod-2', sellerId: 'user-demo-3', type: 'product', title: 'iPhone 14 Pro Max', titleAr: 'آيفون 14 برو ماكس', dataJson: JSON.stringify({ title: 'iPhone 14 Pro Max', brand: 'iPhone', category: 'electronics', price: 410, condition: 'used', location: 'حولي', image: '📱', description: '256GB، بحالة ممتازة' }), location: 'حولي', price: 410, status: 'active' },
  { id: 'list-prod-3', sellerId: 'user-demo-1', type: 'product', title: 'Samsung Galaxy S23', titleAr: 'سامسونج جالاكسي S23', dataJson: JSON.stringify({ title: 'Samsung Galaxy S23', brand: 'Samsung', category: 'electronics', price: 280, condition: 'used', location: 'السالمية', image: '📱', description: 'بكامل ملحقاته' }), location: 'السالمية', price: 280, status: 'active' },
  { id: 'list-prod-4', sellerId: 'user-demo-2', type: 'product', title: 'Sony WH-1000XM5', titleAr: 'سماعات سوني WH-1000XM5', dataJson: JSON.stringify({ title: 'Sony WH-1000XM5', brand: 'Sony', category: 'electronics', price: 180, condition: 'used', location: 'الكويت', image: '🎧', description: 'عازلة للضوضاء' }), location: 'الكويت', price: 180, status: 'active' },

  // Jobs
  { id: 'list-job-1', sellerId: 'user-demo-1', type: 'job', title: 'Senior Frontend Developer', titleAr: 'مطور واجهات أمامية أول', dataJson: JSON.stringify({ title: 'Senior Frontend Developer', company: 'شركة التقنية المتقدمة', salary: 1800, category: 'tech', location: 'الكويت', type: 'fulltime' }), location: 'الكويت', price: 1800, status: 'active' },
  { id: 'list-job-2', sellerId: 'user-demo-2', type: 'job', title: 'محاسب مالي', titleAr: 'محاسب مالي', dataJson: JSON.stringify({ title: 'محاسب مالي', company: 'مكتب الاستشارات المالية', salary: 1200, category: 'finance', location: 'حولي', type: 'fulltime' }), location: 'حولي', price: 1200, status: 'active' },
  { id: 'list-job-3', sellerId: 'user-demo-3', type: 'job', title: 'ممرض مؤهل', titleAr: 'ممرض مؤهل', dataJson: JSON.stringify({ title: 'ممرض', company: 'مستشفى السلام', salary: 900, category: 'health', location: 'السالمية', type: 'fulltime' }), location: 'السالمية', price: 900, status: 'active' },
  { id: 'list-job-4', sellerId: 'user-demo-1', type: 'job', title: 'Remote Full Stack Engineer', titleAr: 'مهندس Full Stack عن بعد', dataJson: JSON.stringify({ title: 'Remote Full Stack Engineer', company: 'TechCorp', salary: 2500, category: 'tech', location: 'عن بعد', type: 'remote' }), location: 'عن بعد', price: 2500, status: 'active' },

  // Food
  { id: 'list-food-1', sellerId: 'user-demo-3', type: 'food', title: 'مندي لحم', titleAr: 'مندي لحم', dataJson: JSON.stringify({ name: 'مندي لحم', restaurant: 'مطعم اليمن الأصيل', price: 4.5, cuisine: 'arabic', spicy: false }), location: 'الكويت', price: 4.5, status: 'active' },
  { id: 'list-food-2', sellerId: 'user-demo-3', type: 'food', title: 'برياني دجاج حار', titleAr: 'برياني دجاج حار', dataJson: JSON.stringify({ name: 'برياني دجاج', restaurant: 'مطعم الهند', price: 3.8, cuisine: 'indian', spicy: true }), location: 'حولي', price: 3.8, status: 'active' },
  { id: 'list-food-3', sellerId: 'user-demo-1', type: 'food', title: 'بيتزا مارجريتا', titleAr: 'بيتزا مارجريتا', dataJson: JSON.stringify({ name: 'بيتزا مارجريتا', restaurant: 'بيتزا هت', price: 3.2, cuisine: 'italian', spicy: false }), location: 'السالمية', price: 3.2, status: 'active' },
  { id: 'list-food-4', sellerId: 'user-demo-1', type: 'food', title: 'مجبوس دجاج', titleAr: 'مجبوس دجاج', dataJson: JSON.stringify({ name: 'مجبوس دجاج', restaurant: 'مطعم الكويت', price: 3.5, cuisine: 'arabic', spicy: false }), location: 'الكويت', price: 3.5, status: 'active' },

  // Real estate
  { id: 'list-re-1', sellerId: 'user-demo-1', type: 'realestate', title: 'شقة في السالمية', titleAr: 'شقة فاخرة في السالمية', dataJson: JSON.stringify({ title: 'شقة فاخرة في السالمية', type: 'apartment', purpose: 'sale', price: 85000, area: 180, bedrooms: 3, location: 'السالمية', image: '🏢' }), location: 'السالمية', price: 85000, status: 'active' },
  { id: 'list-re-2', sellerId: 'user-demo-2', type: 'realestate', title: 'فيلا في الجهراء', titleAr: 'فيلا في الجهراء', dataJson: JSON.stringify({ title: 'فيلا في الجهراء', type: 'villa', purpose: 'sale', price: 220000, area: 450, bedrooms: 5, location: 'الجهراء', image: '🏠' }), location: 'الجهراء', price: 220000, status: 'active' },
  { id: 'list-re-3', sellerId: 'user-demo-3', type: 'realestate', title: 'شقة للإيجار في حولي', titleAr: 'شقة للإيجار في حولي', dataJson: JSON.stringify({ title: 'شقة للإيجار في حولي', type: 'apartment', purpose: 'rent', price: 450, area: 120, bedrooms: 2, location: 'حولي', image: '🏢' }), location: 'حولي', price: 450, status: 'active' },

  // Services
  { id: 'list-svc-1', sellerId: 'user-demo-3', type: 'service', title: 'تصميم شعار احترافي', titleAr: 'تصميم شعار احترافي', dataJson: JSON.stringify({ name: 'تصميم شعار', category: 'design', price: 50, provider: 'سارة المطيري', rating: 4.9 }), location: 'الكويت', price: 50, status: 'active' },
  { id: 'list-svc-2', sellerId: 'user-demo-1', type: 'service', title: 'صيانة مكيفات', titleAr: 'صيانة مكيفات', dataJson: JSON.stringify({ name: 'صيانة مكيفات', category: 'maintenance', price: 30, provider: 'فريق الصيانة', rating: 4.7 }), location: 'حولي', price: 30, status: 'active' },
];

// ─── Main seed function ────────────────────────────────────────────────────

export async function seedDatabase(): Promise<{ users: number; listings: number; capabilities: number }> {
  console.log('[JASIM SEED] Starting...');

  // 1. Sync capabilities
  await syncCapabilitiesToDb();
  const capCount = capabilityRegistry.list().length;

  // 2. Upsert demo users
  let userCount = 0;
  for (const user of DEMO_USERS) {
    await db.user.upsert({
      where: { id: user.id },
      create: user,
      update: user,
    });
    userCount++;
  }

  // 3. Upsert demo listings
  let listingCount = 0;
  for (const listing of DEMO_LISTINGS) {
    await db.listing.upsert({
      where: { id: listing.id },
      create: {
        id: listing.id,
        sellerId: listing.sellerId,
        type: listing.type,
        title: listing.title,
        titleAr: listing.titleAr,
        dataJson: listing.dataJson,
        location: listing.location,
        price: listing.price,
        currency: 'KWD',
        status: listing.status,
      },
      update: {
        title: listing.title,
        titleAr: listing.titleAr,
        dataJson: listing.dataJson,
        location: listing.location,
        price: listing.price,
      },
    });
    listingCount++;
  }

  // 4. Add demo memory items
  await db.memoryItem.upsert({
    where: { id: 'mem-demo-pref-lang' },
    create: {
      id: 'mem-demo-pref-lang',
      userId: 'user-demo-1',
      type: 'preference',
      key: 'language',
      value: 'ar',
      confidence: 1.0,
    },
    update: {},
  });

  console.log(`[JASIM SEED] Done: ${userCount} users, ${listingCount} listings, ${capCount} capabilities`);
  return { users: userCount, listings: listingCount, capabilities: capCount };
}

// ─── Run if executed directly ──────────────────────────────────────────────

if (require.main === module) {
  seedDatabase().then((r) => {
    console.log('Seed result:', r);
    process.exit(0);
  }).catch((e) => {
    console.error('Seed failed:', e);
    process.exit(1);
  });
}

// ============================================================================
// 🌍 JASIM — World Builder (LLM-powered, Zod-validated)
// Generates World Model from Intent — entities, relations, policies
// ============================================================================

import type { WorldModel, WorldEntity, IntentResult, DNAGene } from './types';
import { chatWithLLM } from './ai-gateway';

// ─── Predefined Entity Schemas (fallback when LLM unavailable) ─────────────

const ENTITY_SCHEMAS: Record<string, Omit<WorldEntity, 'id'>> = {
  car: {
    type: 'car', name: 'Car', nameAr: 'سيارة',
    fields: [
      { id: 'brand', name: 'brand', label: 'Brand', labelAr: 'الماركة', type: 'string', searchable: true, filterable: true, sortable: true, required: true },
      { id: 'model', name: 'model', label: 'Model', labelAr: 'الموديل', type: 'string', searchable: true, filterable: true, sortable: true, required: true },
      { id: 'year', name: 'year', label: 'Year', labelAr: 'السنة', type: 'number', searchable: false, filterable: true, sortable: true, required: true },
      { id: 'price', name: 'price', label: 'Price', labelAr: 'السعر', type: 'currency', searchable: false, filterable: true, sortable: true, required: true },
      { id: 'mileage', name: 'mileage', label: 'Mileage', labelAr: 'الممشى', type: 'number', searchable: false, filterable: true, sortable: true, required: false },
      { id: 'transmission', name: 'transmission', label: 'Transmission', labelAr: 'الناقل', type: 'select', searchable: false, filterable: true, sortable: false, required: false, options: [
        { value: 'automatic', label: 'Automatic', labelAr: 'أوتوماتيك' },
        { value: 'manual', label: 'Manual', labelAr: 'عادي' },
      ]},
      { id: 'fuel', name: 'fuel', label: 'Fuel', labelAr: 'الوقود', type: 'select', searchable: false, filterable: true, sortable: false, required: false, options: [
        { value: 'petrol', label: 'Petrol', labelAr: 'بنزين' },
        { value: 'diesel', label: 'Diesel', labelAr: 'ديزل' },
        { value: 'hybrid', label: 'Hybrid', labelAr: 'هجين' },
        { value: 'electric', label: 'Electric', labelAr: 'كهربائي' },
      ]},
      { id: 'image', name: 'image', label: 'Image', labelAr: 'الصورة', type: 'image', searchable: false, filterable: false, sortable: false, required: false },
      { id: 'location', name: 'location', label: 'Location', labelAr: 'الموقع', type: 'location', searchable: true, filterable: true, sortable: false, required: false },
    ],
    relations: [{ targetEntityType: 'seller', type: 'many-to-one' }],
  },
  product: {
    type: 'product', name: 'Product', nameAr: 'منتج',
    fields: [
      { id: 'title', name: 'title', label: 'Title', labelAr: 'العنوان', type: 'string', searchable: true, filterable: false, sortable: true, required: true },
      { id: 'price', name: 'price', label: 'Price', labelAr: 'السعر', type: 'currency', searchable: false, filterable: true, sortable: true, required: true },
      { id: 'category', name: 'category', label: 'Category', labelAr: 'الفئة', type: 'select', searchable: false, filterable: true, sortable: false, required: true, options: [
        { value: 'electronics', label: 'Electronics', labelAr: 'إلكترونيات' },
        { value: 'fashion', label: 'Fashion', labelAr: 'أزياء' },
        { value: 'home', label: 'Home', labelAr: 'منزل' },
        { value: 'sports', label: 'Sports', labelAr: 'رياضة' },
      ]},
      { id: 'condition', name: 'condition', label: 'Condition', labelAr: 'الحالة', type: 'select', searchable: false, filterable: true, sortable: false, required: false, options: [
        { value: 'new', label: 'New', labelAr: 'جديد' },
        { value: 'used', label: 'Used', labelAr: 'مستعمل' },
        { value: 'refurbished', label: 'Refurbished', labelAr: 'مجدد' },
      ]},
      { id: 'image', name: 'image', label: 'Image', labelAr: 'الصورة', type: 'image', searchable: false, filterable: false, sortable: false, required: false },
      { id: 'location', name: 'location', label: 'Location', labelAr: 'الموقع', type: 'location', searchable: true, filterable: true, sortable: false, required: false },
    ],
    relations: [{ targetEntityType: 'seller', type: 'many-to-one' }],
  },
  job: {
    type: 'job', name: 'Job', nameAr: 'وظيفة',
    fields: [
      { id: 'title', name: 'title', label: 'Title', labelAr: 'المسمى', type: 'string', searchable: true, filterable: false, sortable: false, required: true },
      { id: 'company', name: 'company', label: 'Company', labelAr: 'الشركة', type: 'string', searchable: true, filterable: true, sortable: false, required: true },
      { id: 'salary', name: 'salary', label: 'Salary', labelAr: 'الراتب', type: 'currency', searchable: false, filterable: true, sortable: true, required: false },
      { id: 'category', name: 'category', label: 'Category', labelAr: 'الفئة', type: 'select', searchable: false, filterable: true, sortable: false, required: true, options: [
        { value: 'tech', label: 'Technology', labelAr: 'تقنية' },
        { value: 'finance', label: 'Finance', labelAr: 'مالية' },
        { value: 'health', label: 'Healthcare', labelAr: 'صحة' },
        { value: 'education', label: 'Education', labelAr: 'تعليم' },
        { value: 'services', label: 'Services', labelAr: 'خدمات' },
      ]},
      { id: 'location', name: 'location', label: 'Location', labelAr: 'الموقع', type: 'location', searchable: true, filterable: true, sortable: false, required: false },
      { id: 'type', name: 'type', label: 'Type', labelAr: 'النوع', type: 'select', searchable: false, filterable: true, sortable: false, required: false, options: [
        { value: 'fulltime', label: 'Full Time', labelAr: 'دوام كامل' },
        { value: 'parttime', label: 'Part Time', labelAr: 'دوام جزئي' },
        { value: 'remote', label: 'Remote', labelAr: 'عن بعد' },
        { value: 'contract', label: 'Contract', labelAr: 'تعاقد' },
      ]},
    ],
    relations: [{ targetEntityType: 'employer', type: 'many-to-one' }],
  },
  food: {
    type: 'food', name: 'Food', nameAr: 'طعام',
    fields: [
      { id: 'name', name: 'name', label: 'Name', labelAr: 'الاسم', type: 'string', searchable: true, filterable: false, sortable: false, required: true },
      { id: 'restaurant', name: 'restaurant', label: 'Restaurant', labelAr: 'المطعم', type: 'string', searchable: true, filterable: true, sortable: false, required: true },
      { id: 'price', name: 'price', label: 'Price', labelAr: 'السعر', type: 'currency', searchable: false, filterable: true, sortable: true, required: true },
      { id: 'cuisine', name: 'cuisine', label: 'Cuisine', labelAr: 'المطبخ', type: 'select', searchable: false, filterable: true, sortable: false, required: false, options: [
        { value: 'arabic', label: 'Arabic', labelAr: 'عربي' },
        { value: 'indian', label: 'Indian', labelAr: 'هندي' },
        { value: 'italian', label: 'Italian', labelAr: 'إيطالي' },
        { value: 'fastfood', label: 'Fast Food', labelAr: 'وجبات سريعة' },
      ]},
      { id: 'spicy', name: 'spicy', label: 'Spicy', labelAr: 'حار', type: 'boolean', searchable: false, filterable: true, sortable: false, required: false },
    ],
    relations: [{ targetEntityType: 'restaurant', type: 'many-to-one' }],
  },
  realestate: {
    type: 'realestate', name: 'Real Estate', nameAr: 'عقار',
    fields: [
      { id: 'title', name: 'title', label: 'Title', labelAr: 'العنوان', type: 'string', searchable: true, filterable: false, sortable: false, required: true },
      { id: 'type', name: 'type', label: 'Type', labelAr: 'النوع', type: 'select', searchable: false, filterable: true, sortable: false, required: true, options: [
        { value: 'apartment', label: 'Apartment', labelAr: 'شقة' },
        { value: 'villa', label: 'Villa', labelAr: 'فيلا' },
        { value: 'land', label: 'Land', labelAr: 'أرض' },
        { value: 'office', label: 'Office', labelAr: 'مكتب' },
      ]},
      { id: 'purpose', name: 'purpose', label: 'Purpose', labelAr: 'الغرض', type: 'select', searchable: false, filterable: true, sortable: false, required: true, options: [
        { value: 'sale', label: 'For Sale', labelAr: 'للبيع' },
        { value: 'rent', label: 'For Rent', labelAr: 'للإيجار' },
      ]},
      { id: 'price', name: 'price', label: 'Price', labelAr: 'السعر', type: 'currency', searchable: false, filterable: true, sortable: true, required: true },
      { id: 'area', name: 'area', label: 'Area (m²)', labelAr: 'المساحة (م²)', type: 'number', searchable: false, filterable: true, sortable: true, required: true },
      { id: 'bedrooms', name: 'bedrooms', label: 'Bedrooms', labelAr: 'غرف النوم', type: 'number', searchable: false, filterable: true, sortable: true, required: false },
      { id: 'location', name: 'location', label: 'Location', labelAr: 'الموقع', type: 'location', searchable: true, filterable: true, sortable: false, required: true },
      { id: 'image', name: 'image', label: 'Image', labelAr: 'الصورة', type: 'image', searchable: false, filterable: false, sortable: false, required: false },
    ],
    relations: [{ targetEntityType: 'agent', type: 'many-to-one' }],
  },
  restaurant: {
    type: 'restaurant', name: 'Restaurant', nameAr: 'مطعم',
    fields: [
      { id: 'name', name: 'name', label: 'Name', labelAr: 'الاسم', type: 'string', searchable: true, filterable: false, sortable: false, required: true },
      { id: 'cuisine', name: 'cuisine', label: 'Cuisine', labelAr: 'المطبخ', type: 'select', searchable: false, filterable: true, sortable: false, required: true, options: [
        { value: 'arabic', label: 'Arabic', labelAr: 'عربي' },
        { value: 'indian', label: 'Indian', labelAr: 'هندي' },
        { value: 'italian', label: 'Italian', labelAr: 'إيطالي' },
        { value: 'fastfood', label: 'Fast Food', labelAr: 'وجبات سريعة' },
      ]},
      { id: 'rating', name: 'rating', label: 'Rating', labelAr: 'التقييم', type: 'number', searchable: false, filterable: true, sortable: true, required: false },
      { id: 'location', name: 'location', label: 'Location', labelAr: 'الموقع', type: 'location', searchable: true, filterable: true, sortable: false, required: true },
    ],
    relations: [{ targetEntityType: 'food', type: 'one-to-many' }],
  },
  service: {
    type: 'service', name: 'Service', nameAr: 'خدمة',
    fields: [
      { id: 'name', name: 'name', label: 'Name', labelAr: 'الاسم', type: 'string', searchable: true, filterable: false, sortable: false, required: true },
      { id: 'category', name: 'category', label: 'Category', labelAr: 'الفئة', type: 'select', searchable: false, filterable: true, sortable: false, required: true, options: [
        { value: 'cleaning', label: 'Cleaning', labelAr: 'تنظيف' },
        { value: 'maintenance', label: 'Maintenance', labelAr: 'صيانة' },
        { value: 'tutoring', label: 'Tutoring', labelAr: 'تدريس' },
        { value: 'transport', label: 'Transport', labelAr: 'نقل' },
      ]},
      { id: 'price', name: 'price', label: 'Price', labelAr: 'السعر', type: 'currency', searchable: false, filterable: true, sortable: true, required: true },
      { id: 'provider', name: 'provider', label: 'Provider', labelAr: 'المزود', type: 'string', searchable: true, filterable: true, sortable: false, required: true },
      { id: 'rating', name: 'rating', label: 'Rating', labelAr: 'التقييم', type: 'number', searchable: false, filterable: true, sortable: true, required: false },
    ],
    relations: [],
  },
  seller: {
    type: 'seller', name: 'Seller', nameAr: 'بائع',
    fields: [
      { id: 'name', name: 'name', label: 'Name', labelAr: 'الاسم', type: 'string', searchable: true, filterable: false, sortable: false, required: true },
      { id: 'verified', name: 'verified', label: 'Verified', labelAr: 'موثق', type: 'boolean', searchable: false, filterable: true, sortable: false, required: false },
      { id: 'rating', name: 'rating', label: 'Rating', labelAr: 'التقييم', type: 'number', searchable: false, filterable: true, sortable: true, required: false },
    ],
    relations: [],
  },
};

// ─── Pick entities based on intent ────────────────────────────────────────

function pickEntitiesForIntent(intent: IntentResult): string[] {
  if (intent.bubbleType === 'real_estate') return ['realestate', 'seller'];
  if (intent.bubbleType === 'job' || intent.bubbleType === 'recruitment') return ['job', 'seller'];
  if (intent.bubbleType === 'food' || intent.bubbleType === 'restaurant') return ['restaurant', 'food'];
  if (intent.bubbleType === 'product' || intent.type === 'SELL' || intent.type === 'BUY') {
    if (intent.entities.some((e) => e.key === 'carBrand')) return ['car', 'seller'];
    return ['product', 'seller'];
  }
  if (intent.bubbleType === 'service') return ['service', 'seller'];
  if (intent.type === 'BUILD_PLATFORM') return ['product', 'seller'];
  return ['product', 'seller'];
}

// ─── Build World Model ────────────────────────────────────────────────────

export function buildWorldModel(intent: IntentResult, dna: DNAGene): WorldModel {
  const entityTypes = pickEntitiesForIntent(intent);
  const entities: WorldEntity[] = entityTypes
    .filter((t, i, arr) => arr.indexOf(t) === i)
    .map((t) => ({ ...ENTITY_SCHEMAS[t], id: `entity-${t}-${Date.now()}` }));

  const policies = [
    { id: 'policy-islamic', rule: 'No haram items (alcohol, tobacco, gambling, riba)', ruleAr: 'منع المنتجات المحرمة', severity: 'blocking' as const },
    { id: 'policy-verified', rule: 'Sellers must be verified before listing', ruleAr: 'يجب توثيق البائعين', severity: 'mandatory' as const },
    { id: 'policy-escrow', rule: 'High-value transactions use escrow', ruleAr: 'المعاملات الكبيرة تستخدم الضمان', severity: 'advisory' as const },
  ];

  const worldNameAr = intent.type === 'BUILD_PLATFORM'
    ? `منصة مخصصة (${intent.bubbleType})`
    : `عالم ${intent.bubbleType}`;

  return {
    id: `world-${Date.now()}`,
    name: `${intent.bubbleType} World`,
    nameAr: worldNameAr,
    dnaId: dna.id,
    entities,
    policies,
    createdAt: Date.now(),
  };
}

// ─── Get entity schema helper ──────────────────────────────────────────────

export function getEntitySchema(entityType: string): WorldEntity | null {
  const schema = ENTITY_SCHEMAS[entityType];
  if (!schema) return null;
  return { ...schema, id: `entity-${entityType}-schema` };
}

// ─── Get all entity types ──────────────────────────────────────────────────

export function listEntityTypes(): string[] {
  return Object.keys(ENTITY_SCHEMAS);
}

// ============================================================================
// 📦 JASIM — Mock Data Store
// Realistic Arabic/English sample data to demonstrate Novel Tasks
// ============================================================================

export interface MockItem {
  id: string;
  type: 'car' | 'product' | 'job' | 'food' | 'realestate' | 'service' | 'restaurant';
  [key: string]: unknown;
}

// ─── Cars Dataset ──────────────────────────────────────────────────────────

export const MOCK_CARS: MockItem[] = [
  { id: 'car-1', type: 'car', brand: 'Toyota', model: 'Camry', year: 2023, price: 7800, mileage: 15000, transmission: 'automatic', fuel: 'petrol', location: 'الكويت', image: '🚗', condition: 'used' },
  { id: 'car-2', type: 'car', brand: 'Toyota', model: 'Camry', year: 2022, price: 6500, mileage: 32000, transmission: 'automatic', fuel: 'petrol', location: 'حولي', image: '🚙', condition: 'used' },
  { id: 'car-3', type: 'car', brand: 'Toyota', model: 'Corolla', year: 2023, price: 5500, mileage: 8000, transmission: 'automatic', fuel: 'hybrid', location: 'السالمية', image: '🚗', condition: 'used' },
  { id: 'car-4', type: 'car', brand: 'Toyota', model: 'Hilux', year: 2024, price: 12500, mileage: 5000, transmission: 'manual', fuel: 'diesel', location: 'الجهراء', image: '🛻', condition: 'used' },
  { id: 'car-5', type: 'car', brand: 'Hyundai', model: 'Sonata', year: 2023, price: 6800, mileage: 12000, transmission: 'automatic', fuel: 'petrol', location: 'الكويت', image: '🚗', condition: 'used' },
  { id: 'car-6', type: 'car', brand: 'Nissan', model: 'Altima', year: 2023, price: 7200, mileage: 18000, transmission: 'automatic', fuel: 'petrol', location: 'حولي', image: '🚙', condition: 'used' },
  { id: 'car-7', type: 'car', brand: 'Kia', model: 'Sportage', year: 2024, price: 9200, mileage: 3000, transmission: 'automatic', fuel: 'petrol', location: 'الأحمدي', image: '🚙', condition: 'used' },
  { id: 'car-8', type: 'car', brand: 'Toyota', model: 'Land Cruiser', year: 2023, price: 18500, mileage: 22000, transmission: 'automatic', fuel: 'petrol', location: 'الكويت', image: '🚙', condition: 'used' },
];

// ─── Products Dataset ──────────────────────────────────────────────────────

export const MOCK_PRODUCTS: MockItem[] = [
  { id: 'p-1', type: 'product', title: 'Lenovo Legion 5 Pro', brand: 'Lenovo', category: 'electronics', price: 320, condition: 'used', location: 'الكويت', image: '💻', description: 'لابتوب Lenovo Legion 5 Pro، Ryzen 7، RTX 4060، 16GB RAM، SSD 512GB' },
  { id: 'p-2', type: 'product', title: 'iPhone 14 Pro Max', brand: 'iPhone', category: 'electronics', price: 410, condition: 'used', location: 'حولي', image: '📱', description: 'آيفون 14 برو ماكس 256GB، بحالة ممتازة، يأتي بالشاحن الأصلي' },
  { id: 'p-3', type: 'product', title: 'Samsung Galaxy S23', brand: 'Samsung', category: 'electronics', price: 280, condition: 'used', location: 'السالمية', image: '📱', description: 'سامسونج جالاكسي S23 بكامل ملحقاته' },
  { id: 'p-4', type: 'product', title: 'Sony WH-1000XM5 Headphones', brand: 'Sony', category: 'electronics', price: 180, condition: 'used', location: 'الكويت', image: '🎧', description: 'سماعات سوني عازلة للضوضاء بحالة ممتازة' },
  { id: 'p-5', type: 'product', title: 'Dell XPS 15', brand: 'Dell', category: 'electronics', price: 950, condition: 'used', location: 'الجهراء', image: '💻', description: 'دل XPS 15، i7، 32GB RAM، RTX 4050' },
  { id: 'p-6', type: 'product', title: 'iPad Pro 12.9 M2', brand: 'Apple', category: 'electronics', price: 720, condition: 'used', location: 'الكويت', image: '📱', description: 'آيباد برو M2 بحالة ممتازة' },
];

// ─── Jobs Dataset ───────────────────────────────────────────────────────────

export const MOCK_JOBS: MockItem[] = [
  { id: 'j-1', type: 'job', title: 'Senior Frontend Developer', company: 'شركة التقنية المتقدمة', salary: 1800, category: 'tech', location: 'الكويت', type: 'fulltime' },
  { id: 'j-2', type: 'job', title: 'محاسب مالي', company: 'مكتب الاستشارات المالية', salary: 1200, category: 'finance', location: 'حولي', type: 'fulltime' },
  { id: 'j-3', type: 'job', title: 'ممرض/ة مؤهل', company: 'مستشفى السلام', salary: 900, category: 'health', location: 'السالمية', type: 'fulltime' },
  { id: 'j-4', type: 'job', title: 'معلم رياضيات', company: 'مدرسة المستقبل', salary: 1100, category: 'education', location: 'الجهراء', type: 'fulltime' },
  { id: 'j-5', type: 'job', title: 'Remote Full Stack Engineer', company: 'TechCorp', salary: 2500, category: 'tech', location: 'عن بعد', type: 'remote' },
  { id: 'j-6', type: 'job', title: 'مصمم جرافيك', company: 'وكالة الإبداع', salary: 850, category: 'services', location: 'الكويت', type: 'fulltime' },
  { id: 'j-7', type: 'job', title: 'سائق توصيل', company: 'شركة التوصيلات السريعة', salary: 600, category: 'services', location: 'حولي', type: 'parttime' },
];

// ─── Food Dataset ───────────────────────────────────────────────────────────

export const MOCK_FOOD: MockItem[] = [
  { id: 'f-1', type: 'food', name: 'مندي لحم', restaurant: 'مطعم اليمن الأصيل', price: 4.5, cuisine: 'arabic', spicy: false },
  { id: 'f-2', type: 'food', name: 'برياني دجاج', restaurant: 'مطعم الهند', price: 3.8, cuisine: 'indian', spicy: true },
  { id: 'f-3', type: 'food', name: 'بيتزا مارجريتا', restaurant: 'بيتزا هت', price: 3.2, cuisine: 'italian', spicy: false },
  { id: 'f-4', type: 'food', name: 'مجبوس دجاج', restaurant: 'مطعم الكويت', price: 3.5, cuisine: 'arabic', spicy: false },
  { id: 'f-5', type: 'food', name: 'برجر لحم أنغوس', restaurant: 'شاك شاك', price: 4.2, cuisine: 'fastfood', spicy: false },
  { id: 'f-6', type: 'food', name: 'كبسة لحم', restaurant: 'مطعم نجد', price: 4.0, cuisine: 'arabic', spicy: true },
];

// ─── Real Estate Dataset ────────────────────────────────────────────────────

export const MOCK_REALESTATE: MockItem[] = [
  { id: 'r-1', type: 'realestate', title: 'شقة فاخرة في السالمية', type_2: 'apartment', purpose: 'sale', price: 85000, area: 180, bedrooms: 3, location: 'السالمية', image: '🏢' },
  { id: 'r-2', type: 'realestate', title: 'فيلا في الجهراء', type_2: 'villa', purpose: 'sale', price: 220000, area: 450, bedrooms: 5, location: 'الجهراء', image: '🏠' },
  { id: 'r-3', type: 'realestate', title: 'شقة للإيجار في حولي', type_2: 'apartment', purpose: 'rent', price: 450, area: 120, bedrooms: 2, location: 'حولي', image: '🏢' },
  { id: 'r-4', type: 'realestate', title: 'أرض سكنية في الأحمدي', type_2: 'land', purpose: 'sale', price: 60000, area: 500, bedrooms: 0, location: 'الأحمدي', image: '🌍' },
  { id: 'r-5', type: 'realestate', title: 'مكتب تجاري في الكويت', type_2: 'office', purpose: 'rent', price: 1200, area: 80, bedrooms: 0, location: 'الكويت', image: '🏢' },
];

// ─── Brand name mappings (Arabic → English) ──────────────────────────────

const BRAND_SYNONYMS: Record<string, string[]> = {
  Toyota: ['toyota', 'تويوتا', 'كامري', 'camry', 'كورولا', 'corolla', 'هيلوكس', 'hilux', 'لاند كروزر', 'land cruiser', 'لاندكروزر'],
  Hyundai: ['hyundai', 'هيونداي', 'سوناتا', 'sonata', 'elantra', 'إلنترا'],
  Nissan: ['nissan', 'نيسان', 'altima', 'التيما'],
  Kia: ['kia', 'كيا', 'sportage', 'سبورتاج'],
  iPhone: ['iphone', 'آيفون', 'ايفون', 'apple', 'أبل'],
  Samsung: ['samsung', 'سامسونج', 'galaxy', 'جالكسي'],
  Lenovo: ['lenovo', 'لينوفو', 'legion', 'ليجن'],
  Dell: ['dell', 'دل', 'xps'],
  Sony: ['sony', 'سوني', 'wh-1000'],
};

function normalizeBrand(brand: string): string | null {
  const lower = brand.toLowerCase().trim();
  for (const [canonical, synonyms] of Object.entries(BRAND_SYNONYMS)) {
    if (synonyms.some((s) => s.toLowerCase() === lower)) {
      return canonical;
    }
    // Partial match: query contains synonym
    if (synonyms.some((s) => lower.includes(s.toLowerCase()) || s.toLowerCase().includes(lower))) {
      return canonical;
    }
  }
  return null;
}

// ─── Search Function ───────────────────────────────────────────────────────

export interface SearchFilters {
  minPrice?: number;
  maxPrice?: number;
  brand?: string;
  category?: string;
  location?: string;
  yearMin?: number;
  yearMax?: number;
  query?: string;
}

function matchesFilters(item: MockItem, filters: SearchFilters): boolean {
  if (filters.minPrice !== undefined && (item.price as number) < filters.minPrice) return false;
  if (filters.maxPrice !== undefined && (item.price as number) > filters.maxPrice) return false;
  if (filters.brand) {
    const itemBrand = (item.brand as string) || '';
    const canonical = normalizeBrand(filters.brand);
    const itemCanonical = normalizeBrand(itemBrand);
    if (canonical && itemCanonical && canonical !== itemCanonical) return false;
    if (!canonical && !itemBrand.toLowerCase().includes(filters.brand.toLowerCase())) return false;
  }
  if (filters.category && (item.category as string) !== filters.category) return false;
  if (filters.location && !String(item.location).includes(filters.location)) return false;
  if (filters.yearMin && (item.year as number) < filters.yearMin) return false;
  if (filters.yearMax && (item.year as number) > filters.yearMax) return false;
  if (filters.query) {
    const text = JSON.stringify(item).toLowerCase();
    if (!text.includes(filters.query.toLowerCase())) return false;
  }
  return true;
}

export function searchItems(type: 'car' | 'product' | 'job' | 'food' | 'realestate', filters: SearchFilters = {}): MockItem[] {
  let dataset: MockItem[] = [];
  switch (type) {
    case 'car': dataset = MOCK_CARS; break;
    case 'product': dataset = MOCK_PRODUCTS; break;
    case 'job': dataset = MOCK_JOBS; break;
    case 'food': dataset = MOCK_FOOD; break;
    case 'realestate': dataset = MOCK_REALESTATE; break;
  }
  return dataset.filter((item) => matchesFilters(item, filters));
}

// ─── Revenue calculation demo ──────────────────────────────────────────────

export function calculateRevenue(amount: number, tier: 'b2c_free' | 'b2c_express' | 'b2b_starter' | 'b2b_pro' | 'b2b_enterprise'): {
  commission: number;
  fee: number;
  sellerReceives: number;
  total: number;
} {
  const rates = {
    b2c_free: { rate: 0, fee: 0 },
    b2c_express: { rate: 0.015, fee: 0.25 },
    b2b_starter: { rate: 0.025, fee: 0.10 },
    b2b_pro: { rate: 0.02, fee: 0.05 },
    b2b_enterprise: { rate: 0.015, fee: 0 },
  };
  const config = rates[tier];
  const commission = amount * config.rate;
  const fee = config.fee;
  return {
    commission,
    fee,
    sellerReceives: amount - commission - fee,
    total: amount,
  };
}

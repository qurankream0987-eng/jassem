// ============================================================================
// 🧬 JASIM — Suggestion Examples (client-safe, no server imports)
// ============================================================================

export const SUGGESTION_EXAMPLES: Array<{ text: string; label: string; intent: string }> = [
  { text: 'أريد شراء كامري 2023 أقل من 8000 دينار', label: '🚗 بحث عن سيارة', intent: 'CAR_SEARCH' },
  { text: 'أريد بيع لابتوب Lenovo Legion مستعمل', label: '💻 بيع منتج', intent: 'SELL_PRODUCT' },
  { text: 'أبحث عن وظيفة مطور', label: '💼 بحث عن وظيفة', intent: 'JOB_SEARCH' },
  { text: 'ابحث لي عن شقة للإيجار في حولي', label: '🏠 عقار', intent: 'RENT_SEARCH' },
  { text: 'أريد برياني دجاج حار', label: '🍽️ طلب طعام', intent: 'FOOD_SEARCH' },
  { text: 'قارن بين iPhone و Samsung', label: '⚖️ مقارنة', intent: 'COMPARE' },
  { text: 'حلل بيانات السوق', label: '📊 تحليل', intent: 'ANALYZE' },
  { text: 'عايز دواء للصداع', label: '💊 صيدلية', intent: 'PHARMACY' },
];

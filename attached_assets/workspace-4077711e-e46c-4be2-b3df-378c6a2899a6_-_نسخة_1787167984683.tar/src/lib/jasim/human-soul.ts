// ============================================================================
// 💚 JASIM — Human Soul Reader
// Detects emotional state, crisis, and tailors response tone accordingly
// ============================================================================

import type { HumanSoul } from './types';

interface SoulPattern {
  regex: RegExp;
  state: HumanSoul['emotionalState'];
  tone: HumanSoul['voiceTone'];
  empathy: string;
  action: string;
  crisis: boolean;
  trust: number;
}

const SOUL_PATTERNS: SoulPattern[] = [
  // ─── Crisis / Emergency ────────────────────────────────────────────────
  {
    regex: /طوارئ|انقذوني|نجدة|حريق|سرقة|حادث|نزيف|غرق|صعق|heart\s+attack|emergency|help\s+me|911/i,
    state: 'urgent',
    tone: 'urgent',
    empathy: 'أسمعك، سيتم التصرف فوراً. ابقَ هادئاً قدر الإمكان.',
    action: 'ESCALATE_EMERGENCY',
    crisis: true,
    trust: 0.5,
  },
  {
    regex: /مريض\s+جدا|تعبان\s+مو\s+طبيعي|ألم\s+شديد|concious|fainted/i,
    state: 'anxious',
    tone: 'urgent',
    empathy: 'حالتك تستدعي اهتماماً عاجلاً. سأساعدك خطوة بخطوة.',
    action: 'SUGGEST_MEDICAL',
    crisis: true,
    trust: 0.4,
  },
  // ─── Frustration ───────────────────────────────────────────────────────
  {
    regex: /غاضب|زعلان|سيء|محبط|مستفز|sick\s+of|frustrated|angry|annoyed|disappointed/i,
    state: 'frustrated',
    tone: 'gentle',
    empathy: 'أتفهم إحباطك. سأبذل كل ما بوسعي لحل المشكلة الآن.',
    action: 'APOLOGIZE_AND_RESOLVE',
    crisis: false,
    trust: 0.3,
  },
  {
    regex: /ما\s+يشتغل|عطل|خربان|broken|not\s+working|bug|error/i,
    state: 'frustrated',
    tone: 'gentle',
    empathy: 'عذراً على الإزعاج. سأصلح هذا لك فوراً.',
    action: 'REPAIR_FLOW',
    crisis: false,
    trust: 0.2,
  },
  // ─── Happiness ─────────────────────────────────────────────────────────
  {
    regex: /شكرا|ممتاز|رائع|سعيد|mashallah|ماشاء\s+الله|thanks|awesome|great|happy/i,
    state: 'happy',
    tone: 'celebratory',
    empathy: 'يسعدني أنك راضٍ! 🎉 هذا هدفنا دائماً.',
    action: 'CONTINUE_NORMALLY',
    crisis: false,
    trust: 0.5,
  },
  // ─── Confusion ─────────────────────────────────────────────────────────
  {
    regex: /مو\s+فاهم|ما\s+فهمت|محتار|كيف|ليش|confused|lost|unsure|don'?t\s+understand/i,
    state: 'confused',
    tone: 'reassuring',
    empathy: 'لا بأس، سأشرح لك خطوة بخطوة بوضوح.',
    action: 'EXPLAIN_STEP_BY_STEP',
    crisis: false,
    trust: 0.1,
  },
  // ─── Anxiety ───────────────────────────────────────────────────────────
  {
    regex: /قلقان|خايف|متوتر|worried|nervous|anxious|stress/i,
    state: 'anxious',
    tone: 'reassuring',
    empathy: 'أتفهم قلقك. الأمور ستكون على ما يرام بإذن الله.',
    action: 'REASSURE_AND_GUIDE',
    crisis: false,
    trust: 0.2,
  },
];

// ─── Default (calm professional) ───────────────────────────────────────────

const DEFAULT_SOUL: HumanSoul = {
  emotionalState: 'calm',
  crisisDetected: false,
  empathyResponse: '',
  voiceTone: 'professional',
  suggestedAction: 'PROCEED_NORMALLY',
  trustAdjustment: 0,
};

// ─── Main Reader ──────────────────────────────────────────────────────────

export function readHumanSoul(text: string): HumanSoul {
  for (const pattern of SOUL_PATTERNS) {
    if (pattern.regex.test(text)) {
      return {
        emotionalState: pattern.state,
        crisisDetected: pattern.crisis,
        empathyResponse: pattern.empathy,
        voiceTone: pattern.tone,
        suggestedAction: pattern.action,
        trustAdjustment: pattern.trust,
      };
    }
  }
  return { ...DEFAULT_SOUL };
}

// ─── Tone CSS classes (for UI feedback) ───────────────────────────────────

export const TONE_STYLES: Record<HumanSoul['voiceTone'], {
  border: string;
  bg: string;
  text: string;
  label: string;
  labelAr: string;
}> = {
  gentle: {
    border: 'border-emerald-400/30',
    bg: 'bg-emerald-50/50 dark:bg-emerald-950/20',
    text: 'text-emerald-700 dark:text-emerald-300',
    label: 'Gentle',
    labelAr: 'لطيف',
  },
  professional: {
    border: 'border-slate-400/30',
    bg: 'bg-slate-50/50 dark:bg-slate-900/20',
    text: 'text-slate-700 dark:text-slate-300',
    label: 'Professional',
    labelAr: 'احترافي',
  },
  urgent: {
    border: 'border-red-500/40',
    bg: 'bg-red-50/50 dark:bg-red-950/30',
    text: 'text-red-700 dark:text-red-300',
    label: 'Urgent',
    labelAr: 'عاجل',
  },
  celebratory: {
    border: 'border-amber-400/40',
    bg: 'bg-amber-50/50 dark:bg-amber-950/20',
    text: 'text-amber-700 dark:text-amber-300',
    label: 'Celebratory',
    labelAr: 'احتفالي',
  },
  reassuring: {
    border: 'border-sky-400/30',
    bg: 'bg-sky-50/50 dark:bg-sky-950/20',
    text: 'text-sky-700 dark:text-sky-300',
    label: 'Reassuring',
    labelAr: 'مطمئن',
  },
};

export const EMOTION_ICONS: Record<HumanSoul['emotionalState'], string> = {
  calm: '😌',
  urgent: '🚨',
  frustrated: '😣',
  happy: '😊',
  confused: '🤔',
  anxious: '😟',
};

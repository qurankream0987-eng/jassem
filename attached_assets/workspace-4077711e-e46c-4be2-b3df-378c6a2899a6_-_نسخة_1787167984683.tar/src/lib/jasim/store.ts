// ============================================================================
// 🗃️ JASIM — Client State Store (Zustand)
// Manages: messages, loading state, UI preferences
// ============================================================================

import { create } from 'zustand';
import type { ChatMessage } from '@/lib/jasim/types';

interface JasimStore {
  // State
  messages: ChatMessage[];
  isLoading: boolean;
  sessionId: string;
  error: string | null;

  // UI prefs (Zustand scope: user prefs only — per architecture rule)
  density: 'comfortable' | 'compact';
  showWorkflow: boolean;
  showDnaViz: boolean;
  showSoul: boolean;
  showIslamic: boolean;

  // Actions
  sendMessage: (text: string) => Promise<void>;
  clearChat: () => void;
  setDensity: (d: 'comfortable' | 'compact') => void;
  togglePanel: (panel: 'workflow' | 'dna' | 'soul' | 'islamic') => void;
}

export const useJasimStore = create<JasimStore>((set, get) => ({
  messages: [],
  isLoading: false,
  sessionId: `web-${Date.now()}`,
  error: null,

  density: 'comfortable',
  showWorkflow: true,
  showDnaViz: true,
  showSoul: true,
  showIslamic: true,

  sendMessage: async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || get().isLoading) return;

    const sessionId = get().sessionId;
    set({ isLoading: true, error: null });

    // Optimistic user message
    const userMessage: ChatMessage = {
      id: `msg-user-${Date.now()}`,
      role: 'user',
      text: trimmed,
      contracts: [],
      timestamp: Date.now(),
    };
    set({ messages: [...get().messages, userMessage] });

    try {
      const response = await fetch('/api/jasim/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: trimmed, sessionId }),
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();
      const assistantMessage: ChatMessage = data.message;

      set({
        messages: [...get().messages, assistantMessage],
        isLoading: false,
      });
    } catch (err) {
      set({
        isLoading: false,
        error: err instanceof Error ? err.message : 'Unknown error',
      });
    }
  },

  clearChat: () => {
    set({ messages: [], error: null, sessionId: `web-${Date.now()}` });
  },

  setDensity: (d) => set({ density: d }),

  togglePanel: (panel) => {
    const state = get();
    if (panel === 'workflow') set({ showWorkflow: !state.showWorkflow });
    if (panel === 'dna') set({ showDnaViz: !state.showDnaViz });
    if (panel === 'soul') set({ showSoul: !state.showSoul });
    if (panel === 'islamic') set({ showIslamic: !state.showIslamic });
  },
}));

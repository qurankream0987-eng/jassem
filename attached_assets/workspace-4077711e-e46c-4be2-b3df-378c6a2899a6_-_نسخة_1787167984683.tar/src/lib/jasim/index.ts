// ============================================================================
// 🧬 JASIM v34.0 — Universal Generative Commercial Runtime
// Public API exports
// ============================================================================

export * from './types';
export * from './jasim-core';
export { SUGGESTION_EXAMPLES } from './suggestions';
export { validateIslamicConscience, getBlockedMessageArabic } from './islamic-conscience';
export { readHumanSoul, TONE_STYLES, EMOTION_ICONS } from './human-soul';
export { classifyIntent } from './intent-classifier-regex';
export { extractIntent, chatWithLLM, extractIntentWithLLM } from './ai-gateway';
export { getDNA, breedDNA, crossover, mutate, invent } from './dna-breeding';
export { buildWorldModel, getEntitySchema, listEntityTypes } from './world-builder';
export { compilePlan, observeStep, verifyAndAdvance, isWorkflowComplete } from './task-planner';
export { capabilityRegistry, syncCapabilitiesToDb } from './capability-registry';
export { registerAllExecutors, releaseEscrow } from './capability-executors';
export { seedDatabase } from './seed';
export * as UIContractGenerator from './ui-contract-generator';

// ============================================================================
// 🎨 JASIM — UI Contract Generator
// Generates UIContract objects from DNA + Workflow State + Intent + Soul
// Pure function: NO React, NO HTML — just data
// ============================================================================

import type {
  UIContract, DNAGene, Workflow, IntentResult, HumanSoul,
  IslamicValidation, WorldModel, PrimitiveType, BubbleType,
} from './types';
import { getCurrentStepOutput } from './task-runtime';
import type { MockItem } from './mock-data';

const now = () => new Date().toISOString();

// ─── Capability → Primitive Type ────────────────────────────────────────────

const CAPABILITY_TO_PRIMITIVE: Record<string, PrimitiveType> = {
  SEARCH: 'search',
  SEARCH_FLIGHT: 'search',
  FILTER: 'search',
  COMPARE: 'comparison',
  MATCH: 'gallery',
  MATCH_CANDIDATES: 'gallery',
  NEGOTIATE: 'negotiation',
  PROPOSE: 'negotiation',
  COUNTER: 'negotiation',
  PAY: 'payment',
  AUTHORIZE: 'payment',
  CAPTURE: 'payment',
  ESCROW: 'confirmation',
  CREATE_LISTING: 'form',
  ORDER: 'form',
  BOOK: 'form',
  BOOK_APPOINTMENT: 'form',
  RESERVE: 'form',
  ENROLL: 'form',
  APPLY: 'form',
  MENU: 'results',
  REVIEW: 'results',
  TRACK: 'progress',
  NOTIFY: 'status',
  ETA: 'progress',
  CONFIRM: 'confirmation',
  RATE: 'form',
  LOCATE: 'status',
  DISPATCH: 'status',
  ESCALATE: 'status',
  LOG: 'status',
  SHORTLIST: 'gallery',
  INTERVIEW: 'form',
  CONTRACT: 'confirmation',
  VERIFY: 'confirmation',
  VERIFY_PRESCRIPTION: 'confirmation',
  DELIVER: 'progress',
  BALANCE: 'dashboard',
  TRANSFER: 'form',
  TOPUP: 'form',
  WITHDRAW: 'form',
  HISTORY: 'results',
  QUERY: 'dashboard',
  AGGREGATE: 'dashboard',
  VISUALIZE: 'dashboard',
  EXPORT: 'confirmation',
  INSIGHT: 'results',
  CREATE_CAMPAIGN: 'form',
  TARGET: 'form',
  BID: 'form',
  OPTIMIZE: 'status',
  DESIGN_WORLD: 'form',
  CREATE_ENTITIES: 'form',
  DEFINE_POLICIES: 'form',
  DEPLOY: 'confirmation',
  MONITOR: 'dashboard',
  BASKET: 'gallery',
  SCHEDULE_DELIVERY: 'form',
  CHAT: 'chat',
  RECOMMEND: 'results',
  RANK: 'results',
  DISPLAY: 'status',
  CLICK: 'status',
  CONVERT: 'status',
  FOLLOW_UP: 'form',
  TRACK_PROGRESS: 'progress',
  READ: 'status',
  UPDATE: 'form',
  AUDIT: 'results',
  ALERT: 'status',
  ITINERARY: 'confirmation',
};

// ─── Build theme from DNA ──────────────────────────────────────────────────

function buildTheme(dna: DNAGene): UIContract['theme'] {
  return {
    primary: dna.theme.primary,
    secondary: dna.theme.secondary,
    accent: dna.theme.accent,
    glow: dna.theme.glow,
  };
}

// ─── Build status contract (for blocked / completed states) ─────────────────

export function buildStatusContract(params: {
  dna: DNAGene;
  titleAr: string;
  title: string;
  bubbleType?: BubbleType;
  data?: Record<string, unknown>;
  workflow?: Workflow;
}): UIContract {
  return {
    version: '1.0',
    id: `ui-status-${Date.now()}`,
    primitiveType: 'status',
    title: params.title,
    titleAr: params.titleAr,
    bubbleType: params.bubbleType || params.dna.bubbleType,
    metadata: {
      dnaId: params.dna.id,
      workflowId: params.workflow?.id,
      timestamp: now(),
    },
    layout: { type: 'vertical' },
    fields: [],
    actions: [],
    data: params.data || {},
    theme: buildTheme(params.dna),
  };
}

// ─── Build blocked contract (when Islamic validation fails) ────────────────

export function buildBlockedContract(params: {
  dna: DNAGene;
  islamicCheck: IslamicValidation;
}): UIContract {
  const items = params.islamicCheck.forbiddenItems
    .filter((i) => i.severity === 'high')
    .map((i) => i.categoryAr)
    .join('، ');

  return {
    version: '1.0',
    id: `ui-blocked-${Date.now()}`,
    primitiveType: 'status',
    title: 'Blocked by Islamic Conscience',
    titleAr: 'تم الحظر من قبل الضمير الإسلامي',
    bubbleType: params.dna.bubbleType,
    metadata: {
      dnaId: params.dna.id,
      timestamp: now(),
    },
    layout: { type: 'vertical' },
    fields: [],
    actions: params.islamicCheck.alternatives.length > 0
      ? [{
          id: 'suggest_alternative',
          label: 'Suggest Alternative',
          labelAr: 'اقتراح بديل',
          type: 'primary',
          capabilityId: 'SUGGEST_ALTERNATIVE',
          payload: { alternatives: params.islamicCheck.alternatives },
        }]
      : [],
    data: {
      forbiddenItems: items,
      alternatives: params.islamicCheck.alternatives,
      fatwaReference: params.islamicCheck.fatwaReference,
    },
    theme: { primary: '#FF1744', secondary: '#F50057', accent: '#FF80AB', glow: '#FF1744' },
  };
}

// ─── Build emergency contract ──────────────────────────────────────────────

export function buildEmergencyContract(params: {
  dna: DNAGene;
  soul: HumanSoul;
  intent: IntentResult;
}): UIContract {
  return {
    version: '1.0',
    id: `ui-emergency-${Date.now()}`,
    primitiveType: 'status',
    title: 'Emergency Protocol Active',
    titleAr: '🚨 بروتوكول الطوارئ مفعّل',
    bubbleType: 'emergency',
    metadata: {
      dnaId: params.dna.id,
      capabilityId: 'ESCALATE',
      timestamp: now(),
    },
    layout: { type: 'vertical' },
    fields: [],
    actions: [
      { id: 'call_112', label: 'Call Kuwait Emergency', labelAr: 'الاتصال بالطوارئ ١١٢', type: 'danger', capabilityId: 'CALL_EMERGENCY', payload: { number: '112' } },
      { id: 'share_location', label: 'Share My Location', labelAr: 'مشاركة موقعي', type: 'primary', capabilityId: 'SHARE_LOCATION' },
      { id: 'notify_contacts', label: 'Notify Family', labelAr: 'إشعار العائلة', type: 'secondary', capabilityId: 'NOTIFY_CONTACTS' },
    ],
    data: {
      empathyResponse: params.soul.empathyResponse,
      crisisType: params.intent.bubbleType,
    },
    theme: { primary: '#FF1744', secondary: '#F50057', accent: '#FF80AB', glow: '#FF1744' },
  };
}

// ─── Build search contract (dynamic fields from entity schema) ─────────────

export function buildSearchContract(params: {
  dna: DNAGene;
  workflow: Workflow;
  intent: IntentResult;
  worldModel: WorldModel;
}): UIContract {
  const entity = params.worldModel.entities[0];
  const searchableFields = entity?.fields.filter((f) => f.searchable || f.filterable) || [];

  const fields = searchableFields.slice(0, 4).map((f) => ({
    id: `search-${f.id}`,
    name: f.name,
    label: f.label,
    labelAr: f.labelAr,
    type: f.type === 'currency' ? 'number' : f.type === 'select' ? 'select' : 'text',
    placeholder: f.type === 'currency' ? 'أدخل القيمة بالدينار' : `ابحث بـ ${f.labelAr}`,
    options: f.options,
    validation: { required: false },
  }));

  // Pre-fill from intent entities
  for (const entity of params.intent.entities) {
    const field = fields.find((f) => f.name.toLowerCase().includes(entity.key.toLowerCase()) || entity.key.toLowerCase().includes(f.name.toLowerCase()));
    if (field && field.type !== 'select') {
      field.defaultValue = entity.value;
    }
  }

  return {
    version: '1.0',
    id: `ui-search-${params.dna.id}-${Date.now()}`,
    primitiveType: 'search',
    title: `Search ${entity?.name || 'Items'}`,
    titleAr: `بحث ${entity?.nameAr || 'عناصر'}`,
    bubbleType: params.dna.bubbleType,
    metadata: {
      dnaId: params.dna.id,
      workflowId: params.workflow.id,
      stepIndex: 0,
      capabilityId: 'SEARCH',
      timestamp: now(),
    },
    layout: { type: 'vertical' },
    fields,
    actions: [
      { id: 'search', label: 'Search', labelAr: 'بحث', type: 'primary', capabilityId: 'SEARCH', icon: 'search' },
      { id: 'compare', label: 'Compare Top Results', labelAr: 'قارن أفضل النتائج', type: 'secondary', capabilityId: 'COMPARE' },
    ],
    data: { entityType: entity?.type, intentText: params.intent.originalText },
    theme: buildTheme(params.dna),
  };
}

// ─── Build results contract ────────────────────────────────────────────────

export function buildResultsContract(params: {
  dna: DNAGene;
  workflow: Workflow;
  intent: IntentResult;
  results: MockItem[];
  entityType?: string;
}): UIContract {
  const items = params.results;
  return {
    version: '1.0',
    id: `ui-results-${Date.now()}`,
    primitiveType: 'results',
    title: `Found ${items.length} Results`,
    titleAr: `تم العثور على ${items.length} نتيجة`,
    bubbleType: params.dna.bubbleType,
    metadata: {
      dnaId: params.dna.id,
      workflowId: params.workflow.id,
      stepIndex: 1,
      capabilityId: 'SEARCH',
      timestamp: now(),
    },
    layout: { type: 'vertical' },
    fields: [],
    actions: [
      { id: 'refine', label: 'Refine Filters', labelAr: 'تحسين الفلاتر', type: 'secondary', capabilityId: 'FILTER' },
      { id: 'compare_top', label: 'Compare Top 3', labelAr: 'قارن أفضل ٣', type: 'primary', capabilityId: 'COMPARE' },
    ],
    data: { items, entityType: params.entityType, count: items.length },
    theme: buildTheme(params.dna),
  };
}

// ─── Build comparison contract ─────────────────────────────────────────────

export function buildComparisonContract(params: {
  dna: DNAGene;
  workflow: Workflow;
  items: MockItem[];
}): UIContract {
  return {
    version: '1.0',
    id: `ui-compare-${Date.now()}`,
    primitiveType: 'comparison',
    title: 'Comparison',
    titleAr: 'المقارنة',
    bubbleType: params.dna.bubbleType,
    metadata: {
      dnaId: params.dna.id,
      workflowId: params.workflow.id,
      capabilityId: 'COMPARE',
      timestamp: now(),
    },
    layout: { type: 'grid', columns: params.items.length },
    fields: [],
    actions: [
      { id: 'select_best', label: 'Select Best Match', labelAr: 'اختر الأفضل', type: 'primary', capabilityId: 'MATCH' },
      { id: 'negotiate', label: 'Negotiate Price', labelAr: 'فاوض السعر', type: 'secondary', capabilityId: 'NEGOTIATE' },
    ],
    data: { items: params.items },
    theme: buildTheme(params.dna),
  };
}

// ─── Build negotiation contract ────────────────────────────────────────────

export function buildNegotiationContract(params: {
  dna: DNAGene;
  workflow: Workflow;
  originalPrice: number;
  proposedPrice: number;
  discountPercent: number;
  sellerLikelyToAccept: boolean;
  item?: MockItem;
}): UIContract {
  return {
    version: '1.0',
    id: `ui-negotiate-${Date.now()}`,
    primitiveType: 'negotiation',
    title: 'Negotiation Room',
    titleAr: 'غرفة التفاوض',
    bubbleType: 'negotiation',
    metadata: {
      dnaId: params.dna.id,
      workflowId: params.workflow.id,
      capabilityId: 'NEGOTIATE',
      timestamp: now(),
    },
    layout: { type: 'vertical' },
    fields: [
      { id: 'offer_price', name: 'offer_price', label: 'Your Offer', labelAr: 'عرضك', type: 'number', defaultValue: params.proposedPrice, validation: { required: true, min: 0 } },
      { id: 'note_to_seller', name: 'note', label: 'Note to Seller', labelAr: 'ملاحظة للبائع', type: 'text', placeholder: 'اكتب رسالتك للبائع' },
    ],
    actions: [
      { id: 'accept', label: `Accept (${params.proposedPrice} KWD)`, labelAr: `قبول (${params.proposedPrice} د.ك)`, type: 'success', capabilityId: 'ACCEPT', confirmation: 'هل أنت متأكد من قبول هذا العرض؟' },
      { id: 'counter', label: 'Counter Offer', labelAr: 'عرض مضاد', type: 'primary', capabilityId: 'COUNTER' },
      { id: 'reject', label: 'Reject', labelAr: 'رفض', type: 'danger', capabilityId: 'REJECT' },
    ],
    data: {
      originalPrice: params.originalPrice,
      proposedPrice: params.proposedPrice,
      discountPercent: params.discountPercent,
      sellerLikelyToAccept: params.sellerLikelyToAccept,
      item: params.item,
    },
    theme: { primary: '#FFD740', secondary: '#FF6D00', accent: '#FFE57F', glow: '#FFD740' },
  };
}

// ─── Build payment contract ─────────────────────────────────────────────────

export function buildPaymentContract(params: {
  dna: DNAGene;
  workflow: Workflow;
  amount: number;
  currency?: string;
  itemDescription?: string;
}): UIContract {
  const currency = params.currency || 'KWD';
  return {
    version: '1.0',
    id: `ui-payment-${Date.now()}`,
    primitiveType: 'payment',
    title: 'Payment Required',
    titleAr: 'مطلوب دفع',
    bubbleType: 'payment',
    metadata: {
      dnaId: params.dna.id,
      workflowId: params.workflow.id,
      capabilityId: 'PAY',
      timestamp: now(),
    },
    layout: { type: 'vertical' },
    fields: [
      { id: 'payment_method', name: 'payment_method', label: 'Payment Method', labelAr: 'طريقة الدفع', type: 'select', options: [
        { value: 'knet', label: 'KNET', labelAr: 'كي نت' },
        { value: 'visa', label: 'Visa/MasterCard', labelAr: 'فيزا/ماستركارد' },
        { value: 'wallet', label: 'Jasim Wallet', labelAr: 'محفظة جاسم' },
        { value: 'apple_pay', label: 'Apple Pay', labelAr: 'أبل باي' },
      ], validation: { required: true } },
      { id: 'card_number', name: 'card_number', label: 'Card Number', labelAr: 'رقم البطاقة', type: 'text', placeholder: '0000 0000 0000 0000', validation: { required: true, pattern: '^[0-9 ]{16,19}$' } },
      { id: 'cvv', name: 'cvv', label: 'CVV', labelAr: 'التحقق', type: 'text', placeholder: '•••', validation: { required: true, pattern: '^[0-9]{3,4}$' } },
    ],
    actions: [
      { id: 'pay', label: `Pay ${params.amount} ${currency}`, labelAr: `ادفع ${params.amount} ${currency === 'KWD' ? 'د.ك' : currency}`, type: 'primary', capabilityId: 'PAY', confirmation: 'هل أنت متأكد من إتمام الدفع؟ سيتم استخدام الضمان لحماية المعاملة.' },
      { id: 'cancel', label: 'Cancel', labelAr: 'إلغاء', type: 'ghost', capabilityId: 'CANCEL' },
    ],
    data: {
      amount: params.amount,
      currency,
      itemDescription: params.itemDescription,
      escrowEnabled: true,
    },
    theme: { primary: '#00897B', secondary: '#26A69A', accent: '#80CBC4', glow: '#00897B' },
  };
}

// ─── Build confirmation contract ────────────────────────────────────────────

export function buildConfirmationContract(params: {
  dna: DNAGene;
  workflow: Workflow;
  titleAr: string;
  title: string;
  details: Record<string, unknown>;
  nextCapability?: string;
}): UIContract {
  return {
    version: '1.0',
    id: `ui-confirm-${Date.now()}`,
    primitiveType: 'confirmation',
    title: params.title,
    titleAr: params.titleAr,
    bubbleType: params.dna.bubbleType,
    metadata: {
      dnaId: params.dna.id,
      workflowId: params.workflow.id,
      capabilityId: params.nextCapability || 'CONFIRM',
      timestamp: now(),
    },
    layout: { type: 'vertical' },
    fields: [],
    actions: [
      { id: 'confirm', label: 'Confirm', labelAr: 'تأكيد', type: 'primary', capabilityId: params.nextCapability || 'CONFIRM' },
      { id: 'cancel', label: 'Cancel', labelAr: 'إلغاء', type: 'ghost', capabilityId: 'CANCEL' },
    ],
    data: params.details,
    theme: buildTheme(params.dna),
  };
}

// ─── Build progress contract ────────────────────────────────────────────────

export function buildProgressContract(params: {
  dna: DNAGene;
  workflow: Workflow;
  titleAr: string;
  steps: Array<{ label: string; labelAr: string; status: 'done' | 'current' | 'pending' }>;
  eta?: string;
}): UIContract {
  return {
    version: '1.0',
    id: `ui-progress-${Date.now()}`,
    primitiveType: 'progress',
    title: 'In Progress',
    titleAr: params.titleAr,
    bubbleType: params.dna.bubbleType,
    metadata: {
      dnaId: params.dna.id,
      workflowId: params.workflow.id,
      capabilityId: 'TRACK',
      timestamp: now(),
    },
    layout: { type: 'vertical' },
    fields: [],
    actions: [
      { id: 'notify', label: 'Notify me on arrival', labelAr: 'أشعرني عند الوصول', type: 'secondary', capabilityId: 'NOTIFY' },
    ],
    data: { steps: params.steps, eta: params.eta },
    theme: buildTheme(params.dna),
  };
}

// ─── Build form contract (for create_listing, booking, etc.) ───────────────

export function buildFormContract(params: {
  dna: DNAGene;
  workflow: Workflow;
  intent: IntentResult;
  worldModel: WorldModel;
  capabilityId: string;
}): UIContract {
  const entity = params.worldModel.entities[0];
  const requiredFields = entity?.fields.filter((f) => f.required || f.filterable).slice(0, 5) || [];

  const fields = requiredFields.map((f) => ({
    id: `form-${f.id}`,
    name: f.name,
    label: f.label,
    labelAr: f.labelAr,
    type: f.type === 'currency' ? 'number' : f.type === 'image' ? 'text' : f.type,
    placeholder: `أدخل ${f.labelAr}`,
    options: f.options,
    validation: { required: f.required },
  }));

  return {
    version: '1.0',
    id: `ui-form-${Date.now()}`,
    primitiveType: 'form',
    title: 'Fill Required Information',
    titleAr: 'املأ المعلومات المطلوبة',
    bubbleType: params.dna.bubbleType,
    metadata: {
      dnaId: params.dna.id,
      workflowId: params.workflow.id,
      capabilityId: params.capabilityId,
      timestamp: now(),
    },
    layout: { type: 'vertical' },
    fields,
    actions: [
      { id: 'submit', label: 'Submit', labelAr: 'إرسال', type: 'primary', capabilityId: params.capabilityId },
      { id: 'cancel', label: 'Cancel', labelAr: 'إلغاء', type: 'ghost', capabilityId: 'CANCEL' },
    ],
    data: { entityType: entity?.type, formMode: params.capabilityId },
    theme: buildTheme(params.dna),
  };
}

// ─── Build dashboard contract ──────────────────────────────────────────────

export function buildDashboardContract(params: {
  dna: DNAGene;
  workflow: Workflow;
  metrics: Array<{ label: string; labelAr: string; value: string | number; trend?: 'up' | 'down' | 'stable' }>;
}): UIContract {
  return {
    version: '1.0',
    id: `ui-dashboard-${Date.now()}`,
    primitiveType: 'dashboard',
    title: 'Dashboard',
    titleAr: 'لوحة التحكم',
    bubbleType: params.dna.bubbleType,
    metadata: {
      dnaId: params.dna.id,
      workflowId: params.workflow.id,
      capabilityId: 'QUERY',
      timestamp: now(),
    },
    layout: { type: 'grid', columns: 3 },
    fields: [],
    actions: [
      { id: 'export', label: 'Export Report', labelAr: 'تصدير التقرير', type: 'secondary', capabilityId: 'EXPORT' },
    ],
    data: { metrics: params.metrics },
    theme: buildTheme(params.dna),
  };
}

// ─── Build chat contract (default fallback) ──────────────────────────────────

export function buildChatContract(params: {
  dna: DNAGene;
  soul: HumanSoul;
  intent: IntentResult;
  text: string;
}): UIContract {
  return {
    version: '1.0',
    id: `ui-chat-${Date.now()}`,
    primitiveType: 'chat',
    title: 'Jasim Assistant',
    titleAr: 'مساعد جاسم',
    bubbleType: params.dna.bubbleType,
    metadata: {
      dnaId: params.dna.id,
      timestamp: now(),
    },
    layout: { type: 'vertical' },
    fields: [],
    actions: [],
    data: {
      text: params.text,
      tone: params.soul.voiceTone,
      emotion: params.soul.emotionalState,
    },
    theme: buildTheme(params.dna),
  };
}

// ─── Build workflow progress contract (shows DAG state) ─────────────────────

export function buildWorkflowProgressContract(params: {
  dna: DNAGene;
  workflow: Workflow;
}): UIContract {
  return {
    version: '1.0',
    id: `ui-wf-${Date.now()}`,
    primitiveType: 'progress',
    title: 'Workflow Progress',
    titleAr: 'تقدم سير العمل',
    bubbleType: params.dna.bubbleType,
    metadata: {
      dnaId: params.dna.id,
      workflowId: params.workflow.id,
      capabilityId: 'WORKFLOW_STATUS',
      timestamp: now(),
    },
    layout: { type: 'vertical' },
    fields: [],
    actions: [],
    data: {
      steps: params.workflow.steps.map((s) => ({
        id: s.id,
        capability: s.capability,
        labelAr: s.labelAr,
        labelEn: s.labelEn,
        status: s.status,
        attempts: s.attempts,
        requiresHumanGate: s.requiresHumanGate,
      })),
      currentStepIndex: params.workflow.currentStepIndex,
      totalSteps: params.workflow.steps.length,
      overallStatus: params.workflow.status,
    },
    theme: buildTheme(params.dna),
  };
}

// ─── Get current step contract for a workflow ──────────────────────────────

export function getContractForCurrentStep(params: {
  dna: DNAGene;
  workflow: Workflow;
  intent: IntentResult;
  worldModel: WorldModel;
  stepResults: Record<string, unknown>;
}): UIContract {
  const { workflow } = params;

  // The "current step" for UI purposes is the LAST executed/completed step,
  // not the next pending one. If the workflow has executed step N, currentStepIndex
  // is N+1 (pointing to the next), but we want to show step N's output.
  let targetIdx = workflow.currentStepIndex - 1;
  if (targetIdx < 0) targetIdx = 0;
  if (targetIdx >= workflow.steps.length) targetIdx = workflow.steps.length - 1;

  const currentStep = workflow.steps[targetIdx];

  if (!currentStep) {
    return buildStatusContract({
      dna: params.dna,
      title: 'Completed',
      titleAr: 'تم إكمال المهمة بنجاح',
      workflow,
    });
  }

  const cap = currentStep.capability;
  const capLower = cap.toLowerCase();
  const results = params.stepResults;

  // ─── SEARCH / FILTER → results contract ─────────────────────────────────
  if (capLower === 'search' || capLower === 'search_flights' || capLower === 'filter' || capLower === 'search_drivers') {
    const data = results[cap] as { results?: MockItem[]; filtered?: MockItem[] } | undefined;
    const items = data?.results || data?.filtered || [];
    if (items.length > 0) {
      return buildResultsContract({
        dna: params.dna,
        workflow,
        intent: params.intent,
        results: items,
        entityType: params.worldModel.entities[0]?.type,
      });
    }
    return buildSearchContract({ dna: params.dna, workflow, intent: params.intent, worldModel: params.worldModel });
  }

  // ─── COMPARE → comparison contract ─────────────────────────────────────
  if (capLower === 'compare') {
    const data = results[cap] as { comparisonItems?: MockItem[] } | undefined;
    return buildComparisonContract({
      dna: params.dna,
      workflow,
      items: data?.comparisonItems || [],
    });
  }

  // ─── MATCH / MATCH_CANDIDATES → results (best match) ───────────────────
  if (capLower === 'match' || capLower === 'match_candidates') {
    const data = results[cap] as { bestMatch?: MockItem; candidates?: MockItem[] } | undefined;
    if (data?.bestMatch) {
      return buildResultsContract({
        dna: params.dna,
        workflow,
        intent: params.intent,
        results: [data.bestMatch],
        entityType: params.worldModel.entities[0]?.type,
      });
    }
    if (data?.candidates && data.candidates.length > 0) {
      return buildResultsContract({
        dna: params.dna,
        workflow,
        intent: params.intent,
        results: data.candidates,
        entityType: 'job',
      });
    }
    return buildStatusContract({
      dna: params.dna,
      title: 'Best Match',
      titleAr: 'أفضل مطابقة',
      workflow,
      data: { bestMatch: data?.bestMatch, candidates: data?.candidates },
    });
  }

  // ─── NEGOTIATE / PROPOSE → negotiation contract ──────────────────────
  if (capLower === 'negotiate' || capLower === 'propose_offer') {
    const data = results[cap] as any;
    if (data) {
      return buildNegotiationContract({
        dna: params.dna,
        workflow,
        originalPrice: data.originalPrice || 0,
        proposedPrice: data.proposedPrice || 0,
        discountPercent: data.discountPercent || 0,
        sellerLikelyToAccept: data.sellerLikelyToAccept ?? true,
      });
    }
    return buildFormContract({ dna: params.dna, workflow, intent: params.intent, worldModel: params.worldModel, capabilityId: cap });
  }

  // ─── PAYMENT / AUTHORIZE / CAPTURE → payment contract ──────────────────
  if (capLower === 'payment_intent' || capLower === 'payment_authorize' || capLower === 'payment_capture' || capLower === 'pay') {
    const data = results[cap] as any;
    const matchData = results['match'] as { bestMatch?: MockItem } | undefined;
    const amount = data?.amount || matchData?.bestMatch?.price || parseFloat(params.intent.entities.find((e) => e.key === 'budget')?.value || '0');
    return buildPaymentContract({
      dna: params.dna,
      workflow,
      amount,
      itemDescription: matchData?.bestMatch?.title || 'Item',
    });
  }

  // ─── ESCROW_HOLD → confirmation contract ───────────────────────────────
  if (capLower === 'escrow_hold' || capLower === 'escrow_dispute') {
    const data = results[cap] as any;
    return buildConfirmationContract({
      dna: params.dna,
      workflow,
      title: 'Escrow Active',
      titleAr: 'الضمان مفعّل',
      details: data || { escrowId: `esc-${Date.now()}`, status: 'holding' },
      nextCapability: 'escrow_release',
    });
  }

  // ─── TRACK / DELIVER / ETA → progress contract ─────────────────────────
  if (capLower === 'track' || capLower === 'track_delivery' || capLower === 'calculate_eta' || capLower === 'deliver') {
    const data = results[cap] as any;
    return buildProgressContract({
      dna: params.dna,
      workflow,
      titleAr: 'جاري التوصيل',
      steps: data?.steps || [
        { label: 'Order placed', labelAr: 'تم الطلب', status: 'done' },
        { label: 'Preparing', labelAr: 'جاري التحضير', status: 'done' },
        { label: 'Out for delivery', labelAr: 'في الطريق', status: 'current' },
        { label: 'Delivered', labelAr: 'تم التوصيل', status: 'pending' },
      ],
      eta: data?.eta,
    });
  }

  // ─── VERIFY → confirmation contract ────────────────────────────────────
  if (capLower === 'verify_identity' || capLower === 'verify_phone' || capLower === 'trust_score') {
    return buildConfirmationContract({
      dna: params.dna,
      workflow,
      title: 'Verification Complete',
      titleAr: 'تم التحقق',
      details: results[cap] || { verified: true },
      nextCapability: 'proceed',
    });
  }

  // ─── CREATE_LISTING → form contract ────────────────────────────────────
  if (capLower === 'create_listing' || capLower === 'update_listing' || capLower === 'delete_listing') {
    const data = results[cap] as any;
    if (data?.listingId) {
      return buildStatusContract({
        dna: params.dna,
        title: 'Listing Created',
        titleAr: '✅ تم إنشاء الإدراج بنجاح',
        workflow,
        data: { listingId: data.listingId, title: data.title, status: data.status },
      });
    }
    return buildFormContract({ dna: params.dna, workflow, intent: params.intent, worldModel: params.worldModel, capabilityId: cap });
  }

  // ─── BOOK / SCHEDULE → form then confirmation ──────────────────────────
  if (capLower === 'book_appointment' || capLower === 'schedule_interview' || capLower === 'cancel_appointment') {
    const data = results[cap] as any;
    if (data?.bookingId) {
      return buildConfirmationContract({
        dna: params.dna,
        workflow,
        title: 'Booking Confirmed',
        titleAr: '✅ تم تأكيد الحجز',
        details: data,
        nextCapability: 'notify',
      });
    }
    return buildFormContract({ dna: params.dna, workflow, intent: params.intent, worldModel: params.worldModel, capabilityId: cap });
  }

  // ─── ANALYTICS → dashboard contract ────────────────────────────────────
  if (capLower === 'query_analytics' || capLower === 'aggregate_data' || capLower === 'insight_generation' || capLower === 'aggregate') {
    const data = results[cap] as { metrics?: any[] } | undefined;
    return buildDashboardContract({
      dna: params.dna,
      workflow,
      metrics: data?.metrics || [
        { label: 'Total Listings', labelAr: 'إجمالي الإدراجات', value: 0, trend: 'up' },
        { label: 'Active Listings', labelAr: 'الإدراجات النشطة', value: 0, trend: 'up' },
        { label: 'Total Transactions', labelAr: 'إجمالي المعاملات', value: 0, trend: 'stable' },
        { label: 'Total Users', labelAr: 'إجمالي المستخدمين', value: 0, trend: 'up' },
      ],
    });
  }

  // ─── WALLET → dashboard contract ────────────────────────────────────────
  if (capLower === 'wallet_balance' || capLower === 'wallet_history') {
    const data = results[cap] as any;
    return buildDashboardContract({
      dna: params.dna,
      workflow,
      metrics: [
        { label: 'Balance', labelAr: 'الرصيد', value: `${data?.balance || 0} د.ك`, trend: 'stable' },
      ],
    });
  }

  // ─── NOTIFY → status contract ──────────────────────────────────────────
  if (capLower.startsWith('notify')) {
    const data = results[cap] as any;
    return buildStatusContract({
      dna: params.dna,
      title: 'Notification Sent',
      titleAr: '✅ تم إرسال الإشعار',
      workflow,
      data: data || { delivered: true },
    });
  }

  // ─── DEFAULT → status contract ──────────────────────────────────────────
  return buildStatusContract({
    dna: params.dna,
    title: currentStep.labelEn,
    titleAr: `تنفيذ: ${currentStep.labelAr}`,
    workflow,
    data: results[cap] || { note: `Capability ${cap} executed` },
  });
}

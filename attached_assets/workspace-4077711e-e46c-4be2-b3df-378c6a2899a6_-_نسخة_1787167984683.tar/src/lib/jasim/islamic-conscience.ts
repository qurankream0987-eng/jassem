// ============================================================================
// 🕌 JASIM — Islamic Conscience Engine
// Validates user intent against Islamic principles (Sharia compliance)
// Provides alternatives instead of just blocking
// ============================================================================

import type { IslamicValidation } from './types';

interface ForbiddenPattern {
  regex: RegExp;
  category: string;
  categoryAr: string;
  alternative: string;
  severity: 'high' | 'medium' | 'low';
  fatwaRef?: string;
}

// ─── Forbidden Categories (Haram) ──────────────────────────────────────────

const FORBIDDEN_PATTERNS: ForbiddenPattern[] = [
  // Khamr (Alcohol) — Strictly forbidden
  {
    regex: /(?:^|\s|،|,|\.|!)خمر(?:\s|$|،|,|\.|!|$)|كحول|بيرة|نبيذ|فودكا|ويسكي|جين|عرق|ميسلو|alcohol|wine|beer|vodka|whiskey|rum|gin|liquor|spirits/i,
    category: 'alcohol',
    categoryAr: 'المسكرات والكحول',
    alternative: 'عصائر طبيعية، مشروبات غازية حلال، قهوة، شاي',
    severity: 'high',
    fatwaRef: 'البقرة: ٢١٩ — يسألونك عن الخمر والميسر قل فيهما إثم كبير',
  },
  // Tobacco / Smoking (Makrouh to Haram depending on school)
  {
    regex: /تبغ|سجاير|سيجارة|شيشة|تدخين|نيكوتين|cigarette|cigar|shisha|hookah|tobacco|vape|nicotine/i,
    category: 'tobacco',
    categoryAr: 'التبغ والتدخين',
    alternative: 'منتجات صحية، مسواك، علكة نعناع، بدائل طبيعية',
    severity: 'medium',
    fatfaRef: 'الضرر يجب أن يُزال — قاعدة شرعية',
  },
  // Gambling (Maysir) — Strictly forbidden
  {
    regex: /قمار|رهان|كازينو|لوتري|يانصيب|بطاقات\s+لعب|bet|gambling|casino|lottery|raffle/i,
    category: 'gambling',
    categoryAr: 'القمار والميسر',
    alternative: 'استثمار شرعي، صناديق وقف، تمويل إسلامي، تجارة مباحة',
    severity: 'high',
    fatwaRef: 'المائدة: ٩٠ — يا أيها الذين آمنوا إنما الخمر والميسر... رجس من عمل الشيطان',
  },
  // Riba (Usury / Interest) — Strictly forbidden
  {
    regex: /(?:^|\s|،|,|\.|!)ربا(?:\s|$|،|,|\.|!|$)|فوائد\s+بنكية|قروض\s+ربوية|interest\s+rate|usury|loan\s+shark/i,
    category: 'riba',
    categoryAr: 'الربا والفوائد',
    alternative: 'تمويل إسلامي، مرابحة، مضاربة، صناديق صكوك، قروض حسنة',
    severity: 'high',
    fatwaRef: 'البقرة: ٢٧٥ — أحل الله البيع وحرم الربا',
  },
  // Pork / Pork products
  {
    regex: /خنزير|لحم\s+خنزير|حلال\s+بيكون|pork|bacon|ham|lard/i,
    category: 'pork',
    categoryAr: 'لحم الخنزير',
    alternative: 'لحم بقري حلال، دجاج حلال، لحم غنم، بدائل نباتية',
    severity: 'high',
    fatwaRef: 'البقرة: ١٧٣ — حرمت عليكم الميتة والدم ولحم الخنزير',
  },
  // Adult / Inappropriate content
  {
    regex: /إباحي|خلاعة|adult\s+content|porn|escort|nsfw/i,
    category: 'adult',
    categoryAr: 'محتوى للبالغين',
    alternative: 'محتوى تعليمي، ترفيه عائلي، رياضة، ثقافة',
    severity: 'high',
  },
  // Idols / Statues for worship
  {
    regex: /تماثيل\s+للعبادة|أصنام|idols?\s+for\s+worship/i,
    category: 'idols',
    categoryAr: 'التماثيل للعبادة',
    alternative: 'فن إسلامي، خط، زخرفة هندسية، فنون تطبيقية',
    severity: 'medium',
  },
  // Fortunetelling / Magic
  {
    regex: /كهانة|سحر|دجل|عرافة|horoscope|astrology|fortune\s+telling|psychic|sorcery/i,
    category: 'sorcery',
    categoryAr: 'السحر والكهانة',
    alternative: 'استشارة شرعية، علم النفس، تطوير الذات',
    severity: 'high',
    fatwaRef: 'البقرة: ١٠٢ — وما يعلمان من أحد حتى يقولا إنما نحن فتنة فلا تكفر',
  },
];

// ─── Warnings (Makrouh — discouraged but not haram) ────────────────────────

const WARNING_PATTERNS: Array<{ regex: RegExp; warning: string }> = [
  {
    regex: /تخفيضات?\s+ضخمة|خصم\s+٩٠|سبت|black\s+friday/i,
    warning: 'الإسراف والتبذير منهي عنه حتى في حالات التخفيض',
  },
  {
    regex: /شراء\s+بالدَّين|تقسيط\s+طويل|buy\s+now\s+pay\s+later/i,
    warning: 'تأكد من خلو التقسيط من الفوائد الربوية',
  },
];

// ─── Main Validation Function ─────────────────────────────────────────────

export function validateIslamicConscience(text: string): IslamicValidation {
  const forbiddenItems: IslamicValidation['forbiddenItems'] = [];
  const alternatives: string[] = [];
  const warnings: string[] = [];
  let fatwaReference: string | undefined;

  for (const pattern of FORBIDDEN_PATTERNS) {
    const match = text.match(pattern.regex);
    if (match) {
      forbiddenItems.push({
        category: pattern.category,
        matchedText: match[0],
        severity: pattern.severity,
      });
      if (!alternatives.includes(pattern.alternative)) {
        alternatives.push(pattern.alternative);
      }
      if (pattern.fatwaRef && !fatwaReference) {
        fatwaReference = pattern.fatwaRef;
      }
    }
  }

  for (const { regex, warning } of WARNING_PATTERNS) {
    if (regex.test(text) && !warnings.includes(warning)) {
      warnings.push(warning);
    }
  }

  const isCompliant = forbiddenItems.filter((i) => i.severity === 'high').length === 0;

  return {
    isCompliant,
    forbiddenItems,
    alternatives,
    warnings,
    fatwaReference,
  };
}

// ─── Get blocked UI message ─────────────────────────────────────────────────

export function getBlockedMessageArabic(validation: IslamicValidation): string {
  const items = validation.forbiddenItems
    .filter((i) => i.severity === 'high')
    .map((i) => i.categoryAr)
    .join('، ');

  const alternativesText = validation.alternatives.length > 0
    ? `\n\n💡 البدائل المباحة: ${validation.alternatives.join(' • ')}`
    : '';

  const fatwaText = validation.fatwaReference
    ? `\n\n📜 الدليل الشرعي: ${validation.fatwaReference}`
    : '';

  return `🚫 نعتذر، هذا الطلب يتعلق بـ ${items} وهو غير متوافق مع المبادئ الإسلامية.${alternativesText}${fatwaText}`;
}

// ============================================================================
// ⚙️ JASIM — Task Runtime
// Plan → Compile → Execute → Observe → Verify → Repair → Replan
// Heart of the Generative Operating System
// ============================================================================

import type { Workflow, TaskStep, DNAGene, IntentResult, WorldModel } from './types';
import { searchItems, type MockItem, type SearchFilters } from './mock-data';

// ─── Capability Label Map ──────────────────────────────────────────────────

const CAPABILITY_LABELS: Record<string, { ar: string; en: string }> = {
  SEARCH: { ar: 'بحث', en: 'Search' },
  FILTER: { ar: 'تصفية', en: 'Filter' },
  COMPARE: { ar: 'مقارنة', en: 'Compare' },
  MATCH: { ar: 'مطابقة', en: 'Match' },
  NEGOTIATE: { ar: 'تفاوض', en: 'Negotiate' },
  PAY: { ar: 'دفع', en: 'Pay' },
  ESCROW: { ar: 'ضمان', en: 'Escrow' },
  CREATE_LISTING: { ar: 'إنشاء إدراج', en: 'Create Listing' },
  ORDER: { ar: 'طلب', en: 'Order' },
  BOOK: { ar: 'حجز', en: 'Book' },
  MENU: { ar: 'عرض القائمة', en: 'View Menu' },
  REVIEW: { ar: 'مراجعة', en: 'Review' },
  TRACK: { ar: 'تتبع', en: 'Track' },
  NOTIFY: { ar: 'إشعار', en: 'Notify' },
  ETA: { ar: 'وقت الوصول', en: 'ETA' },
  CONFIRM: { ar: 'تأكيد', en: 'Confirm' },
  RATE: { ar: 'تقييم', en: 'Rate' },
  LOCATE: { ar: 'تحديد الموقع', en: 'Locate' },
  DISPATCH: { ar: 'إرسال', en: 'Dispatch' },
  ESCALATE: { ar: 'تصعيد', en: 'Escalate' },
  LOG: { ar: 'تسجيل', en: 'Log' },
  MATCH_CANDIDATES: { ar: 'مطابقة المرشحين', en: 'Match Candidates' },
  SHORTLIST: { ar: 'قائمة مختصرة', en: 'Shortlist' },
  INTERVIEW: { ar: 'مقابلة', en: 'Interview' },
  CONTRACT: { ar: 'عقد', en: 'Contract' },
  VERIFY: { ar: 'تحقق', en: 'Verify' },
  VERIFY_PRESCRIPTION: { ar: 'التحقق من الوصفة', en: 'Verify Prescription' },
  DELIVER: { ar: 'توصيل', en: 'Deliver' },
  AUTHORIZE: { ar: 'تفويض', en: 'Authorize' },
  CAPTURE: { ar: 'حجز المبلغ', en: 'Capture' },
  RECONCILE: { ar: 'تسوية', en: 'Reconcile' },
  REFUND: { ar: 'استرداد', en: 'Refund' },
  BALANCE: { ar: 'الرصيد', en: 'Balance' },
  TRANSFER: { ar: 'تحويل', en: 'Transfer' },
  TOPUP: { ar: 'شحن', en: 'Top Up' },
  WITHDRAW: { ar: 'سحب', en: 'Withdraw' },
  HISTORY: { ar: 'السجل', en: 'History' },
  QUERY: { ar: 'استعلام', en: 'Query' },
  AGGREGATE: { ar: 'تجميع', en: 'Aggregate' },
  VISUALIZE: { ar: 'عرض', en: 'Visualize' },
  EXPORT: { ar: 'تصدير', en: 'Export' },
  INSIGHT: { ar: 'استنتاج', en: 'Insight' },
  CREATE_CAMPAIGN: { ar: 'إنشاء حملة', en: 'Create Campaign' },
  TARGET: { ar: 'استهداف', en: 'Target' },
  BID: { ar: 'مزايدة', en: 'Bid' },
  OPTIMIZE: { ar: 'تحسين', en: 'Optimize' },
  DESIGN_WORLD: { ar: 'تصميم العالم', en: 'Design World' },
  CREATE_ENTITIES: { ar: 'إنشاء الكيانات', en: 'Create Entities' },
  DEFINE_POLICIES: { ar: 'تعريف السياسات', en: 'Define Policies' },
  DEPLOY: { ar: 'نشر', en: 'Deploy' },
  MONITOR: { ar: 'مراقبة', en: 'Monitor' },
  PROPOSE: { ar: 'اقتراح', en: 'Propose' },
  COUNTER: { ar: 'مقاطعة', en: 'Counter' },
  ACCEPT: { ar: 'قبول', en: 'Accept' },
  REJECT: { ar: 'رفض', en: 'Reject' },
  BASKET: { ar: 'سلة', en: 'Basket' },
  SCHEDULE_DELIVERY: { ar: 'جدولة التوصيل', en: 'Schedule Delivery' },
  CHAT: { ar: 'محادثة', en: 'Chat' },
  RECOMMEND: { ar: 'توصية', en: 'Recommend' },
  RANK: { ar: 'ترتيب', en: 'Rank' },
  DISPLAY: { ar: 'عرض', en: 'Display' },
  CLICK: { ar: 'نقر', en: 'Click' },
  CONVERT: { ar: 'تحويل', en: 'Convert' },
  APPLY: { ar: 'تقديم', en: 'Apply' },
  ENROLL: { ar: 'تسجيل', en: 'Enroll' },
  FOLLOW_UP: { ar: 'متابعة', en: 'Follow Up' },
  SEARCH_FLIGHT: { ar: 'البحث عن رحلة', en: 'Search Flight' },
  ITINERARY: { ar: 'خطة الرحلة', en: 'Itinerary' },
  BOOK_APPOINTMENT: { ar: 'حجز موعد', en: 'Book Appointment' },
  CONSULT: { ar: 'استشارة', en: 'Consult' },
  TRACK_PROGRESS: { ar: 'تتبع التقدم', en: 'Track Progress' },
  READ: { ar: 'قراءة', en: 'Read' },
  UPDATE: { ar: 'تحديث', en: 'Update' },
  AUDIT: { ar: 'تدقيق', en: 'Audit' },
  ALERT: { ar: 'تنبيه', en: 'Alert' },
};

// ─── Plan: DNA.capabilities → Workflow.steps ───────────────────────────────

export function compilePlan(dna: DNAGene): Workflow {
  const steps: TaskStep[] = dna.capabilities.map((cap, i) => {
    const label = CAPABILITY_LABELS[cap] || { ar: cap, en: cap };
    return {
      id: `step-${i}-${cap.toLowerCase()}`,
      capability: cap,
      labelAr: label.ar,
      labelEn: label.en,
      status: i === 0 ? 'running' : 'pending',
      attempts: 0,
      requiresHumanGate: cap === 'PAY' || cap === 'CONTRACT' || cap === 'ESCROW' || cap === 'DEPLOY',
    };
  });

  return {
    id: `wf-${Date.now()}`,
    dnaId: dna.id,
    steps,
    currentStepIndex: 0,
    status: 'executing',
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
}

// ─── Execute a Capability (with real side effects via mock data) ────────────

interface ExecutionContext {
  intent: IntentResult;
  worldModel: WorldModel;
  dna: DNAGene;
  formData?: Record<string, unknown>;
  priorResults: Record<string, unknown>;
}

export interface ExecutionResult {
  success: boolean;
  data?: unknown;
  error?: string;
  requiresHumanGate?: boolean;
}

export function executeCapability(capability: string, ctx: ExecutionContext): ExecutionResult {
  // Pick dataset based on bubble type
  let datasetType: 'car' | 'product' | 'job' | 'food' | 'realestate' = 'product';
  if (ctx.intent.bubbleType === 'real_estate') datasetType = 'realestate';
  else if (ctx.intent.bubbleType === 'job' || ctx.intent.bubbleType === 'recruitment') datasetType = 'job';
  else if (ctx.intent.bubbleType === 'food' || ctx.intent.bubbleType === 'restaurant') datasetType = 'food';
  else if (ctx.intent.entities.some((e) => e.key === 'carBrand')) datasetType = 'car';

  switch (capability) {
    case 'SEARCH':
    case 'SEARCH_FLIGHT': {
      const filters: SearchFilters = {};
      const budgetEntity = ctx.intent.entities.find((e) => e.key === 'budget');
      if (budgetEntity) filters.maxPrice = parseFloat(budgetEntity.value);
      const brandEntity = ctx.intent.entities.find((e) => e.key === 'carBrand' || e.key === 'brand');
      if (brandEntity) filters.brand = brandEntity.value;
      const yearEntity = ctx.intent.entities.find((e) => e.key === 'year');
      if (yearEntity) filters.yearMin = parseInt(yearEntity.value);
      const locEntity = ctx.intent.entities.find((e) => e.key === 'location');
      if (locEntity) filters.location = locEntity.value;
      // Do NOT pass full Arabic query as filter — structured filters are primary
      const results = searchItems(datasetType, filters);
      return {
        success: true,
        data: { results, count: results.length, query: ctx.intent.originalText, filters },
      };
    }
    case 'FILTER': {
      const results = ctx.priorResults['SEARCH'] as { results?: MockItem[] } | undefined;
      const items = results?.results || [];
      return { success: true, data: { filtered: items, count: items.length } };
    }
    case 'COMPARE': {
      const results = ctx.priorResults['SEARCH'] as { results?: MockItem[] } | undefined;
      const items = (results?.results || []).slice(0, 3);
      return { success: true, data: { comparisonItems: items } };
    }
    case 'MATCH':
    case 'MATCH_CANDIDATES': {
      const results = ctx.priorResults['SEARCH'] as { results?: MockItem[] } | undefined;
      const items = (results?.results || []).slice(0, 1);
      return { success: true, data: { bestMatch: items[0] || null } };
    }
    case 'CREATE_LISTING': {
      return {
        success: true,
        data: {
          listingId: `listing-${Date.now()}`,
          formData: ctx.formData,
          status: 'draft',
        },
      };
    }
    case 'NEGOTIATE':
    case 'PROPOSE': {
      const target = ctx.priorResults['MATCH'] as { bestMatch?: MockItem } | undefined;
      const price = (target?.bestMatch?.price as number) || 0;
      return {
        success: true,
        data: {
          originalPrice: price,
          proposedPrice: Math.round(price * 0.92 * 100) / 100,
          discountPercent: 8,
          sellerLikelyToAccept: Math.random() > 0.3,
        },
      };
    }
    case 'PAY':
    case 'AUTHORIZE':
    case 'CAPTURE': {
      return {
        success: true,
        requiresHumanGate: true,
        data: {
          paymentMethod: 'knet_placeholder',
          amount: ctx.formData?.amount || 0,
          currency: 'KWD',
          status: 'awaiting_confirmation',
        },
      };
    }
    case 'ESCROW': {
      return {
        success: true,
        requiresHumanGate: true,
        data: { escrowId: `esc-${Date.now()}`, status: 'holding', releaseAfterDays: 7 },
      };
    }
    case 'BOOK':
    case 'BOOK_APPOINTMENT':
    case 'RESERVE': {
      return {
        success: true,
        data: { bookingId: `bk-${Date.now()}`, status: 'confirmed', date: new Date().toISOString() },
      };
    }
    case 'DELIVER':
    case 'TRACK':
    case 'NOTIFY':
    case 'ETA': {
      return {
        success: true,
        data: {
          trackingId: `trk-${Date.now()}`,
          status: 'in_transit',
          eta: new Date(Date.now() + 3600_000).toISOString(),
          driverName: 'محمد العلي',
        },
      };
    }
    case 'VERIFY':
    case 'VERIFY_PRESCRIPTION': {
      return { success: true, data: { verified: true, verifiedAt: new Date().toISOString() } };
    }
    case 'DESIGN_WORLD':
    case 'CREATE_ENTITIES':
    case 'DEFINE_POLICIES':
    case 'DEPLOY':
    case 'MONITOR': {
      return {
        success: true,
        requiresHumanGate: capability === 'DEPLOY',
        data: {
          phase: capability,
          worldId: ctx.worldModel.id,
          entities: ctx.worldModel.entities.map((e) => e.type),
          policies: ctx.worldModel.policies.length,
        },
      };
    }
    case 'BALANCE':
    case 'HISTORY':
    case 'QUERY':
    case 'AGGREGATE':
    case 'VISUALIZE':
    case 'INSIGHT': {
      return {
        success: true,
        data: { metric: 'demo_value', value: Math.floor(Math.random() * 1000), trend: 'up' },
      };
    }
    case 'SHORTLIST': {
      const results = ctx.priorResults['SEARCH'] as { results?: MockItem[] } | undefined;
      return { success: true, data: { shortlisted: (results?.results || []).slice(0, 3) } };
    }
    case 'INTERVIEW': {
      return { success: true, data: { interviewId: `iv-${Date.now()}`, scheduledAt: new Date(Date.now() + 86400_000).toISOString() } };
    }
    case 'CONTRACT': {
      return { success: true, requiresHumanGate: true, data: { contractId: `ct-${Date.now()}`, status: 'draft' } };
    }
    default: {
      // Generic capabilities: just mark as done
      return { success: true, data: { note: `Executed ${capability}` } };
    }
  }
}

// ─── Advance Workflow ──────────────────────────────────────────────────────

export function observeStep(workflow: Workflow): TaskStep | undefined {
  return workflow.steps[workflow.currentStepIndex];
}

export function verifyAndAdvance(
  workflow: Workflow,
  result: ExecutionResult,
  capability: string,
): Workflow {
  const newWf: Workflow = JSON.parse(JSON.stringify(workflow));
  const current = newWf.steps[newWf.currentStepIndex];
  if (!current) return newWf;

  if (!result.success) {
    current.status = 'failed';
    current.attempts += 1;
    // Repair: if attempt < 3, try again; otherwise mark as failed and continue
    if (current.attempts < 3) {
      current.status = 'running';
      newWf.status = 'replanning';
    } else {
      current.status = 'failed';
      // Skip to next step (Replan strategy: skip and continue)
      newWf.currentStepIndex += 1;
      if (newWf.steps[newWf.currentStepIndex]) {
        newWf.steps[newWf.currentStepIndex].status = 'running';
      }
      newWf.status = 'executing';
    }
  } else {
    current.status = 'completed';
    current.output = result.data;
    current.completedAt = Date.now();
    newWf.currentStepIndex += 1;
    if (newWf.steps[newWf.currentStepIndex]) {
      newWf.steps[newWf.currentStepIndex].status = 'running';
      newWf.steps[newWf.currentStepIndex].startedAt = Date.now();
    } else {
      newWf.status = 'completed';
    }
  }
  newWf.updatedAt = Date.now();
  return newWf;
}

export function isWorkflowComplete(workflow: Workflow): boolean {
  return workflow.currentStepIndex >= workflow.steps.length;
}

// ─── Run entire workflow in one shot (for demo simplicity) ─────────────────

export function runWorkflow(
  workflow: Workflow,
  ctx: ExecutionContext,
): { workflow: Workflow; results: Record<string, unknown> } {
  let wf = workflow;
  const results: Record<string, unknown> = {};

  while (!isWorkflowComplete(wf)) {
    const step = observeStep(wf);
    if (!step) break;

    const result = executeCapability(step.capability, { ...ctx, priorResults: results });
    results[step.capability] = result.data;
    wf = verifyAndAdvance(wf, result, step.capability);

    // Safety: don't loop infinitely
    if (wf.status === 'replanning' && step.attempts >= 3) {
      break;
    }
  }

  return { workflow: wf, results };
}

// ─── Get the current step's execution output for UI ────────────────────────

export function getCurrentStepOutput(workflow: Workflow, results: Record<string, unknown>): {
  capability: string;
  output: unknown;
  isLast: boolean;
} | null {
  const currentIdx = Math.max(0, workflow.currentStepIndex - 1);
  const step = workflow.steps[currentIdx];
  if (!step) return null;
  return {
    capability: step.capability,
    output: results[step.capability] || step.output,
    isLast: workflow.currentStepIndex >= workflow.steps.length,
  };
}

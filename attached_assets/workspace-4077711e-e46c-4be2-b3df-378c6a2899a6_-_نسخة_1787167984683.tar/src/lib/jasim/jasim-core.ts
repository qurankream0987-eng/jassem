// ============================================================================
// 🧬 JASIM v34.0 — Core Orchestrator (REAL)
// Goal → Intent (LLM) → Soul → DNA → World → Plan → Execute → Verify → Persist → UI
// ============================================================================

import { db } from '@/lib/db';
import type {
  UIContract, DNAGene, Workflow, IntentResult, HumanSoul,
  IslamicValidation, WorldModel, RuntimeState, ChatMessage,
  Evidence, Result, ExecutionContext,
} from './types';
import { extractIntent } from './ai-gateway';
import { validateIslamicConscience } from './islamic-conscience';
import { readHumanSoul } from './human-soul';
import { getDNA, breedDNA } from './dna-breeding';
import { buildWorldModel } from './world-builder';
import { capabilityRegistry } from './capability-registry';
import { compilePlan, observeStep, verifyAndAdvance, isWorkflowComplete, STOP_CAPABILITIES } from './task-planner';
import {
  buildBlockedContract,
  buildEmergencyContract,
  buildWorkflowProgressContract,
  getContractForCurrentStep,
} from './ui-contract-generator';

// ─── Process Result ────────────────────────────────────────────────────────

export interface ProcessResult {
  message: ChatMessage;
  isComplete: boolean;
  blocked: boolean;
  emergency: boolean;
  aiProvider: string;
  aiReal: boolean;
}

// ─── Get or create user (guest by default) ────────────────────────────────

async function getOrCreateUser(userId?: string): Promise<string> {
  if (userId) {
    const user = await db.user.findUnique({ where: { id: userId } });
    if (user) return user.id;
  }
  // Get or create guest user
  const guest = await db.user.upsert({
    where: { id: 'user-guest' },
    create: { id: 'user-guest', name: 'ضيف', language: 'ar', role: 'user', trustScore: 0.3 },
    update: {},
  });
  return guest.id;
}

// ─── Get or create session ────────────────────────────────────────────────

async function getOrCreateSession(sessionId?: string): Promise<string> {
  if (sessionId) {
    const session = await db.session.findUnique({ where: { id: sessionId } });
    if (session) return session.id;
  }
  const session = await db.session.create({ data: {} });
  return session.id;
}

// ─── Persist user message ──────────────────────────────────────────────────

async function persistUserMessage(sessionId: string, userId: string, text: string): Promise<string> {
  const msg = await db.message.create({
    data: {
      sessionId,
      userId,
      role: 'user',
      text,
      timestamp: new Date(),
    },
  });
  return msg.id;
}

// ─── Persist assistant message ─────────────────────────────────────────────

async function persistAssistantMessage(
  sessionId: string,
  userId: string,
  message: ChatMessage,
  workflowId?: string,
): Promise<string> {
  const msg = await db.message.create({
    data: {
      sessionId,
      userId,
      role: 'assistant',
      text: message.text,
      intentJson: message.intent ? JSON.stringify(message.intent) : null,
      soulJson: message.soul ? JSON.stringify(message.soul) : null,
      islamicJson: message.islamicCheck ? JSON.stringify(message.islamicCheck) : null,
      contractsJson: JSON.stringify(message.contracts),
      workflowId,
      timestamp: new Date(),
    },
  });
  return msg.id;
}

// ─── Persist workflow + task DNA ────────────────────────────────────────────

async function persistWorkflow(
  workflow: Workflow,
  intent: IntentResult,
  dna: DNAGene,
  userId: string,
  sessionId: string,
): Promise<string> {
  // Upsert TaskDNA
  const dnaRecord = await db.taskDNA.create({
    data: {
      goal: intent.goal,
      intentJson: JSON.stringify(intent),
      capabilities: JSON.stringify(dna.capabilities),
      trustLevel: dna.trustLevel,
      riskLevel: dna.riskLevel,
      humanGatesJson: JSON.stringify(dna.humanGates),
    },
  });

  const wfRecord = await db.workflow.create({
    data: {
      id: workflow.id,
      dnaId: dnaRecord.id,
      sessionId,
      ownerId: userId,
      status: workflow.status,
      currentStepIndex: workflow.currentStepIndex,
      stepsJson: JSON.stringify(workflow.steps),
      resultsJson: JSON.stringify(workflow.results),
      startedAt: new Date(workflow.startedAt),
    },
  });

  return wfRecord.id;
}

// ─── Update workflow in DB ──────────────────────────────────────────────────

async function updateWorkflowInDb(workflow: Workflow, evidence: Evidence[]): Promise<void> {
  try {
    await db.workflow.update({
      where: { id: workflow.id },
      data: {
        status: workflow.status,
        currentStepIndex: workflow.currentStepIndex,
        stepsJson: JSON.stringify(workflow.steps),
        resultsJson: JSON.stringify(workflow.results),
        completedAt: workflow.completedAt ? new Date(workflow.completedAt) : null,
        updatedAt: new Date(),
      },
    });

    // Store evidence
    for (const ev of evidence) {
      const capName = workflow.steps[Math.max(0, workflow.currentStepIndex - 1)]?.capability;
      const capRecord = capName ? await db.capability.findUnique({ where: { name: capName } }) : null;
      await db.evidence.upsert({
        where: { id: ev.id },
        create: {
          id: ev.id,
          workflowId: workflow.id,
          capabilityId: capRecord?.id,
          claim: ev.claim,
          value: ev.value,
          source: ev.source,
          sourceRef: ev.sourceRef || null,
          confidence: ev.confidence,
          verificationStatus: ev.verificationStatus,
          retrievedAt: new Date(ev.retrievedAt),
        },
        update: {},
      });
    }

    // Create checkpoint
    await db.checkpoint.create({
      data: {
        workflowId: workflow.id,
        stepIndex: workflow.currentStepIndex,
        stepJson: JSON.stringify(workflow.steps[workflow.currentStepIndex - 1] || {}),
        stateJson: JSON.stringify({ status: workflow.status, results: workflow.results }),
      },
    });

    // Publish step event
    const lastStep = workflow.steps[Math.max(0, workflow.currentStepIndex - 1)];
    if (lastStep) {
      await db.event.create({
        data: {
          type: lastStep.status === 'completed' ? 'StepCompleted' : (lastStep.status === 'failed' ? 'StepFailed' : 'CapabilityInvoked'),
          workflowId: workflow.id,
          payloadJson: JSON.stringify({ step: lastStep.capability, status: lastStep.status }),
        },
      });
    }
  } catch (error) {
    console.error('[JASIM] Failed to update workflow in DB:', error);
  }
}

// ─── Build execution context ──────────────────────────────────────────────

function buildExecutionContext(
  workflow: Workflow,
  intent: IntentResult,
  worldModel: WorldModel,
  dna: DNAGene,
  userId: string,
  sessionId: string,
): ExecutionContext {
  return {
    workflowId: workflow.id,
    ownerId: userId,
    sessionId,
    intent,
    worldModel,
    dna,
    priorResults: workflow.results,
    userId,
  };
}

// ─── Main processUserGoal ──────────────────────────────────────────────────

export async function processUserGoal(
  userText: string,
  sessionId?: string,
  userId?: string,
): Promise<ProcessResult> {
  // 1. Resolve user + session
  const resolvedUserId = await getOrCreateUser(userId);
  const resolvedSessionId = await getOrCreateSession(sessionId);

  // 2. Persist user message
  await persistUserMessage(resolvedSessionId, resolvedUserId, userText);

  // 3. Extract intent via LLM (with regex fallback)
  const { intent, aiResponse } = await extractIntent(userText);

  // 4. Islamic Conscience check — BLOCK if non-compliant
  const islamicCheck = validateIslamicConscience(userText);
  if (!islamicCheck.isCompliant) {
    const blockedContract = buildBlockedContract({
      dna: getDNA(intent.bubbleType),
      islamicCheck,
    });
    const message: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'assistant',
      contracts: [blockedContract],
      islamicCheck,
      intent,
      timestamp: Date.now(),
    };
    await persistAssistantMessage(resolvedSessionId, resolvedUserId, message);
    return {
      message,
      isComplete: true,
      blocked: true,
      emergency: false,
      aiProvider: aiResponse?.provider || 'regex-fallback',
      aiReal: aiResponse?.real ?? false,
    };
  }

  // 5. Human Soul reading
  const soul = readHumanSoul(userText);

  // 6. Crisis override — Emergency protocol
  if (soul.crisisDetected) {
    const dna = getDNA('emergency');
    const emergencyContract = buildEmergencyContract({ dna, soul, intent });
    const message: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'assistant',
      text: soul.empathyResponse,
      contracts: [emergencyContract],
      soul,
      intent,
      islamicCheck,
      timestamp: Date.now(),
    };
    await persistAssistantMessage(resolvedSessionId, resolvedUserId, message);
    return {
      message,
      isComplete: true,
      blocked: false,
      emergency: true,
      aiProvider: aiResponse?.provider || 'regex-fallback',
      aiReal: aiResponse?.real ?? false,
    };
  }

  // 7. DNA selection / breeding
  let dna: DNAGene;
  if (intent.type === 'BUILD_PLATFORM') {
    dna = breedDNA(
      [intent.bubbleType, 'platform', 'product'],
      userText,
      { islamicCompliant: true },
    );
  } else {
    dna = getDNA(intent.bubbleType);
  }

  // 8. Build World Model
  const worldModel = buildWorldModel(intent, dna);

  // 9. Compile workflow plan (DAG)
  const workflow = compilePlan(dna, intent, resolvedUserId, resolvedSessionId);

  // 10. Persist workflow to DB (creates TaskDNA + Workflow record)
  await persistWorkflow(workflow, intent, dna, resolvedUserId, resolvedSessionId);

  // 11. Execute workflow — STOP at first user-visible capability
  let executedWorkflow = workflow;
  const allEvidence: Evidence[] = [];
  const ctx = buildExecutionContext(executedWorkflow, intent, worldModel, dna, resolvedUserId, resolvedSessionId);

  for (let i = 0; i < executedWorkflow.steps.length; i++) {
    const step = observeStep(executedWorkflow);
    if (!step) break;

    // Execute current step using capability registry
    const result = await capabilityRegistry.execute(step.capability, ctx);
    if (result.evidence) allEvidence.push(...result.evidence);

    executedWorkflow = verifyAndAdvance(executedWorkflow, result);
    executedWorkflow.results = { ...executedWorkflow.results, [step.capability]: result.data };

    // Track cost
    if (result.costUsd) executedWorkflow.totalCostUsd += result.costUsd;
    if (result.tokensIn) executedWorkflow.totalTokensIn += result.tokensIn;
    if (result.tokensOut) executedWorkflow.totalTokensOut += result.tokensOut;

    // Stop at user-visible capabilities
    if (STOP_CAPABILITIES.has(step.capability)) {
      break;
    }
  }

  // 12. Update workflow in DB + store evidence + create checkpoint + publish events
  await updateWorkflowInDb(executedWorkflow, allEvidence);

  // 13. Generate UI contract for current/last step
  const finalContract = getContractForCurrentStep({
    dna,
    workflow: executedWorkflow,
    intent,
    worldModel,
    stepResults: executedWorkflow.results,
  });

  // 14. Build workflow visualization contract (transparency)
  const workflowContract = buildWorkflowProgressContract({
    dna,
    workflow: executedWorkflow,
  });

  // 15. Empathy text
  const empathyText = soul.empathyResponse && soul.emotionalState !== 'calm'
    ? soul.empathyResponse
    : undefined;

  // 16. Construct assistant message
  const message: ChatMessage = {
    id: `msg-${Date.now()}`,
    role: 'assistant',
    text: empathyText,
    contracts: [finalContract, workflowContract],
    soul,
    intent,
    islamicCheck,
    workflow: executedWorkflow,
    evidence: allEvidence,
    timestamp: Date.now(),
  };

  // 17. Persist assistant message
  await persistAssistantMessage(resolvedSessionId, resolvedUserId, message, executedWorkflow.id);

  const isComplete = executedWorkflow.status === 'completed';

  return {
    message,
    isComplete,
    blocked: false,
    emergency: false,
    aiProvider: aiResponse?.provider || 'regex-fallback',
    aiReal: aiResponse?.real ?? false,
  };
}

// ─── Get session messages from DB ──────────────────────────────────────────

export async function getSessionMessagesFromDb(sessionId: string): Promise<ChatMessage[]> {
  const dbMessages = await db.message.findMany({
    where: { sessionId },
    orderBy: { timestamp: 'asc' },
    take: 100,
  });

  return dbMessages.map((m) => ({
    id: m.id,
    role: m.role as ChatMessage['role'],
    text: m.text || undefined,
    contracts: m.contractsJson ? JSON.parse(m.contractsJson) : [],
    intent: m.intentJson ? JSON.parse(m.intentJson) : undefined,
    soul: m.soulJson ? JSON.parse(m.soulJson) : undefined,
    islamicCheck: m.islamicJson ? JSON.parse(m.islamicJson) : undefined,
    timestamp: m.timestamp.getTime(),
  }));
}

// ─── Continue workflow (when user clicks action) ──────────────────────────

export async function continueWorkflow(
  workflowId: string,
  actionId: string,
  payload?: Record<string, unknown>,
): Promise<ProcessResult> {
  // Load workflow from DB
  const wfRecord = await db.workflow.findUnique({
    where: { id: workflowId },
    include: { dna: true, owner: true, session: true },
  });
  if (!wfRecord) {
    throw new Error(`Workflow ${workflowId} not found`);
  }

  // Reconstruct workflow object
  const workflow: Workflow = {
    id: wfRecord.id,
    dnaId: wfRecord.dnaId,
    ownerId: wfRecord.ownerId,
    sessionId: wfRecord.sessionId || undefined,
    steps: JSON.parse(wfRecord.stepsJson),
    currentStepIndex: wfRecord.currentStepIndex,
    status: wfRecord.status as Workflow['status'],
    results: wfRecord.resultsJson ? JSON.parse(wfRecord.resultsJson) : {},
    startedAt: wfRecord.startedAt.getTime(),
    completedAt: wfRecord.completedAt?.getTime(),
    updatedAt: wfRecord.updatedAt.getTime(),
    totalCostUsd: 0,
    totalTokensIn: 0,
    totalTokensOut: 0,
  };

  // Reconstruct intent
  const intent: IntentResult = JSON.parse(wfRecord.dna.intentJson);

  // Reconstruct DNA
  const dna: DNAGene = {
    id: wfRecord.dnaId,
    version: '34.0',
    generation: 0,
    bubbleType: intent.bubbleType,
    capabilities: JSON.parse(wfRecord.dna.capabilities),
    trustLevel: wfRecord.dna.trustLevel as DNAGene['trustLevel'],
    riskLevel: wfRecord.dna.riskLevel as DNAGene['riskLevel'],
    theme: { primary: '#800020', secondary: '#D4AF37', accent: '#FFD700', glow: '#800020' },
    streamMode: true,
    expandable: true,
    selfHealing: true,
    mutations: [],
  };

  const worldModel = buildWorldModel(intent, dna);
  const ctx = buildExecutionContext(workflow, intent, worldModel, dna, workflow.ownerId, workflow.sessionId || '');
  ctx.formData = payload;

  // Continue executing remaining steps
  let executedWorkflow = workflow;
  const allEvidence: Evidence[] = [];

  // Execute next step(s)
  while (!isWorkflowComplete(executedWorkflow)) {
    const step = observeStep(executedWorkflow);
    if (!step) break;

    const result = await capabilityRegistry.execute(step.capability, ctx);
    if (result.evidence) allEvidence.push(...result.evidence);

    executedWorkflow = verifyAndAdvance(executedWorkflow, result);
    executedWorkflow.results = { ...executedWorkflow.results, [step.capability]: result.data };

    if (STOP_CAPABILITIES.has(step.capability)) {
      break;
    }
  }

  await updateWorkflowInDb(executedWorkflow, allEvidence);

  const finalContract = getContractForCurrentStep({
    dna,
    workflow: executedWorkflow,
    intent,
    worldModel,
    stepResults: executedWorkflow.results,
  });

  const workflowContract = buildWorkflowProgressContract({
    dna,
    workflow: executedWorkflow,
  });

  const message: ChatMessage = {
    id: `msg-${Date.now()}`,
    role: 'assistant',
    contracts: [finalContract, workflowContract],
    intent,
    workflow: executedWorkflow,
    evidence: allEvidence,
    timestamp: Date.now(),
  };

  // Persist the new message
  if (workflow.sessionId) {
    await persistAssistantMessage(workflow.sessionId, workflow.ownerId, message, executedWorkflow.id);
  }

  return {
    message,
    isComplete: executedWorkflow.status === 'completed',
    blocked: false,
    emergency: false,
    aiProvider: 'jasim-runtime',
    aiReal: true,
  };
}

// ─── Suggestion Examples (Novel Tasks) ──────────────────────────────────────
// (Moved to separate file for client-side import safety)

export const SUGGESTION_EXAMPLES_PLACEHOLDER = true;

// ============================================================================
// 🧬 JASIM v34.0 — Canonical Type System
// Real Generative Commercial Runtime — DNA → Capability → Composer → Runtime → Verifier
// ============================================================================

import { z } from 'zod';

// ─── 1. INTENT (LLM-extracted, Zod-validated) ──────────────────────────────

export const IntentTypeSchema = z.enum([
  'SEARCH', 'CREATE', 'COMPARE', 'BOOK', 'BUY', 'SELL',
  'NEGOTIATE', 'DELIVER', 'HIRE', 'PAY', 'EMERGENCY', 'CHAT',
  'BUILD_PLATFORM', 'ANALYZE', 'PROCURE', 'SCHEDULE', 'VERIFY',
]);
export type IntentType = z.infer<typeof IntentTypeSchema>;

export const BubbleTypeSchema = z.enum([
  'food', 'restaurant', 'pharmacy', 'fashion', 'grocery', 'delivery', 'emergency',
  'job', 'recruitment', 'payment', 'wallet', 'analytics', 'ads',
  'platform', 'negotiation', 'product', 'service', 'dashboard', 'settings',
  'chat', 'subchat', 'suggestions', 'ad',
  'cinema', 'car_insurance', 'real_estate', 'travel', 'education',
  'healthcare', 'government', 'events',
  'generic',
]);
export type BubbleType = z.infer<typeof BubbleTypeSchema>;

export const EntitySchema = z.object({
  key: z.string(),
  value: z.string(),
  type: z.enum(['string', 'number', 'currency', 'location', 'time', 'brand', 'category']),
  confidence: z.number().min(0).max(1).default(1),
});
export type Entity = z.infer<typeof EntitySchema>;

export const IntentResultSchema = z.object({
  type: IntentTypeSchema,
  bubbleType: BubbleTypeSchema,
  confidence: z.number().min(0).max(1),
  goal: z.string(),
  entities: z.array(EntitySchema).default([]),
  constraints: z.array(z.string()).default([]),
  originalText: z.string(),
  language: z.enum(['ar', 'ar-gulf', 'ar-egypt', 'en']).default('ar'),
  modelProvider: z.string().default('zai-glm'),
  modelReal: z.boolean().default(true),
  causalContext: z.string().optional(),
  forbiddenDetected: z.boolean().default(false),
});
export type IntentResult = z.infer<typeof IntentResultSchema>;

// ─── 2. ISLAMIC CONSCIENCE ──────────────────────────────────────────────────

export const IslamicValidationSchema = z.object({
  isCompliant: z.boolean(),
  forbiddenItems: z.array(z.object({
    category: z.string(),
    categoryAr: z.string(),
    matchedText: z.string(),
    severity: z.enum(['high', 'medium', 'low']),
  })),
  alternatives: z.array(z.string()),
  warnings: z.array(z.string()),
  fatwaReference: z.string().optional(),
});
export type IslamicValidation = z.infer<typeof IslamicValidationSchema>;

// ─── 3. HUMAN SOUL ──────────────────────────────────────────────────────────

export const HumanSoulSchema = z.object({
  emotionalState: z.enum(['calm', 'urgent', 'frustrated', 'happy', 'confused', 'anxious']),
  crisisDetected: z.boolean(),
  empathyResponse: z.string(),
  voiceTone: z.enum(['gentle', 'professional', 'urgent', 'celebratory', 'reassuring']),
  suggestedAction: z.string(),
  trustAdjustment: z.number().min(-1).max(1).default(0),
});
export type HumanSoul = z.infer<typeof HumanSoulSchema>;

// ─── 4. CAPABILITY (canonical, versioned, real) ────────────────────────────

export const CapabilityTypeSchema = z.enum([
  'SEARCH', 'CREATE', 'COMPARE', 'PAY', 'ESCROW', 'DISPATCH', 'MATCH', 'CHAT',
  'NOTIFY', 'TRACK', 'VERIFY', 'NEGOTIATE', 'BOOK', 'DELIVER', 'CALCULATE',
  'ANALYZE', 'CREATE_LISTING', 'FILTER', 'RANK', 'RECOMMEND', 'ORDER',
  'REFUND', 'AUTHORIZE', 'CAPTURE', 'RELEASE', 'AGGREGATE', 'VISUALIZE',
  'INSIGHT', 'QUERY', 'HISTORY', 'BALANCE', 'TRANSFER', 'TOPUP', 'WITHDRAW',
]);
export type CapabilityType = z.infer<typeof CapabilityTypeSchema>;

export const CapabilitySchema = z.object({
  id: z.string(),
  name: z.string(),
  type: CapabilityTypeSchema,
  version: z.number().default(1),
  description: z.string().optional(),
  status: z.enum(['REAL', 'MOCKED', 'BLOCKED', 'EXTERNAL']).default('REAL'),
  riskLevel: z.enum(['low', 'medium', 'high', 'critical']).default('low'),
  latencyMs: z.number().default(200),
  reliability: z.number().min(0).max(1).default(0.95),
  costUsd: z.number().default(0),
  requiredPermissions: z.array(z.string()).default([]),
  fallbackCapabilityId: z.string().optional(),
  inputSchema: z.record(z.unknown()).optional(),
  outputSchema: z.record(z.unknown()).optional(),
});
export type Capability = z.infer<typeof CapabilitySchema>;

// ─── 5. TASK DNA ────────────────────────────────────────────────────────────

export const DNAGeneSchema = z.object({
  id: z.string(),
  version: z.string().default('34.0'),
  generation: z.number().default(0),
  parentIds: z.array(z.string()).optional(),
  bubbleType: BubbleTypeSchema,
  capabilities: z.array(z.string()),
  trustLevel: z.enum(['low', 'medium', 'high']).default('medium'),
  riskLevel: z.enum(['low', 'medium', 'high', 'critical']).default('low'),
  modelPolicy: z.string().optional(),
  memoryRequirements: z.array(z.string()).default([]),
  humanGates: z.array(z.string()).default([]),
  verificationPolicy: z.string().default('standard'),
  theme: z.object({
    primary: z.string(),
    secondary: z.string(),
    accent: z.string(),
    glow: z.string(),
  }),
  streamMode: z.boolean().default(true),
  expandable: z.boolean().default(true),
  selfHealing: z.boolean().default(true),
  lifetimeMs: z.number().optional(),
  mutations: z.array(z.string()).default([]),
  createdAt: z.number().default(() => Date.now()),
});
export type DNAGene = z.infer<typeof DNAGeneSchema>;

// ─── 6. WORKFLOW & STEPS (DAG) ─────────────────────────────────────────────

export const TaskStepStatusSchema = z.enum([
  'pending', 'running', 'completed', 'failed', 'skipped', 'waiting_user', 'waiting_external',
]);
export type TaskStepStatus = z.infer<typeof TaskStepStatusSchema>;

export const TaskStepSchema = z.object({
  id: z.string(),
  capability: z.string(),
  labelAr: z.string(),
  labelEn: z.string(),
  status: TaskStepStatusSchema.default('pending'),
  output: z.unknown().optional(),
  startedAt: z.number().optional(),
  completedAt: z.number().optional(),
  attempts: z.number().default(0),
  maxAttempts: z.number().default(3),
  requiresHumanGate: z.boolean().default(false),
  dependsOn: z.array(z.string()).default([]),
  evidenceId: z.string().optional(),
  error: z.string().optional(),
});
export type TaskStep = z.infer<typeof TaskStepSchema>;

export const WorkflowStatusSchema = z.enum([
  'planning', 'executing', 'verifying', 'completed', 'failed', 'replanning',
  'waiting_user', 'waiting_external', 'cancelled',
]);
export type WorkflowStatus = z.infer<typeof WorkflowStatusSchema>;

export const WorkflowSchema = z.object({
  id: z.string(),
  dnaId: z.string(),
  ownerId: z.string(),
  sessionId: z.string().optional(),
  steps: z.array(TaskStepSchema),
  currentStepIndex: z.number().default(0),
  status: WorkflowStatusSchema.default('planning'),
  results: z.record(z.unknown()).default({}),
  startedAt: z.number().default(() => Date.now()),
  completedAt: z.number().optional(),
  updatedAt: z.number().default(() => Date.now()),
  totalCostUsd: z.number().default(0),
  totalTokensIn: z.number().default(0),
  totalTokensOut: z.number().default(0),
});
export type Workflow = z.infer<typeof WorkflowSchema>;

// ─── 7. WORLD MODEL ─────────────────────────────────────────────────────────

export const WorldEntityFieldSchema = z.object({
  id: z.string(),
  name: z.string(),
  label: z.string(),
  labelAr: z.string(),
  type: z.enum(['string', 'number', 'currency', 'image', 'location', 'time', 'select', 'boolean']),
  searchable: z.boolean().default(false),
  filterable: z.boolean().default(false),
  sortable: z.boolean().default(false),
  required: z.boolean().default(false),
  options: z.array(z.object({ value: z.string(), label: z.string(), labelAr: z.string() })).optional(),
  defaultValue: z.unknown().optional(),
});
export type WorldEntityField = z.infer<typeof WorldEntityFieldSchema>;

export const WorldEntitySchema = z.object({
  id: z.string(),
  type: z.string(),
  name: z.string(),
  nameAr: z.string(),
  fields: z.array(WorldEntityFieldSchema),
  relations: z.array(z.object({
    targetEntityType: z.string(),
    type: z.enum(['one-to-many', 'many-to-one', 'many-to-many']),
  })).default([]),
});
export type WorldEntity = z.infer<typeof WorldEntitySchema>;

export const WorldModelSchema = z.object({
  id: z.string(),
  name: z.string(),
  nameAr: z.string(),
  dnaId: z.string(),
  entities: z.array(WorldEntitySchema),
  policies: z.array(z.object({
    id: z.string(),
    rule: z.string(),
    ruleAr: z.string(),
    severity: z.enum(['advisory', 'mandatory', 'blocking']),
  })).default([]),
  createdAt: z.number(),
});
export type WorldModel = z.infer<typeof WorldModelSchema>;

// ─── 8. EVIDENCE (every claim is traceable) ────────────────────────────────

export const EvidenceSchema = z.object({
  id: z.string(),
  claim: z.string(),
  value: z.string(),
  source: z.enum(['user_input', 'merchant_api', 'web_search', 'internal_calc', 'capability_output', 'database', 'llm']),
  sourceRef: z.string().optional(),
  confidence: z.number().min(0).max(1).default(0.9),
  verificationStatus: z.enum(['unverified', 'verified', 'rejected']).default('unverified'),
  retrievedAt: z.number().default(() => Date.now()),
});
export type Evidence = z.infer<typeof EvidenceSchema>;

// ─── 9. RESULT (canonical task output) ────────────────────────────────────

export const ResultStatusSchema = z.enum([
  'PLANNED', 'RUNNING', 'WAITING_FOR_USER', 'WAITING_EXTERNAL',
  'COMPLETED', 'PARTIALLY_COMPLETED', 'FAILED', 'BLOCKED',
]);
export type ResultStatus = z.infer<typeof ResultStatusSchema>;

export const ResultSchema = z.object({
  status: ResultStatusSchema,
  summary: z.string(),
  summaryAr: z.string().optional(),
  data: z.record(z.unknown()).default({}),
  evidence: z.array(EvidenceSchema).default([]),
  nextSteps: z.array(z.object({
    label: z.string(),
    labelAr: z.string(),
    capabilityId: z.string(),
    payload: z.record(z.unknown()).optional(),
  })).default([]),
  confidence: z.number().min(0).max(1).default(0.9),
  costUsd: z.number().default(0),
  executionTimeMs: z.number().default(0),
});
export type Result = z.infer<typeof ResultSchema>;

// ─── 10. UI CONTRACT ────────────────────────────────────────────────────────

export const PrimitiveTypeSchema = z.enum([
  'form', 'search', 'results', 'gallery', 'comparison',
  'progress', 'confirmation', 'payment', 'status', 'chat',
  'negotiation', 'dashboard', 'listing', 'evidence', 'detail',
]);
export type PrimitiveType = z.infer<typeof PrimitiveTypeSchema>;

export const UIContractThemeSchema = z.object({
  primary: z.string(),
  secondary: z.string(),
  accent: z.string(),
  glow: z.string(),
});

export const UIContractActionSchema = z.object({
  id: z.string(),
  label: z.string(),
  labelAr: z.string(),
  type: z.enum(['primary', 'secondary', 'danger', 'ghost', 'success']),
  capabilityId: z.string(),
  icon: z.string().optional(),
  confirmation: z.string().optional(),
  payload: z.record(z.unknown()).optional(),
  disabled: z.boolean().default(false),
  loading: z.boolean().default(false),
  requiresHumanGate: z.boolean().default(false),
});

export const UIContractFieldSchema = z.object({
  id: z.string(),
  name: z.string(),
  label: z.string(),
  labelAr: z.string(),
  type: z.string(),
  placeholder: z.string().optional(),
  helpText: z.string().optional(),
  defaultValue: z.unknown().optional(),
  options: z.array(z.object({ value: z.string(), label: z.string(), labelAr: z.string() })).optional(),
  validation: z.object({
    required: z.boolean().optional(),
    min: z.number().optional(),
    max: z.number().optional(),
    pattern: z.string().optional(),
  }).optional(),
});

// Self-referential children handled with interface
export interface UIContract {
  version: '1.0';
  id: string;
  primitiveType: PrimitiveType;
  title: string;
  titleAr: string;
  subtitle?: string;
  bubbleType: BubbleType;
  metadata: {
    dnaId: string;
    workflowId?: string;
    stepIndex?: number;
    capabilityId?: string;
    timestamp: string;
  };
  layout: {
    type: 'vertical' | 'horizontal' | 'grid' | 'tabs' | 'wizard' | 'accordion';
    columns?: number;
    gap?: string;
  };
  fields: Array<z.infer<typeof UIContractFieldSchema>>;
  actions: Array<z.infer<typeof UIContractActionSchema>>;
  data?: Record<string, unknown>;
  theme?: z.infer<typeof UIContractThemeSchema>;
  evidence?: Evidence[];
  children?: UIContract[];
}

// ─── 11. CHAT MESSAGE ──────────────────────────────────────────────────────

export type ChatRole = 'user' | 'assistant' | 'system';

export interface ChatMessage {
  id: string;
  role: ChatRole;
  text?: string;
  contracts: UIContract[];
  soul?: HumanSoul;
  islamicCheck?: IslamicValidation;
  intent?: IntentResult;
  workflow?: Workflow;
  evidence?: Evidence[];
  result?: Result;
  timestamp: number;
}

// ─── 12. RUNTIME STATE (session + memory) ─────────────────────────────────

export interface RuntimeState {
  sessionId: string;
  userId: string;
  messages: ChatMessage[];
  activeDnaId?: string;
  activeWorkflowId?: string;
  worldModel?: WorldModel;
  memory: Record<string, unknown>;
}

// ─── 13. EXECUTION CONTEXT (passed to capabilities) ──────────────────────

export interface ExecutionContext {
  workflowId: string;
  ownerId: string;
  sessionId?: string;
  intent: IntentResult;
  worldModel: WorldModel;
  dna: DNAGene;
  priorResults: Record<string, unknown>;
  formData?: Record<string, unknown>;
  userId?: string;
}

// ─── 14. EXECUTION RESULT (from a capability) ─────────────────────────────

export interface ExecutionResult {
  success: boolean;
  data?: unknown;
  evidence?: Evidence[];
  error?: string;
  requiresHumanGate?: boolean;
  costUsd?: number;
  tokensIn?: number;
  tokensOut?: number;
  latencyMs?: number;
}

// ─── 15. AI GATEWAY RESPONSE ──────────────────────────────────────────────

export interface AIGatewayResponse<T = unknown> {
  provider: string;
  model: string;
  real: boolean;
  fallback: boolean;
  confidence: number;
  data: T;
  tokensIn: number;
  tokensOut: number;
  costUsd: number;
  latencyMs: number;
  error?: string;
}

// ─── 16. EVENT ────────────────────────────────────────────────────────────

export const EventTypeSchema = z.enum([
  'WorkflowStarted', 'StepCompleted', 'StepFailed', 'WorkflowCompleted',
  'ListingCreated', 'ListingSold', 'ListingRemoved',
  'TransactionInitiated', 'PaymentAuthorized', 'PaymentReleased', 'PaymentRefunded',
  'EscrowHeld', 'EscrowReleased',
  'MessageReceived', 'NotificationSent',
  'TaskFailed', 'TaskReplanned',
  'UserApproved', 'UserBlocked',
  'EvidenceRecorded', 'CapabilityInvoked',
]);
export type EventType = z.infer<typeof EventTypeSchema>;

export interface JasimEvent {
  id: string;
  type: EventType;
  workflowId?: string;
  transactionId?: string;
  capabilityId?: string;
  userId?: string;
  payload: Record<string, unknown>;
  publishedAt: number;
}

// ─── 17. REVENUE TIERS ────────────────────────────────────────────────────

export type RevenueTier = 'b2c_free' | 'b2c_express' | 'b2b_starter' | 'b2b_pro' | 'b2b_enterprise' | 'developer';

export const REVENUE_CONFIG: Record<RevenueTier, {
  label: string;
  commissionRate: number;
  perTransactionFee: number;
  monthlyFee: number;
  features: string[];
}> = {
  b2c_free: { label: 'مجاني', commissionRate: 0, perTransactionFee: 0, monthlyFee: 0, features: ['basic_search', 'chat'] },
  b2c_express: { label: 'سريع', commissionRate: 0.015, perTransactionFee: 0.25, monthlyFee: 0, features: ['priority', 'negotiation'] },
  b2b_starter: { label: 'البداية', commissionRate: 0.025, perTransactionFee: 0.10, monthlyFee: 29, features: ['dashboard', 'analytics'] },
  b2b_pro: { label: 'احترافي', commissionRate: 0.02, perTransactionFee: 0.05, monthlyFee: 99, features: ['api', 'multi_branch', 'ads'] },
  b2b_enterprise: { label: 'مؤسسات', commissionRate: 0.015, perTransactionFee: 0, monthlyFee: 499, features: ['white_label', 'custom_dna', 'sla'] },
  developer: { label: 'مطور', commissionRate: 0, perTransactionFee: 0, monthlyFee: 0, features: ['api', 'sandbox', 'webhooks'] },
};

// ─── 18. COMMISSION RATES BY CATEGORY (per architecture doc) ──────────────

export const COMMISSION_RATES: Record<string, { rate: number; label: string; labelAr: string }> = {
  product: { rate: 0.05, label: 'Physical Products', labelAr: 'منتجات مادية' },
  service: { rate: 0.10, label: 'Services', labelAr: 'خدمات' },
  freelance: { rate: 0.10, label: 'Freelance', labelAr: 'عمل حر' },
  recruitment: { rate: 0.08, label: 'Recruitment', labelAr: 'توظيف' },
  car: { rate: 0.02, label: 'Cars', labelAr: 'سيارات' },
  realestate: { rate: 0.01, label: 'Real Estate', labelAr: 'عقارات' },
  b2b: { rate: 0.02, label: 'B2B', labelAr: 'B2B' },
  booking: { rate: 0.075, label: 'Bookings', labelAr: 'حجوزات' },
  digital: { rate: 0.10, label: 'Digital Services', labelAr: 'خدمات رقمية' },
};

// ============================================================================
// 🧠 JASIM — AI Gateway (Provider-Agnostic)
// Uses z-ai-web-dev-sdk (GLM model) as primary — REAL LLM integration
// Fallback: regex-based classifier (only used if SDK unavailable)
// ============================================================================

import ZAI from 'z-ai-web-dev-sdk';
import type { AIGatewayResponse, IntentResult, IntentType, BubbleType } from './types';
import { classifyIntent as regexClassifyIntent } from './intent-classifier-regex';
import { validateIslamicConscience } from './islamic-conscience';
import { readHumanSoul } from './human-soul';

// ─── ZAI Singleton ──────────────────────────────────────────────────────────

let zaiInstance: ZAI | null = null;

async function getZAI(): Promise<ZAI | null> {
  if (zaiInstance) return zaiInstance;
  try {
    zaiInstance = await ZAI.create();
    console.log('[JASIM AI] ZAI SDK initialized');
    return zaiInstance;
  } catch (error) {
    console.warn('[JASIM AI] Failed to init ZAI SDK, falling back to regex classifier:', error);
    return null;
  }
}

// ─── Intent Extraction Prompt ─────────────────────────────────────────────

const INTENT_SYSTEM_PROMPT = `أنت محرك فهم النية في نظام جاسم v34.0. مهمتك تحويل كلام المستخدم العربي إلى بنية نية دقيقة.

يجب أن تخرج JSON صالح فقط بالشكل التالي (بدون شرح إضافي):
{
  "type": "SEARCH|CREATE|COMPARE|BOOK|BUY|SELL|NEGOTIATE|DELIVER|HIRE|PAY|EMERGENCY|CHAT|BUILD_PLATFORM|ANALYZE|PROCURE|SCHEDULE|VERIFY",
  "bubbleType": "food|restaurant|pharmacy|fashion|grocery|delivery|emergency|job|recruitment|payment|wallet|analytics|ads|platform|negotiation|product|service|dashboard|settings|chat|subchat|suggestions|ad|cinema|car_insurance|real_estate|travel|education|healthcare|government|events|generic",
  "confidence": 0.0-1.0,
  "goal": "وصف موجز للهدف بالعربية",
  "entities": [
    { "key": "budget", "value": "8000", "type": "currency" },
    { "key": "carBrand", "value": "كامري", "type": "brand" }
  ],
  "constraints": ["أقل من 8000 دينار", "سنة 2023"],
  "language": "ar|ar-gulf|ar-egypt|en",
  "causalContext": "سبب اختيار هذه النية"
}

قواعد:
- إذا اكتشفت طلب طوارئ (حريق، حادث، إسعاف) → type=EMERGENCY، bubbleType=emergency
- إذا طلب إنشاء منصة جديدة → type=BUILD_PLATFORM، bubbleType=platform
- إذا طلب تحليل بيانات → type=ANALYZE، bubbleType=analytics
- استخرج كل الكيانات: الميزانية، الماركة، السنة، الموقع، الفئة
- لا تخترع قيوداً غير موجودة
- اللغة: عربي فصحى=ar، خليجي=ar-gulf، مصري=ar-egypt، إنجليزي=en`;

// ─── Real LLM Intent Extraction ──────────────────────────────────────────

export async function extractIntentWithLLM(text: string): Promise<AIGatewayResponse<IntentResult> | null> {
  const zai = await getZAI();
  if (!zai) return null;

  const startTime = Date.now();
  try {
    const response = await zai.chat.completions.create({
      model: 'glm-4-flash',
      messages: [
        { role: 'system', content: INTENT_SYSTEM_PROMPT },
        { role: 'user', content: text },
      ],
      temperature: 0.1, // low temp for structured output
      max_tokens: 800,
    });

    const content = response?.choices?.[0]?.message?.content || '';
    const latencyMs = Date.now() - startTime;

    // Parse JSON from response (handle markdown code blocks)
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      console.warn('[JASIM AI] No JSON found in LLM response, falling back');
      return null;
    }

    const parsed = JSON.parse(jsonMatch[0]);

    // Validate against our schema (with fallback for missing fields)
    const intent: IntentResult = {
      type: (parsed.type as IntentType) || 'CHAT',
      bubbleType: (parsed.bubbleType as BubbleType) || 'generic',
      confidence: Math.min(1, Math.max(0, parsed.confidence ?? 0.7)),
      goal: parsed.goal || text,
      entities: Array.isArray(parsed.entities) ? parsed.entities : [],
      constraints: Array.isArray(parsed.constraints) ? parsed.constraints : [],
      originalText: text,
      language: parsed.language || 'ar',
      modelProvider: 'zai-glm-4-flash',
      modelReal: true,
      causalContext: parsed.causalContext,
      forbiddenDetected: !validateIslamicConscience(text).isCompliant,
    };

    return {
      provider: 'zai',
      model: 'glm-4-flash',
      real: true,
      fallback: false,
      confidence: intent.confidence,
      data: intent,
      tokensIn: response?.usage?.prompt_tokens || 0,
      tokensOut: response?.usage?.completion_tokens || 0,
      costUsd: ((response?.usage?.prompt_tokens || 0) * 0.0000001) + ((response?.usage?.completion_tokens || 0) * 0.0000001),
      latencyMs,
    };
  } catch (error) {
    console.error('[JASIM AI] LLM call failed:', error);
    return null;
  }
}

// ─── Real LLM Chat (general conversation) ──────────────────────────────────

export async function chatWithLLM(
  message: string,
  systemPrompt?: string,
): Promise<AIGatewayResponse<{ text: string }>> {
  const zai = await getZAI();
  const fallbackText = regexClassifyIntent(message);

  if (!zai) {
    return {
      provider: 'regex-fallback',
      model: 'regex-classifier',
      real: false,
      fallback: true,
      confidence: 0.5,
      data: { text: 'عذراً، لا أستطيع الوصول للنموذج اللغوي الآن. لكن فهمت أنك تريد: ' + fallbackText.type },
      tokensIn: 0,
      tokensOut: 0,
      costUsd: 0,
      latencyMs: 5,
    };
  }

  const startTime = Date.now();
  try {
    const response = await zai.chat.completions.create({
      model: 'glm-4-flash',
      messages: [
        { role: 'system', content: systemPrompt || 'أنت جاسم، مساعد ذكي تجاري عربي واعٍ بالضمير الإسلامي والروح الإنسانية. أجب بالعربية الفصحى باختصار ووضوح.' },
        { role: 'user', content: message },
      ],
      temperature: 0.7,
      max_tokens: 500,
    });

    const text = response?.choices?.[0]?.message?.content || '';
    const latencyMs = Date.now() - startTime;

    return {
      provider: 'zai',
      model: 'glm-4-flash',
      real: true,
      fallback: false,
      confidence: 0.9,
      data: { text },
      tokensIn: response?.usage?.prompt_tokens || 0,
      tokensOut: response?.usage?.completion_tokens || 0,
      costUsd: ((response?.usage?.prompt_tokens || 0) * 0.0000001) + ((response?.usage?.completion_tokens || 0) * 0.0000001),
      latencyMs,
    };
  } catch (error) {
    return {
      provider: 'zai',
      model: 'glm-4-flash',
      real: false,
      fallback: true,
      confidence: 0.3,
      data: { text: 'عذراً، حدث خطأ في الاتصال بالنموذج.' },
      tokensIn: 0,
      tokensOut: 0,
      costUsd: 0,
      latencyMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

// ─── Unified Intent Extraction (LLM with regex fallback) ──────────────────

export async function extractIntent(text: string): Promise<{ intent: IntentResult; aiResponse: AIGatewayResponse<IntentResult> | null }> {
  const llmResult = await extractIntentWithLLM(text);

  if (llmResult && llmResult.real) {
    return { intent: llmResult.data, aiResponse: llmResult };
  }

  // Fallback: regex-based intent classification
  const regexIntent = regexClassifyIntent(text);
  return {
    intent: {
      ...regexIntent,
      modelProvider: 'regex-fallback',
      modelReal: false,
    },
    aiResponse: {
      provider: 'regex-fallback',
      model: 'regex-classifier',
      real: false,
      fallback: true,
      confidence: regexIntent.confidence,
      data: regexIntent,
      tokensIn: 0,
      tokensOut: 0,
      costUsd: 0,
      latencyMs: 1,
    },
  };
}
